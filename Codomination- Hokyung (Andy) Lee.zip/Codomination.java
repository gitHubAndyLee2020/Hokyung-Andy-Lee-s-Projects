import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * A turn-based game
 * 
 * @author (Hokyung(Andy) Lee) 
 * @version No.1 (Start date: September 1, 2020 / End date: )
 * @Method Names
 * main() - void
 * rulebook1p() - void
 * rulebook2p() - void
 * getPlayerNum() - int
 * onePlayerMasterBoard() - void
 * twoPlayerMasterBoard() - void
 * player1Deploy() - void
 * player2Deploy() - void
 * athenaDeploy(int i) - void
 * tip() - void
 * battleResolve1() - void
 * battleResolve2() - void
 * wait(int ms)
 * player1Upkeep() - void
 * player2Upkeep() - void
 * athenaUpkeep() - void
 * getMeleeTier(int level) - String
 * getSpearTier(int level) - String
 * getMissileTier(int level) - String
 * levelDescription() - void
 * divider();
 */
public class Codomination
{
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    static String input = "";
    static ArrayList<String> player1Troops = new ArrayList<String>();
    static ArrayList<String> player2Troops = new ArrayList<String>();
    static ArrayList<String> athenaTroops = new ArrayList<String>();
    static int XP = 0;
    static int playerNum = 0;
    static int player1HP = 10;
    static int player2HP = 10;
    static int athenaHP = 10;
    static int p1MeLevel = 1;
    static int p1SpLevel = 1;
    static int p1MiLevel = 1;
    static int p2MeLevel = 1;
    static int p2SpLevel = 1;
    static int p2MiLevel = 1;
    static int aMeLevel = 1;
    static int aSpLevel = 1;
    static int aMiLevel = 1;
    static boolean appoint = false;
    public static void main(String args[])
    {
        System.out.println("Hello, welcome to Codomination, a turn-based strategy game.");
        playerNum = getPlayerNum();
        if(playerNum == 1)
        {
            divider();
            rulebook1p();
            divider();
            onePlayerMasterBoard();
        }
        else
        {
            divider();
            rulebook2p();
            divider();
            twoPlayerMasterBoard();
        }    
    }
    public static void rulebook1p()
    {
        System.out.println("In the one-player version of Codomination, the player will be playing against Athena, the bot in this game.");
        System.out.println("The goal of the game is to defeat the other player through developing and deploying your army in the most efficient way.");
        System.out.println("The game consists of three different stages that loops until the game ends: battle, player's upkeep, and Athena's upkeep.");
        System.out.println("In the battle stage, the player and Athena will each get turns to deploy five troops onto the battlefield, where they will battle each other.");
        System.out.println("In the upkeep turns, the player and Athena will get to invest their XP points on developing their troop types.");
        System.out.println("Key Note: Athena is unaware of the choices of troop types during the player's placement stage. Athena instead uses mathematical calculation to determine the best placement choice.");
        System.out.println("Please press any key to start the game.");
        input = kb.nextLine();
    }
    public static void rulebook2p()
    {
        System.out.println("In the two-player version of Codomination, the two players will be playing against each other.");
        System.out.println("The goal of the game is to defeat the other player through developing and deploying your army in the most efficient way.");
        System.out.println("The game consists of three different stages that loops until the game ends: battle, player1's upkeep, and player2's upkeep.");
        System.out.println("In the battle stage, both players will each get turns to deploy five troops onto the battlefield. where they will battle each other.");
        System.out.println("In the upkeep turns, both players will get to invest their XP points on developing their troop types.");
        System.out.println("Please press any key to start the game.");
        input = kb.nextLine();
    }
    public static int getPlayerNum()
    {
        int num = 0;
        while(true)
        {
            System.out.println("The game has two options: one-player or two player (Please type in 1 or 2 to select the options)");
            input = kb.nextLine();
            if(input.equals("1") || input.equals("2"))
            {
                num = Integer.parseInt(input);
                break;
            }
            else
            {
                System.out.println("Sorry, please type in 1 or 2.");
            }    
        }    
        return num;
    }
    public static void onePlayerMasterBoard()
    {
        while(true)
        {
            for(int i = 0; i < 5; i++)
            {
                player1Deploy();
                athenaDeploy(i);
                if(i != 4)
                {
                    System.out.print("| ");
                    for(int j = i; j >= 0; j--)
                    {
                        System.out.print(player1Troops.get(j) + " | ");    
                    }
                    System.out.print("vs");
                    for(int j = 0; j <= i; j++)
                    {
                        System.out.print(" | " + athenaTroops.get(j));
                    }
                    System.out.println(" |");
                    divider();
                }
            }
            battleResolve1();
            if(player1HP <= 0)
            {
                System.out.println("Athena has won! Please enter any key to exit the game.");
                input = kb.nextLine();
                System.exit(0);
            }
            else if(athenaHP <= 0)
            {
                System.out.println("The player has won! Please enter any key to exit the game.");
                input = kb.nextLine();
                System.exit(0);
            }    
            player1Upkeep();
            athenaUpkeep();
        }
    }
    public static void twoPlayerMasterBoard()
    {
        while(true)
        {
            for(int i = 0; i < 5; i++)
            {
                player1Deploy();
                player2Deploy();
                if(i != 4)
                {
                    System.out.print("| ");
                    for(int j = i; j >= 0; j--)
                    {
                        System.out.print(player1Troops.get(j) + " | ");    
                    }
                    System.out.print("vs");
                    for(int j = 0; j <= i; j++)
                    {
                        System.out.print(" | " + player2Troops.get(j));
                    }
                    System.out.println(" |");
                    divider();
                }
            }
            battleResolve2();
            if(player1HP <= 0)
            {
                System.out.println("The player2 has won! Please enter any key to exit the game.");
                input = kb.nextLine();
                System.exit(0);
            }
            else if(player2HP <= 0)
            {
                System.out.println("The player1 has won! Please enter any key to exit the game.");
                input = kb.nextLine();
                System.exit(0);
            }    
            player1Upkeep();
            player2Upkeep();
        }
    }
    public static void player1Deploy()
    {
        System.out.println("Player1: Deployment");
        while(!appoint)
        {
            System.out.println("Three types of deployable troops:");
            System.out.print("1) Melee - ");
            System.out.println(getMeleeTier(p1MeLevel));
            System.out.print("2) Spear - ");
            System.out.println(getSpearTier(p1SpLevel));
            System.out.print("3) Missile - ");
            System.out.println(getMissileTier(p1MiLevel));
            System.out.println("Melee is effective against Missile, Spear is effective against Melee, and Missile is effective against Melee.");
            System.out.println("Troops in higher tiers are stronger.");
            System.out.println("Type in the number of the troop type you wish to deploy (ex: 1 to deploy a melee unit).");
            System.out.println("Type in \"tip\" (without the \"\") in order to see the chance of one troop type defeating another.");
            input = kb.nextLine();
            if(input.equals("1"))
            {
                String troop = "Me" + getMeleeTier(p1MeLevel).substring(4) + "(p1)";
                player1Troops.add(troop);
                appoint = true; 
            }
            else if(input.equals("2"))
            {
                String troop = "Sp" + getSpearTier(p1SpLevel).substring(4) + "(p1)";
                player1Troops.add(troop);
                appoint = true;
            }
            else if(input.equals("3"))
            {
                String troop = "Mi" + getMissileTier(p1MiLevel).substring(4) + "(p1)";
                player1Troops.add(troop);
                appoint = true;
            }    
            else if(input.equals("tip") || input.equals("Tip") || input.equals("TIP"))
            {
                tip();
            }    
            else
            {
                System.out.println("Sorry, please try again with number 1, 2, or 3.");
            }    
        }
        appoint = false;
        divider();
    }
    public static void player2Deploy()
    {
        System.out.println("Player2: Deployment");
        while(!appoint)
        {
            System.out.println("Three types of deployable troops:");
            System.out.print("1) Melee - ");
            System.out.println(getMeleeTier(p2MeLevel));
            System.out.print("2) Spear - ");
            System.out.println(getSpearTier(p2SpLevel));
            System.out.print("3) Missile - ");
            System.out.println(getMissileTier(p2MiLevel));
            System.out.println("Melee is effective against Missile, Spear is effective against Melee, and Missile is effective against Melee.");
            System.out.println("Troops in higher tiers are stronger.");
            System.out.println("Type in the number of the troop type you wish to deploy (ex: 1 to deploy a melee unit).");
            System.out.println("Type in \"tip\" (without the \"\") in order to see the chance of one troop type defeating another.");
            input = kb.nextLine();
            if(input.equals("1"))
            {
                String troop = "Me" + getMeleeTier(p2MeLevel).substring(4) + "(p2)";
                player2Troops.add(troop);
                appoint = true; 
            }
            else if(input.equals("2"))
            {
                String troop = "Sp" + getSpearTier(p2SpLevel).substring(4) + "(p2)";
                player2Troops.add(troop);
                appoint = true;
            }
            else if(input.equals("3"))
            {
                String troop = "Mi" + getMissileTier(p2MiLevel).substring(4) + "(p2)";
                player2Troops.add(troop);
                appoint = true;
            }    
            else if(input.equals("tip") || input.equals("Tip") || input.equals("TIP"))
            {
                tip();
            }    
            else
            {
                System.out.println("Sorry, please try again with number 1, 2, or 3.");
            }    
        }
        appoint = false;
        divider();
    }
    public static void athenaDeploy(int i)
    {
        double[] odd = new double[3];
        String[] oddStr = {"Me", "Sp", "Mi"};
        Arrays.fill(odd, 0);
        odd[0] += (Character.getNumericValue(getMeleeTier(aMeLevel).charAt(4))-1);
        odd[1] += (Character.getNumericValue(getSpearTier(aSpLevel).charAt(4))-1);
        odd[2] += (Character.getNumericValue(getMissileTier(aMiLevel).charAt(4))-1);
        if(i != 0)
        {
            if(player1Troops.get(i-1).substring(0, 2).equals("Me"))
            {
                odd[0] = 5;
                odd[1] = 7;
                odd[2] = 3;
            }
            if(player1Troops.get(i-1).substring(0, 2).equals("Sp"))
            {
                odd[0] = 3;
                odd[1] = 5;
                odd[2] = 7;
            }
            if(player1Troops.get(i-1).substring(0, 2).equals("Mi"))
            {
                odd[0] = 7;
                odd[1] = 3;
                odd[2] = 5;
            }
        }
        //
        //Calcultes the odd of the previous player's troop defeating the previous athena's troop.
        double x = 0;
        if(i != 0)
        {
            if(player1Troops.get(i-1).substring(0,2).equals("Me"))
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 5;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 3;
                }
                else
                {
                    x = 7;
                }
            }
            else if(player1Troops.get(i-1).substring(0,2).equals("Sp"))
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 7;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 5;
                }
                else
                {
                    x = 3;
                }
            }
            else
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 3;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 7;
                }
                else
                {
                    x = 5;
                }
            }
            //Calculate the odd of current athena's troop dueling the previous player's troop.
            for(int j = 0; j < 3; j++)
            {
                odd[j] = odd[j]*x/10;
            }
            odd[0] += ((Character.getNumericValue(getMeleeTier(aMeLevel).charAt(4))+4)*((10-x)/10));
            odd[1] += ((Character.getNumericValue(getMeleeTier(aMeLevel).charAt(4))+4)*((10-x)/10));
            odd[2] += ((Character.getNumericValue(getMeleeTier(aMeLevel).charAt(4))+4)*((10-x)/10));
        }
        //
        for(int j = 1; j < odd.length; j++)
        {
            for(int k = 0; k < j; k++)
            {
                if(odd[j] > odd[k])
                {
                    double tempInt = odd[k];
                    odd[k] = odd[j];
                    odd[j] = tempInt;
                    String tempStr = oddStr[k];
                    oddStr[k] = oddStr[j];
                    oddStr[j] = tempStr;
                }    
            }    
        }
        Double odd0 = new Double(odd[0]);
        Double odd1 = new Double(odd[1]);
        Double odd2 = new Double(odd[2]);
        String type = "";
        if(odd0.equals(odd1) && odd0.equals(odd2))
        {
            type = oddStr[rand.nextInt(3)];
        }
        else if(odd0.equals(odd1))
        {
            type = oddStr[rand.nextInt(2)];
        }
        else 
        {
            type = oddStr[0];
        }
        if(type.equals("Me"))
        {
            athenaTroops.add("Me" + getMeleeTier(aMeLevel).substring(4) + "(a)");
        }
        else if(type.equals("Sp"))
        {
            athenaTroops.add("Sp" + getSpearTier(aSpLevel).substring(4) + "(a)");
        }
        else
        {
            athenaTroops.add("Mi" + getMissileTier(aMiLevel).substring(4) + "(a)");
        }
    }    
    public static void tip()
    {
        divider();
        System.out.println("TIP:");
        System.out.println("Melee is effective against Missile, Spear is effective against Melee, and Missile is effective against Melee.");
        System.out.println("For troops in the same tier, the chance of winning is described below:");
        System.out.println("Melee  ) 3:7 (  Spear");
        System.out.println("Spear  ) 3:7 (  Missile");
        System.out.println("Missile) 3:7 (  Melee");
        System.out.println("The same troop type have equal chance of defeating one another.");
        System.out.println("For troops that have higher tiers by n (ex: if one troop is tier1, and the other is in tier2, n is 1),");
        System.out.println("the chance becomes a+n:b-n, where a represents the initial number of the higher tiered troop, and b represents the number for the lower tiered troop.");
        System.out.println("For example, if tier4 melee troop battles a tier1 spear troop, n is 4-1=3,");
        System.out.println("meaning the chance is 3+3:7-3 = 6:4, where 6 is for the melee troop and 4 is for the spear troop.");
        System.out.println("During the battle stage of the game, the troops will battle each other in a linear fashion.");
        System.out.println("Any surviving troops will inflect 1 damage to the enemy's base before being dismissed.");
        divider();
    }
    public static void battleResolve1()
    {
        System.out.println("Battle Stage: The two armies will clash for domination");
        int n = 1;
        while(player1Troops.size() > 0 && athenaTroops.size() > 0)
        {
            System.out.print("| ");
            for(int i = player1Troops.size()-1; i >= 0; i--)
            {
                System.out.print(player1Troops.get(i) + " | ");
            }
            System.out.print("vs");
            for(int i = 0; i < athenaTroops.size(); i++)
            {
                System.out.print(" | " + athenaTroops.get(i));
            }
            System.out.println(" |");
            System.out.println();
            System.out.println("Clash No." + n + ":");
            System.out.println("| " + player1Troops.get(0) + " | vs | " + athenaTroops.get(0) + " |");
            int x = 0;
            if(player1Troops.get(0).substring(0,2).equals("Me"))
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 5;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 3;
                }
                else
                {
                    x = 7;
                }
            }
            else if(player1Troops.get(0).substring(0,2).equals("Sp"))
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 7;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 5;
                }
                else
                {
                    x = 3;
                }
            }
            else
            {
                if(athenaTroops.get(0).substring(0,2).equals("Me"))
                {
                    x = 3;
                }
                else if(athenaTroops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 7;
                }
                else
                {
                    x = 5;
                }
            }
            int y = Character.getNumericValue(player1Troops.get(0).charAt(2)) - Character.getNumericValue(athenaTroops.get(0).charAt(2));
            x += y;
            int duel = rand.nextInt(10);
            wait(5000);
            if(x > duel)
            {
                System.out.println("| " + player1Troops.get(0) + " | defeated | " + athenaTroops.get(0) + " | in a duel.");
                athenaTroops.remove(0);
            }
            else
            {
                System.out.println("| " + athenaTroops.get(0) + " | defeated | " + player1Troops.get(0) + " | in a duel.");
                player1Troops.remove(0);
            }    
            n++;
            divider();
        }
        if(player1Troops.size() > 0)
        {
            System.out.print("|");
            for(int i = player1Troops.size() - 1; i >= 0; i--)
            {
                System.out.print(" " + player1Troops.get(i) + " |");   
            }
            System.out.println();
            System.out.println("There are " + player1Troops.size() + " troops left in player1's army.");
            System.out.println("These troops inflect " + player1Troops.size() + " HP damage to Athena's base before being dismissed");
            athenaHP -= player1Troops.size();
            player1Troops.clear();
            System.out.println("Athena's base now has " + athenaHP + " HP left.");
        }
        if(athenaTroops.size() > 0)
        {
            System.out.print("|");
            for(int i = 0; i < athenaTroops.size(); i++)
            {
                System.out.print(" " + athenaTroops.get(i) + " |");   
            }
            System.out.println();
            System.out.println("There are " + athenaTroops.size() + " left in Athena's army.");
            System.out.println("These troops inflect " + athenaTroops.size() + " damage to player1's base before being dismissed");
            player1HP -= athenaTroops.size();
            athenaTroops.clear();
            System.out.println("Player1's base now has " + player1HP + " left.");
        }
        divider();
    }
    public static void battleResolve2()
    {
        System.out.println("Battle Stage: The two armies will clash for domination");
        int n = 1;
        while(player1Troops.size() > 0 && player2Troops.size() > 0)
        {
            System.out.print("| ");
            for(int i = player1Troops.size()-1; i >= 0; i--)
            {
                System.out.print(player1Troops.get(i) + " | ");
            }
            System.out.print("vs");
            for(int i = 0; i < player2Troops.size(); i++)
            {
                System.out.print(" | " + player2Troops.get(i));
            }
            System.out.println(" |");
            System.out.println();
            System.out.println("Clash No." + n + ":");
            System.out.println("| " + player1Troops.get(0) + " | vs | " + player2Troops.get(0) + " |");
            int x = 0;
            if(player1Troops.get(0).substring(0,2).equals("Me"))
            {
                if(player2Troops.get(0).substring(0,2).equals("Me"))
                {
                    x = 5;
                }
                else if(player2Troops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 3;
                }
                else
                {
                    x = 7;
                }
            }
            else if(player1Troops.get(0).substring(0,2).equals("Sp"))
            {
                if(player2Troops.get(0).substring(0,2).equals("Me"))
                {
                    x = 7;
                }
                else if(player2Troops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 5;
                }
                else
                {
                    x = 3;
                }
            }
            else
            {
                if(player2Troops.get(0).substring(0,2).equals("Me"))
                {
                    x = 3;
                }
                else if(player2Troops.get(0).substring(0,2).equals("Sp"))
                {
                    x = 7;
                }
                else
                {
                    x = 5;
                }
            }
            int y = Character.getNumericValue(player1Troops.get(0).charAt(2)) - Character.getNumericValue(player2Troops.get(0).charAt(2));
            x += y;
            int duel = rand.nextInt(10);
            wait(5000);
            if(x > duel)
            {
                System.out.println("| " + player1Troops.get(0) + " | defeated | " + player2Troops.get(0) + " | in a duel.");
                player2Troops.remove(0);
            }
            else
            {
                System.out.println("| " + player2Troops.get(0) + " | defeated | " + player1Troops.get(0) + " | in a duel.");
                player1Troops.remove(0);
            }    
            n++;
            divider();
        }
        if(player1Troops.size() > 0)
        {
            System.out.print("|");
            for(int i = player1Troops.size() - 1; i >= 0; i--)
            {
                System.out.print(" " + player1Troops.get(i) + " |");   
            }
            System.out.println();
            System.out.println("There are " + player1Troops.size() + " troops left in player1's army.");
            System.out.println("These troops inflect " + player1Troops.size() + " HP damage to player2's base before being dismissed");
            player2HP -= player1Troops.size();
            player1Troops.clear();
            System.out.println("Player2's base now has " + player2HP + " HP left.");
        }
        if(player2Troops.size() > 0)
        {
            System.out.print("|");
            for(int i = 0; i < player2Troops.size(); i++)
            {
                System.out.print(" " + player2Troops.get(i) + " |");   
            }
            System.out.println();
            System.out.println("There are " + player2Troops.size() + " left in player2's army.");
            System.out.println("These troops inflect " + player2Troops.size() + " damage to player1's base before being dismissed");
            player1HP -= player2Troops.size();
            player2Troops.clear();
            System.out.println("Player1's base now has " + player1HP + " left.");
        }
        divider();
    }
    public static void wait(int ms)
    {
        try
        {
            Thread.sleep(ms);
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }    
    }    
    public static void player1Upkeep()
    {
        System.out.println("Player1: Upkeep");
        XP = 2;
        while(XP > 0)
        {
            System.out.print("1) Player1's Melee Level: " + p1MeLevel + " / ");
            System.out.println(getMeleeTier(p1MeLevel));
            System.out.print("2) Player1's Spear Level: " + p1SpLevel + " / ");
            System.out.println(getSpearTier(p1SpLevel));
            System.out.print("3) Player1's Missile Level: " + p1MiLevel + " / ");
            System.out.println(getMissileTier(p1MiLevel));
            levelDescription();
            while(!appoint)
            {
                System.out.println("You have " + XP + " XP points. You can type in the number of the troop type you want to develop, followed by a dash and the amount of XP points to assign.");
                System.out.println("For example, in order to assign 2 XP on Melee Level, type 1-2.");
                input = kb.nextLine();
                if(input.length() == 3)
                {
                    if(Character.isDigit(input.charAt(0)) && Character.isDigit(input.charAt(2)))
                    {
                        if(Character.getNumericValue(input.charAt(0)) > 0 && Character.getNumericValue(input.charAt(0)) < 4 && Character.getNumericValue(input.charAt(2)) > 0 && Character.getNumericValue(input.charAt(2)) < 3)
                        {
                            if(Character.getNumericValue(input.charAt(0)) == 1)
                            {
                                p1MeLevel += Character.getNumericValue(input.charAt(2));
                            }
                            else if(Character.getNumericValue(input.charAt(0)) == 2)
                            {
                                p1SpLevel += Character.getNumericValue(input.charAt(2));
                            }
                            else
                            {
                                p1MiLevel += Character.getNumericValue(input.charAt(2));
                            }    
                            XP -= Character.getNumericValue(input.charAt(2));
                            appoint = true;
                        }
                        else
                        {
                            System.out.println("Sorry, please try again using valid numbers (1, 2, or 3 for the troop types, and 1 or 2 for XP invested)");
                        }    
                    }
                    else
                    {
                        System.out.println("Sorry, please try again using the format written in the instruction.");
                    }
                }
                else
                {
                    System.out.println("Sorry, please try again using the format written in the instruction.");
                }
            }
            appoint = false;
        }
        System.out.print("1) Player1's Melee Level: " + p1MeLevel + " / ");
        System.out.println(getMeleeTier(p1MeLevel));
        System.out.print("2) Player1's Spear Level: " + p1SpLevel + " / ");
        System.out.println(getSpearTier(p1SpLevel));
        System.out.print("3) Player1's Missile Level: " + p1MiLevel + " / ");
        System.out.println(getMissileTier(p1MiLevel));
        divider();
    }
    public static void player2Upkeep()
    {
        System.out.println("Player2: Upkeep");
        XP = 2;
        while(XP > 0)
        {
            System.out.print("1) Player2's Melee Level: " + p2MeLevel + " / ");
            System.out.println(getMeleeTier(p2MeLevel));
            System.out.print("2) Player2's Spear Level: " + p2SpLevel + " / ");
            System.out.println(getSpearTier(p2SpLevel));
            System.out.print("3) Player2's Missile Level: " + p2MiLevel + " / ");
            System.out.println(getMissileTier(p2MiLevel));
            levelDescription();
            while(!appoint)
            {
                System.out.println("You have " + XP + " XP points. You can type in the number of the troop type you want to develop, followed by a dash and the amount of XP points to assign.");
                System.out.println("For example, in order to assign 2 XP on Melee Level, type 1-2.");
                input = kb.nextLine();
                if(input.length() == 3)
                {
                    if(Character.isDigit(input.charAt(0)) && Character.isDigit(input.charAt(2)))
                    {
                        if(Character.getNumericValue(input.charAt(0)) > 0 && Character.getNumericValue(input.charAt(0)) < 4 && Character.getNumericValue(input.charAt(2)) > 0 && Character.getNumericValue(input.charAt(2)) < 3)
                        {
                            if(Character.getNumericValue(input.charAt(0)) == 1)
                            {
                                p2MeLevel += Character.getNumericValue(input.charAt(2));
                            }
                            else if(Character.getNumericValue(input.charAt(0)) == 2)
                            {
                                p2SpLevel += Character.getNumericValue(input.charAt(2));
                            }
                            else
                            {
                                p2MiLevel += Character.getNumericValue(input.charAt(2));
                            }    
                            XP -= Character.getNumericValue(input.charAt(2));
                            appoint = true;
                        }
                        else
                        {
                            System.out.println("Sorry, please try again using valid numbers (1, 2, or 3 for the troop types, and 1 or 2 for XP invested)");
                        }
                    }
                    else
                    {
                        System.out.println("Sorry, please try again using the format written in the instruction.");
                    }
                }
                else
                {
                    System.out.println("Sorry, please try again using the format written in the instruction.");
                }
            }
            appoint = false;
        }
        System.out.print("1) Player2's Melee Level: " + p2MeLevel + " / ");
        System.out.println(getMeleeTier(p2MeLevel));
        System.out.print("2) Player2's Spear Level: " + p2SpLevel + " / ");
        System.out.println(getSpearTier(p2SpLevel));
        System.out.print("3) Player2's Missile Level: " + p2MiLevel + " / ");
        System.out.println(getMissileTier(p2MiLevel));
        divider();
    }
    public static void athenaUpkeep()
    {
        System.out.println("Athena: Upkeep");
        System.out.print("1) Athena's Melee Level: " + aMeLevel + " / ");
        System.out.println(getMeleeTier(aMeLevel));
        System.out.print("2) Athena's Spear Level: " + aSpLevel + " / ");
        System.out.println(getSpearTier(aSpLevel));
        System.out.print("3) Athena's Missile Level: " + aMiLevel + " / ");
        System.out.println(getMissileTier(aMiLevel));
        int aMeLevelTemp = aMeLevel;
        int aSpLevelTemp = aSpLevel;
        int aMiLevelTemp = aMiLevel;
        XP = 2;
        int i = 3;
        //i represents the level.
        int n = 3;
        int rowXP = 0;
        boolean[][] XPAppliable = new boolean[3][6];
        for(boolean[] row : XPAppliable)
        {
            Arrays.fill(row, false);
        }    
        while(i <= 10)
        {
            if(aMeLevel == i-1)
            {
                XPAppliable[rowXP][0] = true;
            }
            if(aSpLevel == i-1)
            {
                XPAppliable[rowXP][1] = true;
            }
            if(aMiLevel == i-1)
            {
                XPAppliable[rowXP][2] = true;
            }
            if(aMeLevel == i-2)
            {
                XPAppliable[rowXP][3] = true;
            }
            if(aSpLevel == i-2)
            {
                XPAppliable[rowXP][4] = true;
            }
            if(aMiLevel == i-2)
            {
                XPAppliable[rowXP][5] = true;
            }
            i += n;
            n++;
            rowXP++;
        }
        while(XP > 0)
        {
            for(int j = 2; j >= 0; j--)
            {
                if(XP == 2)
                {
                    if(XPAppliable[j][0] && XPAppliable[j][1] && XPAppliable[j][2])
                    {
                        int typeNot3 = rand.nextInt(3);
                        if(typeNot3 == 0)
                        {
                            aSpLevel++;
                            aMiLevel++;
                        }
                        else if(typeNot3 == 1)
                        {
                            aMeLevel++;
                            aMiLevel++;
                        }
                        else
                        {
                            aMeLevel++;
                            aSpLevel++;
                        }
                        XP -= 2;
                    }
                    else if(XPAppliable[j][0] && XPAppliable[j][1])
                    {
                        aMeLevel++;
                        aSpLevel++;
                        XP -= 2;
                    }
                    else if(XPAppliable[j][1] && XPAppliable[j][2])
                    {
                        aSpLevel++;
                        aMiLevel++;
                        XP -= 2;
                    }
                    else if(XPAppliable[j][0] && XPAppliable[j][2])
                    {
                        aMeLevel++;
                        aMiLevel++;
                        XP -= 2;
                    }
                }
                if(XP > 0)
                {
                    if(XPAppliable[j][0] && XPAppliable[j][1])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aMeLevel++;
                        }
                        else
                        {
                            aSpLevel++;
                        }
                        XP -= 1;
                    }
                    else if(XPAppliable[j][1] && XPAppliable[j][2])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aSpLevel++;
                        }
                        else
                        {
                            aMiLevel++;
                        }
                        XP -= 1;
                    }
                    else if(XPAppliable[j][0] && XPAppliable[j][2])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aMeLevel++;
                        }
                        else
                        {
                            aMiLevel++;
                        }
                        XP -= 1;
                    }
                    else if(XPAppliable[j][0])
                    {
                        aMeLevel++;
                        XP--;
                    }
                    else if(XPAppliable[j][1])
                    {
                        aSpLevel++;
                        XP--;
                    }
                    else if(XPAppliable[j][2])
                    {
                        aMiLevel++;
                        XP--;
                    }
                }
                if(XP == 2)
                {
                    if(XPAppliable[j][3] && XPAppliable[j][4] && XPAppliable[j][5])
                    {
                        int type3 = rand.nextInt(3);
                        if(type3 == 0)
                        {
                            aMeLevel += 2;
                        }
                        else if(type3 == 1)
                        {
                            aSpLevel += 2;
                        }
                        else
                        {
                            aMiLevel += 2;
                        }    
                        XP -= 2;
                    }
                    else if(XPAppliable[j][3] && XPAppliable[j][4])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aMeLevel += 2;
                        }
                        else
                        {
                            aSpLevel += 2;
                        }    
                        XP -= 2;
                    }
                    else if(XPAppliable[j][4] && XPAppliable[j][5])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aSpLevel += 2;
                        }
                        else
                        {
                            aMiLevel += 2;
                        }
                        XP -= 2;
                    }
                    else if(XPAppliable[j][3] && XPAppliable[j][5])
                    {
                        boolean type2 = rand.nextBoolean();
                        if(type2)
                        {
                            aMeLevel += 2;
                        }
                        else
                        {
                            aMiLevel += 2;
                        }
                        XP -= 2;
                    }
                    else if(XPAppliable[j][3])
                    {
                        aMeLevel += 2;
                        XP -= 2;
                    }
                    else if(XPAppliable[j][4])
                    {
                        aSpLevel += 2;
                        XP -= 2;
                    }
                    else if(XPAppliable[j][5])
                    {
                        aMiLevel += 2;
                        XP -= 2;
                    }
                }    
            }
            if(XP == 2)
            {
                int type3 = rand.nextInt(3);
                if(type3 == 0)
                {
                    aMeLevel += 2;
                }
                else if(type3 == 1)
                {
                    aSpLevel += 2;
                }
                else
                {
                    aMiLevel += 2;
                }    
                XP -= 2;
            }
            else if(XP == 1)
            {
                int type3 = rand.nextInt(3);
                if(type3 == 0)
                {
                    aMeLevel += 1;
                }
                else if(type3 == 1)
                {
                    aSpLevel += 1;
                }
                else
                {
                    aMiLevel += 1;
                }    
                XP -= 1;
            }
        }
        wait(2000);
        int aMeLevelDiff = aMeLevel - aMeLevelTemp;
        int aSpLevelDiff = aSpLevel - aSpLevelTemp;
        int aMiLevelDiff = aMiLevel - aMiLevelTemp;
        System.out.println();
        System.out.println("Athena placed her XP points on the following types:");
        if(aMeLevelDiff > 0)
        {
            System.out.println("Melee Level: " + aMeLevelDiff + " XP");
        }
        if(aSpLevelDiff > 0)
        {
            System.out.println("Spear Level: " + aSpLevelDiff + " XP");
        }
        if(aMiLevelDiff > 0)
        {
            System.out.println("Missile Level: " + aMiLevelDiff + " XP");
        }    
        System.out.println();
        System.out.print("1) Athena's Melee Level: " + aMeLevel + " / ");
        System.out.println(getMeleeTier(aMeLevel));
        System.out.print("2) Athena's Spear Level: " + aSpLevel + " / ");
        System.out.println(getSpearTier(aSpLevel));
        System.out.print("3) Athena's Missile Level: " + aMiLevel + " / ");
        System.out.println(getMissileTier(aMiLevel));
        divider();
        wait(2000);
    }    
    public static String getMeleeTier(int level)
    {
        if(level > 0 && level < 3)
        {
            return "Tier1:Club";
        }
        else if(level > 2 && level < 6)
        {
            return "Tier2:Sword";
        }
        else if(level > 5 && level < 10)
        {
            return "Tier3:Longsword";
        }
        else
        {
            return "Tier4:Rapier";
        }    
    }
    public static String getSpearTier(int level)
    {
        if(level > 0 && level < 3)
        {
            return "Tier1:Scythe";
        }
        else if(level > 2 && level < 6)
        {
            return "Tier2:Spear";
        }
        else if(level > 5 && level < 10)
        {
            return "Tier3:Halberd";
        }
        else
        {
            return "Tier4:Pike";
        }    
    }
    public static String getMissileTier(int level)
    {
        if(level > 0 && level < 3)
        {
            return "Tier1:Sling";
        }
        else if(level > 2 && level < 6)
        {
            return "Tier2:Bow";
        }
        else if(level > 5 && level < 10)
        {
            return "Tier3:Crossbow";
        }
        else
        {
            return "Tier4:Musket";
        }    
    }
    public static void levelDescription()
    {
        System.out.println("The level number of a troop type determines the tier and strengh of the troop.");
        System.out.println("Level 1-2: Tier 1 / Level 3-5: Tier 2 / Level 6-9: Tier 3 / Level 10 and up: Tier 4");
        System.out.println("Melee Troop Types: Tier 1 - Club / Tier 2 - Sword / Tier 3 - Longsword / Tier 4 - Rapier");
        System.out.println("Spear Troop Types: Tier 1 - Scythe / Tier 2 - Spear / Tier 3 - Halberd / Tier 4 - Pike");
        System.out.println("Missile Troop Types: Tier 1 - Sling / Tier 2 - Bow / Tier 3 - Crossbow / Tier 4 - Musket");
    }
    public static void divider()
    {
        System.out.println();
        System.out.println("====================================================================================================");
        System.out.println();
    }    
}
