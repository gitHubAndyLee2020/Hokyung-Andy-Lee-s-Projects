
/**
 * helps plan activities
 * 
 * @author (Andy Lee) 
 * @version (1.0)
 */
public class Activities
{
    public static void main()
    {
        Activities d = new Activities("", "", "");
        Activities soccer = new Activities("Soccer", "The individuals will be divided into four teams of 4-6, and play against each other in two different games.\nThe winner and the loser of the games will face each other.", "soccer ball (2)");
        Activities snack = new Activities("Snack", "The individuals will be provided with snacks and have the time to relax and socialize", "snacks (varies on the day)");
        Activities tyDying = new Activities("Shirt tie dying", "Ty dye will set in stations with two colours, \nthe individuals will tie their shirts in the way they prefer, \nand spray the tye paint on the tied shirt. \nThey can have the assistance from the leaders if they wish. \n(The individuals should bring their on shirt)", "Ty dye kits, gloves, extra white shirts (10)");
        Activities geoFlag = new Activities("Flag drawing and presentation", "The individuals can draw the flag of their country \n(The leaders can show pictures of the flags if the individuals need them), \nand present it to others about their flag \nand three things about their country. \nLeaders can provide suggestions. (Or about Canada). \nIf there are extra time, individuals can create their own flag, \npresent three appropriate facts about their fictional country.", "papers, markers, printed pictures of their flags.");
        Activities juniorGeoFlag = new Activities("Fictional Geo Activity", "Individuals can create their own flag and map, \npresent three appropriate facts about their fictional country.", "papers, markers, printed pictures of their flags.");
        Activities waitTime = new Activities("Waiting Time Activity", "While the leaders pick up individuals, \nothers can be occupied with coloring pictures.", "Coloring paper, markers");
        Activities tikTok = new Activities("TikTok dance", "The individuals and the leaders will learn TikTok dances as a group.", "TikTok, electronics");
        //Science experiments
        Activities magicMilk = new Activities("Magic Milk", "Get paper plate,pour milk and food coloring into the plate, \nget cotton swabs, dip it in dish soap, \nand dip the swabs into the milk.", "paper plates (20), cotoon swabs, food coloring, dish soap");
        Activities ziplockEx = new Activities("Ziplock bag experiment", "Fill up the ziplock bag with water, \nseal it, and poke pencils into them.", "Ziplock (20), pens or pencils, water");
        Activities colorEx = new Activities("Color experiment", "The leaders will provide papers with color mix examples, \nwhich the individuals will guess. \nThen they will actually mix colors to confirm.", "Color sheets, cups (6), liquid food color \n(blue, green, red, orange, purple...), water");
        Activities bubbleEx = new Activities("Bubble experiment", "Take sticks and strings to create bubble frame, \nuse them to make big bubbles", "sticks (40), string, bubble making liquid");
        //
        Activities instrumentMaking = new Activities("Making instruments", "The leaders will provide materials for instrument building. \nThe leaders will give presentation and videos of instruments and instrument making. \nThen the indivisuals will get to make their own instrument (percussion or string)", "cleanex boxes, elastic bands, straws, (metal string), bells, tin cans, decorative materials, plastic cups");
        Activities movie = new Activities("Movie", "Watch movie that they choose in their survey, optional trivia for the movie.", "Trivia sheet");
        Activities makeOwnSong = new Activities("Make your own song", "They get to compose their own songs using their own instruments \n(they can choose their teams)). \nChallenges: Make wonky noises. \nAfter, they can present their songs.", "instruments");
        Activities chooseActivity = new Activities("Choose your own activity", "Choices: Board games, coloring, loom bracelet.", "board games, coloring sheets, markers, loom bracelet kit");
        //badminton and frisbee
        Activities decorateFrisbee = new Activities("Decorate Frisbee", "the individuals can decorate their frisbees with the provided materials.", "Paint, frisbees (20), stickers, colored papers");
        Activities badminton = new Activities("Badminton", "The individuals will play badminton in the tennis court.", "badminton rackets (8), birdies (4)");
        Activities frisbeeGolf = new Activities("Frisbee Golf", "Start the teams in different stations, and keep going on stations until the time duration ends.", "Frisbees");
        Activities frisbeeToss = new Activities("Frisbee Toss", "Toss the frisbees to knock set objects, such as waterbottles, down. This can be team competition.", "Frisbees, objects to knock down");
        Activities frisbeeBalance = new Activities("Pool noodle balance frisbee game", "Teams can race with pool noodles with frisbee on top with set objects they have to race to and back. The first team to finish it wins.", "Pool noodles, frisbees, buckets (for marking the racing end point)");
        //
        Activities trivia = new Activities("Trivia", "The individuals will be divided into four groups, \neach group will be given few seconds to discuss the answer \nbefore a leader goes around to check each group's answer.", "Trivia questions sheet");
        Activities riddle = new Activities("Riddle", "The individuals will be divided into four teams and discuss the answer of the riddle in group before guessing. \nRiddles will be read by the leaders.", "Riddle question sheets");
        Activities keepUp = new Activities("Keep Up", "Get individuals in four groups, \nthe groups will have to keep up the ball.", "balls");
        Activities nameBall = new Activities("Name ball", "The individuals gets into a circle, \n the person in the middle throws the ball in the air, \nand the called person has to run up and catch the ball. \nThis will repeat.", "ball");
        Activities tunnelBall = new Activities("Tunnel ball", "Team stand in a line with their legs apart. \nThe person at the front rolls the ball between the legs. \n The person at the end will pick up the ball and run to the front of the line. That will continue as a relay until the finish line.", "ball");
        Activities slime = new Activities("Slime Making", "The individuals will be given separate \nmaterials and a bowl to make slimes.", "shaving cream, contacts solution, glue, glitter, food coloring");
        //
        Activities actBackUp = new Activities("Duck duck goose, simone says, Mr.Wolf", "...", "N/A");
        //
        Activities playground = new Activities("Playground", "...", "N/A");
        Activities videoDance = new Activities("Youtube Dance", "The leaders will put on YouTube or other instructional dance videos \nthat the individuals will dance to.", "N/A");
        Activities danceFollow = new Activities("Dance follow activity", "One person will be in middle of a circle, \nand the other people can copy what the iddle person is dancing. \nThe middle spot can keep switching (appropriate).", "N/A");
        Activities cosmicKids = new Activities("Cosmic Kids", "Leaders can put on cosmic kids videos (yoga).", "N/A");
        Activities danceTraditional = new Activities("Traditional dances", "The individuals will be dancing chicken dance, \nMacarena, and line dances instructed by the leaders.", "N/A");
        Activities story = new Activities("Story building", "Leaders will read the sentence that are provided in the cartoon strip (without pictures), \nand the individuals can either draw pictures or continue on the story.", "N/A");
        //minute to win it game
        Activities nutstacking = new Activities("Nut stacking", "Individuals get a pile of nuts, \nthe individuals can use a pen or pencil to stack the nuts. \nThe individuals who statcks the nuts first gets a point.", "Nuts (not food), pens or pencil");
        Activities catapult = new Activities("Knock block castle hustle", "One team uses a catapult and tries to break down the castle \n(and knock the targets down) that the leaders built \nwhile the other bteam blocks with spoons or popsicle sticks.", "catapult kit, jinga blocks, spoons or popsicle sticks, targets (erasers)");
        Activities cupstacking = new Activities("Cup stacking", "Player stacks cups in a pyramid form \nand has unstack them and put them in front of himself/herself in a stack. \nThe faster person gets a point.", "cups");
        Activities pennyBalancing = new Activities("Penny balancing", "Have the leader set up a ruler on top of a marker, \nthe leaders can put six pennies on one side, \nand the individuals add pennies to the other side to make it balance.", "pennies, ruler, marker");
        Activities oreo = new Activities("Oreo eating", "The individuals will put an oreo on their forehead and try to eat it. \nThe individuals can't eat the dropped oreos, \nbut the leaders can give an oreo to eat.", "N/A");
        Activities cerealPuzzle = new Activities("Cereal box puzzle", "The individuals will be given a bag of cereal boxes puzzles, \nand they have to put it back together within the given time, \nand leaders will record the times.", "Cut up cereal box");
        Activities kleanexHead = new Activities("Kleanex head", "Individuals will be given a kleanex with ping pong balls in it. \nThey will wear the kleanex on their head and try to bring the balls out.", "Kleanex boxes, ping pong balls");
        Activities mentalPuzzle = new Activities("Mental Puzzle", "A leader will give math and riddle questions on the white board, \nand the individuals have to figure out as much puzzles as possible \nwithin the given time. They will be times for solving the problems.", "N/A");
        Activities kickball = new Activities("Kick ball", "The individuals will be playing kickball, \nthere will be four corners, and the other rules are identical to baseball.", "ball, four plates or plastic rings for the posts");
        Activities airplane = new Activities("Air plane building", "The individuals will be provided with papers to build airplanes, \nwhich they will later compete in whose airplane goes the furtest.", "papers, tape, stickers, markers");
        Activities g = new Activities("", "", "");
        //
        System.out.println("Tuesday's plan:");
        System.out.println();
        System.out.println(dayPlan(waitTime,actBackUp,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d));
    }
    private String nameAct;
    private String descriptionAct;
    private String materialsAct;
    public Activities(String nameAct, String descriptionAct, String materialsAct)
    {
        this.nameAct = nameAct;
        this.descriptionAct = descriptionAct;
        this.materialsAct = materialsAct;
    }
    public String toString()
    {
        return nameAct + "\n" + descriptionAct + "\n" + materialsAct + "\n" + "\n";
    }
    public static String dayPlan(Activities actOne, Activities actTwo, Activities actThree, Activities actFour, Activities actFive, Activities actSix, Activities actSeven, Activities actEight, Activities actNine, Activities actTen, Activities actEleven, Activities actTwelve, Activities actThirteen, Activities actFourteen, Activities actFifteen, Activities actSixteen, Activities actSeventeen)
    {
        return "Activity No. 1, time duration: 12:00 - 12:30\n" + actOne + "\nActivity No. 2, Group 1, time duration: 12:30 - 1:00\n" + actTwo + "\nActivity No. 2, Group 2, time duration: 12:30 - 1:00\n" + actThree + "\nActivity No. 3, Group 1, time duration: 1:00 - 1:30\n" + actFour + "\nActivity No. 3, Group 2, time duration: 1:00 - 1:30\n" + actFive + "\nActivity No. 4, Group 1, time duration: 1:30 - 2:00\n" + actSix + "\nActivity No. 4, Group 2, time duration: 1:30 - 2:00\n" + actSeven + "\nActivity No. 5, Group 1, time duration: 2:00 - 2:30\n" + actEight + "\nActivity No. 5, Group 2, time duration: 2:00 - 2:30\n" + actNine + "\nActivity No. 6, Group 1, time duration: 2:30 - 3:00\n" + actTen + "\nActivity No. 6, Group 2, time duration: 2:30 - 3:00\n" + actEleven + "\nActivity No. 7, Group 1, time duration: 3:00 - 3:30\n" + actTwelve + "\nActivity No. 7, Group 2, time duration: 3:00 - 3:30\n" + actThirteen + "\nActivity No. 8, Group 1, time duration: 3:30 - 4:00\n" + actFourteen + "\nActivity No. 8, Group 2, time duration: 3:30 - 4:00\n" + actFifteen + "\nActivity Back-Up\n" + actSixteen + "\nActivity Back-Up\n" + actSeventeen;
    }
}
