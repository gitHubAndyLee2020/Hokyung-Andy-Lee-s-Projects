import java.util.Scanner;
import java.util.Random;
/**
 * 여기에 TrialsofOlympus 클래스 설명을 작성하십시오.
 * 
 * @author (작성자 이름) 
 * @version (버전번호나 날짜)
 */
public class TrialsofOlympus
{
    // 인스턴스 변수 - 다음의 예제를 사용자에 맞게 바꾸십시오
    private int x;

    
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    static String input = "";
    static String name = "";
    static int i = 0;
    static int waterlevel = 0;
    static int questionsanswered = 0;
    static boolean introstage1 = false;
    static boolean lookroom1 = false;
    static boolean torch = false;
    static boolean lookroom = false;
    static boolean looksword = false;
    static boolean sword = false;
    static boolean Python = true;
    static boolean done = false;
    static boolean chain = true;
    static boolean watchchain = false;
    static boolean lookchain = false;
    static boolean keyword1 = false;
    static boolean stage2 = false;
    static boolean introstage2 = false;
    static boolean lookroom2 = false;
    static boolean closeeyes = false;
    static boolean Medusa = true;
    static boolean headofMedusa = false;
    static boolean talktoowl = false;
    static boolean lookatstatue = false;
    static boolean branch = false;
    static boolean helmet = false;
    static boolean grabhelmet = false;
    static boolean shield = false;
    static boolean Athena = false;
    static boolean keyword2 = false;
    static boolean stage3 = false;
    static boolean introstage3 = false;
    static boolean lookroom3 = false;
    static boolean solvequestions = false;
    static boolean talktoturtle = false;
    static boolean trident = false;
    static boolean Poseidonadvice = false;
    static boolean lookhatch = false;
    static boolean lookholes = false;
    static boolean keyword3 = false;
    static boolean stage4 = false;
    static boolean introstage4 = false;
    static boolean lookroom4 = false;
    static boolean Phobos = true;
    static boolean panic = false;
    static boolean potionpanic = false;
    static boolean potiongod = false;
    static boolean offense = false;
    static boolean defense = false;
    static boolean flee = false;
    static boolean Asclepiusintro = false;
    static boolean vile = false;
    static boolean Ares = true;
    static boolean bident = false;
    static boolean removestone = false;
    static boolean lookpassage = false;
    static boolean lookstone = false;
    static boolean stage5 = false;
    static int arrows = 0;
    static int HP = 200;
    static int HPPython = 20;
    static int HPPhobos = 120;
    static int HPAres = 200;
    static int pt = 0;
    public static void main()
    {
        System.out.println("Welcome to the game 'Trials of Olympus', a fasnating escape-room styled RPG that takes place in the world of Greek Mythology.");
        System.out.println("Once upon a time, the Gods of the Olympus ruled the world in peace and justice.");
        System.out.println("But when a group of rebel gods released the evil creatures from the depth of Tartarus, the monsters ambused the Mount Olympus and captured the gods.");
        System.out.println("With the gods nullified, the world fell in chaos. You, a great hero, is determined to bring order back to the world by rescuing the gods.");
        System.out.println("Your ultimate goal is to rescue the king of the god from the most powerful monster that arose from Tartarus. There are 8 stages in total.");
        System.out.println("Basic commands are (9 in total): 'look at', 'use', 'open', 'grab', 'talk to', 'duel', 'strike with', 'flee', 'buy'.");
        System.out.println("All usable objects in the room will be inside '' mark. They will also be written inside brackets beside the lines.");
        System.out.println("Use commands like this: command + object name (ex: look at room) / type 'duel' + subject to fight, then use 'strike with' or 'flee' during combat.");
        System.out.println("The combat will continue until you type in 'flee'. (Use 'flee' without objects)");  
        System.out.println("Type 'inventory' to look at the objects and equipments you have discovered so far. Type 'market' to purchase equipments. ('inventory', 'market')");
        System.out.println("Are you ready to start the game and save Olympus from the evil? (yes / no)");
        input = kb.nextLine();
        if(input.equals("yes") || input.equals("Yes") || input.equals("yep") || input.equals("Yep"))
        {
            System.out.println("Excellent! Let the game begin.");
            System.out.println("Remember, 'look at' works for all objects/subjects, and 'talk to' works for every subject. use 'open' for any type of doors.");
            System.out.println("In this game, you are permitted to use commands on the same object multiple times. (in most cases)");
            System.out.println("Enter your hero's name.");
            name  = kb.nextLine();
            stage1();
        }
        else
        {
            System.exit(0);
        }
    }
    public static void stage1()
    {
        if(!introstage1)
        {
            System.out.println("You enter the Mount Olympus through a dark cave in the dark side of the mountain. Good luck, hero " + name + ".");
            System.out.println("You start with 200 HP, and you lose the game when you have 0 HP left.");
            System.out.println("You start with 0 pt, and you can buy equipments in 'market' when you obtain enough points during the game.");
            System.out.println("'stage1': Cave of Apollo (God of Prophecy) - Use 'room'. ('room')");
            introstage1 = true;
        }
        i = 1;
        while(true)     
        {
            System.out.println("What is your command?");
            input = kb.nextLine();
            if(input.equals("look at room") || input.equals("look at the room"))
            {
                if(!torch)
                {
                    System.out.println("You see a dark cave with a 'torch' hanging on the wall and a 'boulder' slumped against the side. ('torch', 'boulder')");
                    lookroom1 = true;
                }
                else if(Python)
                {
                    System.out.println("You see a cave with the god 'Apollo' and a 'gate' located at the far end, guarded by the great snake 'Python'. ('Python', 'Apollo', 'gate', 'boulder' (also 'torch')");
                    lookroom = true;
                }
                else if(!Python)
                {
                    System.out.println("You see a cave with the god 'Apollo' and a 'gate' at the far side of the cave. ('Apollo', 'gate', 'boulder', (also 'torch', 'Python')");
                }
            }    
            else if(input.equals("look at torch") || input.equals("look at the torch"))
            {
                if(!torch)
                {
                    System.out.println("It's a blackened wood stick that ceased burning long time ago. But it looks ignitable if you 'use' it.");
                }
                else if(torch)
                {
                    System.out.println("It's a wood stick burning with intense fire that lights the cave.");   
                }
            }
            else if(input.equals("use torch") || input.equals("use the torch"))
            {
                if(!torch)
                {
                    System.out.println("The torch ignits in a red spark and you can now 'look at' the 'room' and see your surrounding.");
                    torch = true;
                }
                else if(torch)
                {
                    System.out.println("You have already ignited the torch.");   
                }
            }
            else if(input.equals("look at boulder") || input.equals("look at the boulder"))
            {
                if(!sword)
                {
                    System.out.println("It's a large stone with a 'sword' embedded into it. ('sword')");
                    looksword = true;
                }
                else if(sword)
                {
                    System.out.println("It's a stone that used to hold the 'sword' that now hangs in your belt.");
                }
            }    
            else if(input.equals("look at sword") || input.equals("look at the sword"))
            {
                if(!sword)
                {
                    System.out.println("It's a bronze sword that is embedded deep into the 'boulder', waiting to be pulled out by a Hero.");
                }
                else if(sword)
                {
                    System.out.println("It's a short, bronze sword that hangs on your belt. The edges look sharp enough to slice a stone apart.");
                }
            }
            else if(input.equals("grab sword") || input.equals("grab the sword"))
            {
                if(!sword)
                {
                    System.out.println("You pull the bronze 'sword' out of the 'boulder' and place it into your belt. You may use it in various situations such as combat.");
                    sword = true;
                }
                else if(sword)
                {
                    System.out.println("You have already pulled the 'sword' out of the 'boulder'.");
                }
            }
            else if(input.equals("look at Python") || input.equals("look at the Python") || input.equals("look at python") || input.equals("look at the python"))
            {
                if(Python)
                {
                    System.out.println("It's a enormous snake that is slittering on the cavern floor, guarding 'Apollo' and the 'gate' from you.");
                }
                else if(!Python)
                {
                    System.out.println("You have already destroyed Python, and it is now gone");
                }
            }
            else if(input.equals("talk to Python") || input.equals("talk to the Python") || input.equals("talk to python") || input.equals("talk to the python"))
            {
                if(Python)
                {
                    System.out.println("Python: Ha! the appetizer has come before my main meal Apollo. Confront me if you are brave enough! (then hisses)");
                }
                else if(!Python)
                {
                    System.out.println("You cannot talk to Python, as for it is now deceased.");
                }
            }
            else if(input.equals("duel Python") || input.equals("duel the Python") || input.equals("duel python") || input.equals("duel the python"))
            {
                if(Python)
                {
                    System.out.println("As you stand in front of the great snake, it lunges at you with its mouth open. It has " + HPPython + " HP.");
                    done = false;
                    while(!done)
                    {
                        System.out.println("What is your action?");
                        input = kb.nextLine();
                        int rand1 = rand.nextInt(2);
                        if(input.equals("strike with sword") || input.equals("strike with the sword"))
                        {
                            if(!sword)
                            {
                                System.out.println("You do not posess a 'sword' to strike with.");
                            }
                            else if(sword)
                            {
                                 System.out.println("You raise your newly found weapon as Python attempts to bite you.");
                                 System.out.println("Type one of the two regions to attack ('head' / 'belly')");
                                 input = kb.nextLine();
                                 if(rand1 >= 1)
                                 {
                                     if(input.equals("head"))
                                     {
                                         System.out.println("As the snake drove its open mouth to devour you, you slash it across it's face, dealing -10 HP to it.");
                                         HPPython = HPPython - 10;
                                         System.out.println("Now it has " + HPPython + " HP left.");
                                         if(HPPython <= 0)
                                         {
                                            System.out.println("Python is killed, and it falls to the ground and turns into a pile of dust.");
                                            Python = false;
                                            System.out.println("You gain +100 pt for destroying Python.");
                                            pt = pt + 100;
                                            System.out.println("You now have " + pt + " pt.");
                                            done = true;
                                         }
                                     }
                                     else if(input.equals("belly"))
                                     {
                                         System.out.println("As you tried to stab the snake, it bites you with its enormous fangs and deals -10 HP to you.");
                                         HP = HP - 10;
                                         System.out.println("You now have " + HP + " HP left.");
                                         if(HP <= 0)
                                         {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                         }
                                     }
                                 }
                                 else if(rand1 <= 0)
                                 {
                                     if(input.equals("belly"))
                                     {
                                         System.out.println("You stab Python's belly as it turned around in front of you. You deal a fatal -20 Hp to the snake.");
                                         HPPython = HPPython - 20;
                                         System.out.println("Now it has " + HPPython + " HP left.");
                                         if(HPPython <= 0)
                                         {
                                             System.out.println("Python is killed, and it falls to the ground and turns into a pile of dust.");
                                             Python = false;
                                             System.out.println("You gain +100 pt for destroying Python.");
                                             pt = pt + 100;
                                             System.out.println("You now have " + pt + " pt.");
                                             done = true;
                                         }
                                     }
                                     else if(input.equals("head"))
                                     {
                                        System.out.println("As you tried to slash Python's head, it turns away from you.");
                                     }
                                 }
                            }
                        }    
                        else if(input.equals("flee"))
                        {
                            System.out.println("You run away from Python just in time to escape its fangs. THe fight is over for now.");
                            done = true;
                        }
                        else
                        {
                            System.out.println("That action does not work. Please try another action, or choose to 'flee'.");
                        }    
                    }
                    done = false;
                }
                else if(!Python)
                {
                    System.out.println("You cannot duel Python, as for it is now deceased.");
                }
            }
            else if(input.equals("look at Apollo") || input.equals("look at apollo"))
            {
                if(Python)
                {
                    System.out.println("You notice that the god is tied to a rock when 'Python' slitters in front of 'Apollo' to guard him.");
                }
                else if(chain)
                {
                    System.out.println("He is a dashing god that glows in gold, except that he is tied to a rock.");
                }
                else if(!chain)
                {
                    System.out.println("He is a handsome god that is standing next to the 'gate', looking at you with his warm, golden eyes.");
                }
            }
            else if(input.equals("talk to Apollo") || input.equals("talk to apollo"))
            {
                if(Python)
                {
                    System.out.println("Apollo tries to speak with you, but the hissing noise of 'Python' muffles his sound.");
                }
                else if(chain)
                {
                    System.out.println("Apollo: Thank thou, " + name + ", for killing that evil snake. It would also be grateful if thou freed me from tis' 'chain' I'm bound to. ('chain')");
                    watchchain = true;
                }
                else if(!chain)
                {
                    System.out.println("Apollo: In order for thou to enter the wisdom god's chamber, you need to pass my prophecy. (Each _ represents a letter, combine all _ to make a password)");
                    System.out.println("Apollo: Through _oards of creatures / Shall a warrior _merge / F_om the swift blade's departure / Greatest _f evil must purge");
                    System.out.println("Apollo: Thou should remember tis' password, as for it shall help thou to continue on thy way.");
                    keyword1 = true;
                }
            }
            else if(input.equals("look at chain") || input.equals("look at the chain"))
            {
                if(chain)
                {
                    System.out.println("It's an iron 'chain' that seems to be breakable if you would striked it with a sharp object.");
                    lookchain = true;
                }
                else if(!chain)
                {
                    System.out.println("The 'chain' is broken, and the god 'Apollo' is free.");
                }
            }
            else if(input.equals("open chain") || input.equals("open the chain"))
            {
                if(chain)
                {
                    System.out.println("you need to strike it with one of your sharp equipments to open it.");
                    lookchain = true;
                }
                else if(!chain)
                {
                    System.out.println("The 'chain' is broken, and the god 'Apollo' is free.");
                }
            }
            else if(input.equals("strike with sword") || input.equals("strike with the sword") || input.equals("use sword") || input.equals("use the sword"))
            {
                 if(lookchain)
                 {
                     System.out.println("You swing your 'sword' at the 'chain' and it shatters into pieces. 'Apollo' is now free.");
                     chain = false;
                 }
            }
            else if(input.equals("look at gate") || input.equals("look at the gate") || input.equals("open gate") || input.equals("open the gate"))
            {
                if(!Python)
                {
                    if(!stage2)
                    {
                        System.out.println("It's an old wooden 'gate' that requires a four-letter password to open. (type in the password in lower case)");
                        input = kb.nextLine();
                        if(input.equals("hero"))
                        {
                            System.out.println("The 'gate' clicks open, and you may now enter the next stage.");
                            System.out.println("You may use 'stage1' to come back to this stage, and 'stage2' to move to the next stage. ('stage1', 'stage2')");
                            stage2 = true;
                        }
                        else
                        {
                            System.out.println("You have entered the wrong password. Please try again, or come back after you have found the proper password.");
                        }
                    }
                    else if(stage2)
                    {
                        System.out.println("The gate is already open, and you can move on to the next stage. ('stage2')");
                    }
                }
                else if(Python)
                {
                    System.out.println("As you tried to look closer at the gate and attempt to reach it, Python slittered in front of you to block you from the gate.");
                }
            }    
            else if(input.equals("inventory") || input.equals("Inventory"))
            {
                 inventory();
            }
            else if(input.equals("market") || input.equals("Market"))
            {
                 market();
            }
            else if(input.equals("stage2"))
            {
                 if(stage2)
                 {
                     System.out.println("You walk through the 'gate' and enter the next stage.");
                     stage2();
                 }
                 else
                 {
                     System.out.println("You haven't opened the 'gate' yet.");
                 }
            }  
            else
            {
                 System.out.println("Sorry, you cannot do that. Please try something else.");
            }
        } 
    } 
    public static void stage2()
    { 
        if(!introstage2)
        {
            System.out.println("'stage2': Chamber of Athena (Goddess of Wisdom) - Use 'room'. ('room')");
            introstage2 = true;
        }   
        i = 2;
        while(true)     
        {
            System.out.println("What is your command?");
            input = kb.nextLine();
            if(input.equals("look at room") || input.equals("look at the room"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("You see an enormous chamber with 'statue' of Athena at the far end, with a 'door' behind it.");
                        System.out.println("In front of the 'statue' and the 'door', there is a 'mirror' and an 'owl', which are both guarded by 'Medusa'. ('statue', 'door', 'mirror', 'owl', 'Medusa')");
                    }
                    else if(closeeyes)
                    {
                        System.out.println("You cannot see anything, as for you have closed your eyes.");
                    }    
                }
                else if(!Athena)
                {
                    System.out.println("You see an enormous chamber with a 'statue', a 'mirror', an 'owl', and a 'door' behind the looming statue. ('statue', 'mirror', 'owl', 'door')");
                }
                else if(Athena)
                {
                    System.out.println("You see an enormous chamber with a 'statue', a 'mirror', a 'door', and the goddess 'Athena' standing proudly. ('statue', 'mirror', 'Athena', 'door')");
                }
            }
            else if(input.equals("look at mirror") || input.equals("look at the mirror") || input.equals("use mirror") || input.equals("use the mirror"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("You see the reflection of the monster 'Medusa' and her bloodshot eyes that turns living things into stones.");
                        System.out.println("Since you cannot be turned into a stone if you close your eyes while facing 'Medusa', you close your eyes.");
                        System.out.println("However, you can still picture the position of 'Medusa' and have the instict ability to fight with your eyes closed.");
                        System.out.println("Because of the fear that you may be turned into a stone, you continue to close your eyes.");
                        closeeyes = true;
                    }
                    else if(closeeyes)
                    {
                        System.out.println("You closed your eyes, so you cannot see the mirror.");
                    }    
                }
                else if(!Athena)
                {
                    System.out.println("Only thing you see in the mirror is the 'statue' of Athena, an 'owl', and a 'door' behind the looming statue.");
                }
                else if(Athena)
                {
                    System.out.println("You see the beautiful yet furious goddess 'Athena' in the mirror, along with her 'statue' and a 'door'.");
                }
            }
            else if(input.equals("look at Medusa") || input.equals("look at medusa"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("'Medusa' is a green gorgon with leathery skin, snakes instead of hair, and bloodshot eyes.");
                        System.out.println("But as you look into the eyes of 'Medusa', its deathly gaze starts turning you into a stone.");
                        System.out.println("You turn away just in time to avoid this, but you receive a great damage of -40HP.");
                        HP = HP - 40;
                        System.out.println("You now have " + HP + " HP left.");
                        if(HP <= 0)
                        {
                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    else if(closeeyes)
                    {
                        System.out.println("You closed your eyes, so you manage to avoid looking at the deadly glare of 'Medusa'.");
                    }
                } 
                else if(!Medusa)
                {
                    System.out.println("You cannot look at Medusa, as for it is deceased and turned into a pile of dust.");
                }
            }
            else if(input.equals("talk to Medusa") || input.equals("talk to medusa"))
            {
                if(Medusa)
                {
                    System.out.println("You try to talk to 'medusa', but she hisses at you in unreconizable, evil language.");
                }
                else if(!Medusa)
                {
                    System.out.println("You cannot talk to 'Medusa', as for she is deceased.");
                }
            }
            else if(input.equals("duel Medusa") || input.equals("duel medusa"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("As you try to face 'Medusa', its deathly gaze starts turning you into a stone.");
                        System.out.println("You run away just in time to avoid this, but you receive a great damage of -40HP.");
                        HP = HP - 40;
                        System.out.println("You now have " + HP + " HP left.");
                        if(HP <= 0)
                        {
                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    else if(closeeyes)
                    {
                        while(!done)
                        {
                            System.out.println("What is your action?");
                            input = kb.nextLine();
                            if(input.equals("strike with sword") || input.equals("strike with the sword"))
                            {
                                System.out.println("As you keep your eyes closed, you charge at the direction of 'Medusa', brandishing your 'sword'.");
                                System.out.println("Type one of the two regions to slash ('neck' / 'torso')");
                                input = kb.nextLine();
                                if(input.equals("neck"))
                                {
                                    System.out.println("With the predise strike with your sword, you decapitate 'Medusa'.");
                                    System.out.println("'Medusa' is now dead, and it's body crumbles to a pile of dust.");
                                    System.out.println("However, the 'head' of the 'Medusa' falls to the ground, and by using your ears as the guide, you grab the 'head'.");
                                    System.out.println("You place the 'head' in a bag and keep it. From relieve, you open your eyes.");
                                    closeeyes = false;
                                    Medusa = false;
                                    System.out.println("You gain +300 pt for killing 'Mudusa'.");
                                    pt = pt + 300;
                                    System.out.println("You now have " + pt + " pt.");
                                    done = true;
                                    headofMedusa = true;
                                }
                                else if(input.equals("torso"))
                                {
                                    System.out.println("As you tried to slash the torso of the gorgon, it quickly dodges and slashes you with its long nail, dealing -20 HP damage."); 
                                    HP = HP - 20;
                                    System.out.println("You now have " + HP + " HP left.");
                                    if(HP <= 0)
                                    {
                                        System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                        input = kb.nextLine();
                                        while(true)
                                        {
                                            if(input.equals("end") || input.equals("End"))
                                            {
                                                System.exit(0);
                                            }
                                            else
                                            {
                                                System.out.println("You typed in the wrong word. Please type in 'end'.");
                                            }    
                                        }
                                    }
                                }
                            }
                            else if(input.equals("flee"))
                            {
                                System.out.println("You run away from 'Medusa'. The fight is over for now.");
                                done = true;
                            }
                            else
                            {
                                System.out.println("That action does not work. Please try another action, or choose to 'flee'.");
                            }
                        }
                        done = false;
                    }   
                }
                else if(!Medusa)
                {
                    System.out.println("You cannot duel 'Medusa', as for she is deceased and turned into a pile of dust.");
                }
            }
            else if(input.equals("look at head") || input.equals("look at the head"))
            {
                if(!Medusa)
                {
                    if(headofMedusa)
                    {
                        System.out.println("You take the 'head' of the Medusa out of your bag.");
                        System.out.println("Unfortuately, the deadly stare of the decapitated 'head' still causes -20HP to you.");
                        HP = HP - 20;
                        System.out.println("You now have " + HP + " HP left.");
                        if(HP <= 0)
                        {
                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    else if(!headofMedusa)
                    {
                        System.out.println("The decapitated 'head' of 'Medusa' is held in front of the 'shield' you grabbed earlier.");
                    }
                }
                else if(Medusa)
                {
                    System.out.println("You have not decapitated 'Medusa' yet.");
                } 
            }
            else if(input.equals("look at owl") || input.equals("look at the owl"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("You try to look at the grey owl, but Medusa steps into the view and you look away.");
                    }
                    else if(closeeyes)
                    {
                        System.out.println("Your eyes are closed, and you can't see anything.");
                    }
                }
                else if(!Athena)
                {
                    System.out.println("It is a beautiful grey owl that has a face that oddly resembles the face of the 'statue' of Athena.");   
                }
                else if(Athena)
                {
                    System.out.println("The owl is now gone, as for it transformed into the goddess 'Athena'.");   
                }
            }
            else if(input.equals("talk to owl") || input.equals("talk to the owl"))
            {
                if(Medusa)
                {
                    System.out.println("You try talking to the owl, but all it does is squeal at 'Medusa'.");
                }
                else if(!Athena)
                {
                    System.out.println("owl: I have been cursed and shapeshifted into the form of an owl, and I need you to lift this curse.");
                    System.out.println("owl: Offer me one of the objects you posess with you, and I will transform into my true form and be able to help you on your quest.");
                    System.out.println("Type the name of one of the objects you posess to offer it to the owl. (ex: handkerchief / (in lowercase))");
                    talktoowl = true;
                }
                else if(Athena)
                {
                    System.out.println("You cannot talk to the owl, as for it transformed into the goddess 'Athena'.");   
                }
            }
            else if(input.equals("branch"))
            {
                if(!branch)
                {
                    System.out.println("You have not obtained the 'branch' from the 'statue' yet.");
                }
                else if(!Athena)
                {
                    System.out.println("The 'owl' just awkwardly looks at the 'branch'. You need to offer a different object.");
                }
                else if(Athena)
                {
                    System.out.println("You cannot offer the olive 'branch', as for the owl had already turned into the goddess 'Athena'.");
                }
            }
            else if(input.equals("helmet"))
            {
                if(!helmet)
                {
                    System.out.println("You have not obtained the 'helmet' from the 'statue' yet.");
                }
                else if(!Athena)
                {
                    System.out.println("You offer the golden 'helmet' to the 'owl', and as the 'owl' wears the 'helmet', it transforms into 'Athena', the mighty goddess.");
                    System.out.println("You lost the possession of the 'helmet', as for you have offered it to the goddess.");
                    System.out.println("Athena: Thank you my hero, for lifting off my curse. ('Athena' - you may need to talk to her for advice)");
                    Athena = true;
                    helmet = false;
                }    
            }
            else if(input.equals("look at Athena") || input.equals("look at athena"))
            {
                if(!Athena)
                {
                    System.out.println("You cannot look at 'Athena', as for she is still in the form of an 'owl'.");
                }
                else if(Athena)
                {
                    System.out.println("She is a beautiful and intelligent goddess that is dressed in full armour."); 
                    System.out.println("It seems like she can provide you with advices to continue on with your journey.");
                }
            }
            else if(input.equals("talk to Athena") || input.equals("talk to athena"))
            {
                if(!Athena)
                {
                    System.out.println("You cannot talk to 'Athena', as for she is still in the form of an 'owl'.");
                }
                else if(Athena)
                {
                    System.out.println("Athena: I shall give you the clue to help you continue on your way. But you'll need to solve it yourself.");
                    System.out.println("Athena: a n s t d (unscramble the word to make a password)");
                    keyword2 = true;
                }    
            }
            else if(input.equals("shield"))
            {
                if(!shield)
                {
                    System.out.println("You have not obtained the 'shield' from the 'statue' yet.");
                }
                else if(!Athena)
                {
                    System.out.println("The Owl becomes frightened by the look of the Medusa head on the shield. You need to offer a different object.");
                }
                else if(Athena)
                {
                    System.out.println("You cannot offer the 'shield', as for the owl had already turned into the goddess 'Athena'.");
                }
            }
            else if(input.equals("sword"))
            {
                if(!Athena)
                {
                    System.out.println("You offer the 'owl' your sword, but it cannot even grab it with its feet. You need to offer a different object.");
                }
                else if(Athena)
                {
                    System.out.println("You cannot offer the 'sword', as for the owl had already turned into the goddess 'Athena'.");
                }
            }
            else if(input.equals("look at statue") || input.equals("look at the statue"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("It's a beautiful ivory-gold statue that is looming over the chamber. Unfortunatly, 'Medusa' blocks your way as you try to approach the glorious 'statue'.");
                    }
                    else if(closeeyes)
                    {
                        System.out.println("Your eyes are closed, and you can't see anything.");
                    }
                }
                else if(!Athena)
                {
                    System.out.println("It's a beautiful, ivory-gold 'statue' of the goddess Athena that is looming over the chamber with its powerful aura."); 
                    System.out.println("It may hold the following objects (unless you've already taken them), which you are permitted to take.");
                    lookatstatue = true;
                    if(!branch)
                    {
                        System.out.println("An olive 'branch', which is held by the left hand of the 'statue'. ('branch')");
                    }
                    if(!grabhelmet)
                    {
                        System.out.println("A golden war 'helmet', worn by the 'statue'. ('helmet')");
                    }
                    if(!shield)
                    {
                        System.out.println("A 'shield', which is held by the right hand of the 'statue'. ('shield')");
                    }
                    else
                    {
                        System.out.println("You look for further objects, but you have taken all of them.");
                    }
                }
            }
            else if(input.equals("grab branch") || input.equals("grab the branch"))
            {
                if(lookatstatue)
                {
                    System.out.println("You reach for the olive 'branch' and put it in your pocket. You may need it later.");
                    branch = true;
                }
                else if(!lookatstatue)
                {
                    System.out.println("You need to look at the 'statue' to know where to grab objects from.");
                }
                else if(branch)
                {
                    System.out.println("You already grabbed the 'branch' from the 'statue'.");
                }
            }
            else if(input.equals("grab helmet") || input.equals("grab the helmet"))
            {
                if(lookatstatue)
                {
                    System.out.println("You reach for the golden 'helmet' and hold it by your side, as you may need it later.");
                    helmet = true;
                    grabhelmet = true;
                }
                else if(!lookatstatue)
                {
                    System.out.println("You need to look at the 'statue' to know where to grab objects from.");
                }
                else if(grabhelmet)
                {
                    System.out.println("You already grabbed the 'helmet' from the 'statue'.");
                }
            }
            else if(input.equals("grab shield") || input.equals("grab the shield"))
            {
                if(lookatstatue)
                {
                    System.out.println("You grab the 'shield' from the hand of the 'statue', and attach the 'head' of Medusa onto it. You throw the shield's sling over your back.");
                    System.out.println("You may use this in combat situations, just type (use shield / strike with shield) in combat if you wish to use shield instead of other weapons."); 
                    shield = true;
                    headofMedusa = false;
                }
                else if(!lookatstatue)
                {
                    System.out.println("You need to look at the 'statue' to know where to grab objects from.");
                }
                else if(shield)
                {
                    System.out.println("You already grabbed the 'shield' from the 'statue'.");
                }
            }
            else if(input.equals("look at branch") || input.equals("look at the branch"))
            {
                if(!branch)
                {
                    System.out.println("It's an olive branch held by the left hand of the 'statue'");
                }    
                else if(branch)
                {
                    System.out.println("It's a simple olive 'branch', you remember that olive branch is the symbol for life and victory.");
                }
            }
            else if(input.equals("look at helmet") || input.equals("look at the helmet"))
            {
                if(!grabhelmet)
                {
                    System.out.println("It's a golden 'helmet' worn by the 'statue'.");
                }    
                else if(grabhelmet)
                {
                    if(helmet)
                    {
                        System.out.println("It's a golden 'helmet' worn by the goddess Athena. It looks naturally fitting to the 'owl' in the chamber."); 
                    }
                    else if(!helmet)
                    {
                        System.out.println("You already offered the golden 'helmet' and you do not possess it anymore.");   
                    }    
                } 
            }
            else if(input.equals("look at shield") || input.equals("look at the shield"))
            {
                if(!shield)
                {
                    System.out.println("It's a bronze shield that the 'statue' of Athena is holding with its right hand.");
                }    
                else if(shield)
                {
                    System.out.println("It's a shiny bronze 'shield' that has the head of 'Medusa' attached to it. (it's greek name is Aegis, the shield of Zeus that Athena often use)");
                    System.out.println("Unfortunately, you mistakenly makes eye contact with the beheaded heah of 'Medusa' and recieve -20 HP damage.");
                    HP = HP - 20;
                    System.out.println("You now have " + HP + " HP left.");
                    if(HP <= 0)
                    {
                        System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                        input = kb.nextLine();
                        if(input.equals("end") || input.equals("End"))
                        {
                            System.exit(0);
                        }
                    }
                }  
            }
            else if(input.equals("look at door") || input.equals("look at the door") || input.equals("open door") || input.equals("open the door"))
            {
                if(Medusa)
                {
                    if(!closeeyes)
                    {
                        System.out.println("As you tried to approach the 'door', 'Medusa' blocks your way and you turn your head around.");
                    }
                    else if(closeeyes)
                    {
                        System.out.println("You closed your eyes, so you cannot see anything.");
                    }
                }
                else if(!stage3)
                {
                    System.out.println("It's a marble hinge 'door' that is elegantly decorated with scultures of mythical figures.");
                    System.out.println("It requires a five-letter password to open. (enter it in lowercase)");
                    input = kb.nextLine();
                    if(input.equals("stand"))
                    {
                        System.out.println("The 'door' makes a creaking noise and opens by spliting into half.");
                        System.out.println("You may use 'stage1' and 'stage2' to come back to previous stages, and 'stage3' to move to the next stage. ('stage1', 'stage2', 'stage3')");
                        stage3 = true;
                        System.out.println("As you opened the 'door', Athena turns to you and starts speaking with her rich voice.");
                        System.out.println("Athena: You have met two friendly gods so far, but the next one will not be so polite.");
                        System.out.println("Athena: The god in the next chamber will be very angry with you sending his former love, 'Medusa', straight back to Tartarus.");
                        System.out.println("Athena: But do not worry my hero. I'll be watching over you. (Athena then walks away to stand beside her 'statue')");
                    }
                    else
                    {
                        System.out.println("You have entered the wrong password. Please try again, or come back after you have found the proper password.");
                    }
                }
                else if(stage3)
                {
                    System.out.println("The door is already open.");
                }
            }
            else if(input.equals("inventory") || input.equals("Inventory"))
            {
                 inventory();
            }
            else if(input.equals("market") || input.equals("Market"))
            {
                 market();
            }
            else if(input.equals("stage1"))
            {
                 System.out.println("You walk back through the 'gate' and into the previous stage.");
                 stage1();
            }
            else if(input.equals("stage3"))
            {
                 if(stage3)
                 {
                     System.out.println("You walk through the 'door' and enter the next stage.");
                     stage3();
                 }
                 else
                 {
                     System.out.println("You haven't opened the 'door' yet.");
                 }
            } 
            else
            {
                 System.out.println("Sorry, you cannot do that. Please try something else.");
            }
        }    
    }
    public static void stage3()
    {
        if(!introstage3)
        {
            System.out.println("'stage3': Pool of Poseidon (God of Sea) - Use 'room'. ('room')");
            introstage3 = true;
        }   
        i = 3;
        while(true)     
        {
            System.out.println("What is your command?");
            input = kb.nextLine();
            if(input.equals("look at room") || input.equals("look at the room"))
            {
                lookroom3 = true;
                System.out.println("You see a luxurious marble pool lined with blue marble columns, along with mosaic pictures of aquatic animals that cover the pool's floor.");
                System.out.println("At the end of the long pool, you can see the god 'Poseidon' sitting in his throne, with a 'hatch' behind him.");
                System.out.println("At the base of the sea god's throne, a 'turtle' is crawling around. ('Poseidon', 'hatch', turtle')"); 
            }
            else if(input.equals("look at Poseidon") || input.equals("look at poseidon"))
            {
                if(!solvequestions)
                {
                    System.out.println("He is an long-bearded, ancient-looking god holding a trident. He is looking furiously at your direction.");
                }
                else if(solvequestions)
                {
                    System.out.println("He is a old god that is slumped on his throne, looking far off to the distance."); 
                }    
            }
            else if(input.equals("talk to Poseidon") || input.equals("talk to poseidon"))
            {
                if(!solvequestions)
                {
                    System.out.println("Poseidon: You must be a very bold young man, as for you risked getting punished for your action in the previous chamber.");
                    System.out.println("Poseidon: Because you destroyed my love, Medusa, I cannot let you pass easily.");
                    System.out.println("Poseidon: If you pass three of the questions that I will randomly test you on, you may proceed.");
                    System.out.println("Poseidon: But every time you get a question wrong, the pool will start to fill with water, level by level.");
                    System.out.println("Poseidon: When the water fills up all five levels, you'll drown and be sent to the underworld (the game will end)");
                    System.out.println("Poseidon: I'll now start asking my questions. (Make sure you type in your answers correctly)");
                    while(questionsanswered < 3)
                    {
                        int rand3 = rand.nextInt(5);
                        if(rand3 <= 0)
                        {
                            System.out.println("Poseidon: Which hero was dipped in the river Styx as a child, and died in the Trojan war when his heel, his only vulnerable spot, was shot?");
                            System.out.println("Use one of these heroes as answer: 'Hercules', 'Hector', 'Achilles', 'Perseus'. (Type in the name of the hero)");
                            input = kb.nextLine();
                            if(input.equals("Achilles") || input.equals("achilles"))
                            {
                                System.out.println("Poseidon: You are correct.");
                                questionsanswered = questionsanswered + 1;
                                System.out.println("You answered " + questionsanswered + " questions correctly.");
                                System.out.println("You also earn +100pt for answering the question correctly.");
                                pt = pt + 100;
                                System.out.println("You now have " + pt + "pt."); 
                            }
                            else
                            {
                                System.out.println("Poseidon: Ha! Your answer is unfortuately incorrect.");
                                System.out.println("Poseidon smirks as water fills a level of the pool.");
                                waterlevel = waterlevel + 1;
                                System.out.println(waterlevel + " levels of the pool is now filled with water, only " + (5 - waterlevel) + " levels left before you are drowned.");
                            }    
                        }
                        else if(rand3 <= 1)
                        {
                            System.out.println("Poseidon: What did the titan Prometheus give to the mankind as a gift?");
                            System.out.println("This gift can be found anywhere, and the ability to control it seperates humans from all other animals.");
                            input = kb.nextLine();
                            if(input.equals("Fire") || input.equals("fire"))
                            {
                                System.out.println("Poseidon: You are correct.");
                                questionsanswered = questionsanswered + 1;
                                System.out.println("You answered " + questionsanswered + " questions correctly.");
                                System.out.println("You also earn +200pt for answering the question correctly.");
                                pt = pt + 200;
                                System.out.println("You now have " + pt + "pt."); 
                            }
                            else
                            {
                                System.out.println("Poseidon: Ha! Your answer is unfortuately incorrect.");
                                System.out.println("Poseidon smirks as water fills a level of the pool.");
                                waterlevel = waterlevel + 1;
                                System.out.println(waterlevel + " levels of the pool is now filled with water, only " + (5 - waterlevel) + " levels left before you are drowned.");
                            }
                        }
                        else if(rand3 <= 2)
                        {
                            System.out.println("Poseidon: How would you defeat Hydra (nine headed snake)");
                            System.out.println("1) Burn it with greek fire.");
                            System.out.println("2) Cut off all of its heads.");
                            System.out.println("3) Cut off it's immortal head and bury it under a heavy stone.");
                            System.out.println("Type in the number of the answer. (ex: 5)");
                            input = kb.nextLine();
                            if(input.equals("3"))
                            {
                                System.out.println("Poseidon: You are correct.");
                                questionsanswered = questionsanswered + 1;
                                System.out.println("You answered " + questionsanswered + " questions correctly.");
                                System.out.println("You also earn +200pt for answering the question correctly.");
                                pt = pt + 200;
                                System.out.println("You now have " + pt + "pt."); 
                            }
                            else
                            {
                                System.out.println("Poseidon: Ha! Your answer is unfortuately incorrect.");
                                System.out.println("Poseidon smirks as water fills a level of the pool.");
                                waterlevel = waterlevel + 1;
                                System.out.println(waterlevel + " levels of the pool is now filled with water, only " + (5 - waterlevel) + " levels left before you are drowned.");
                            }
                        }
                        else if(rand3 <= 3)
                        {
                            System.out.println("Poseidon: If you are the hero Orpheus, and you are rescueing your wife, Eurydice, from the underworld.");
                            System.out.println("In this situation, what should you never do?");
                            System.out.println("1) Look back to see her.");
                            System.out.println("2) grab her hand.");
                            System.out.println("3) Insult the furies (demons) that are following you and your wife.");
                            System.out.println("Type in the number of the answer. (ex: 5)");
                            input = kb.nextLine();
                            if(input.equals("1"))
                            {
                                System.out.println("Poseidon: You are correct.");
                                questionsanswered = questionsanswered + 1;
                                System.out.println("You answered " + questionsanswered + " questions correctly.");
                                System.out.println("You also earn +200pt for answering the question correctly.");
                                pt = pt + 200;
                                System.out.println("You now have " + pt + "pt."); 
                            }
                            else
                            {
                                System.out.println("Poseidon: Ha! Your answer is unfortuately incorrect.");
                                System.out.println("Poseidon smirks as water fills a level of the pool.");
                                waterlevel = waterlevel + 1;
                                System.out.println(waterlevel + " levels of the pool is now filled with water, only " + (5 - waterlevel) + " levels left before you are drowned.");
                            }
                        }
                        else if(rand3 <= 4)
                        {
                            System.out.println("Poseidon: Many years ago, I have lost a competition with the goddess Athena.");
                            System.out.println("Poseidon: The competion was over the city of Athens, and I first offered the inhabitants of the city a spring of salt water.");
                            System.out.println("Poseidon: If you are Athena, what would you offer to the cities's inhabitants?");
                            System.out.println("1) horse");
                            System.out.println("2) olive tree");
                            System.out.println("3) gold");
                            System.out.println("4) victory in any battle they fight in");
                            System.out.println("Type in the number of the answer. (ex: 5)");
                            input = kb.nextLine();
                            if(input.equals("2"))
                            {
                                System.out.println("Poseidon: You are correct.");
                                questionsanswered = questionsanswered + 1;
                                System.out.println("You answered " + questionsanswered + " questions correctly.");
                                System.out.println("You also earn +300pt for answering the question correctly.");
                                pt = pt + 300;
                                System.out.println("You now have " + pt + "pt."); 
                            }
                            else
                            {
                                System.out.println("Poseidon: Ha! Your answer is unfortuately incorrect.");
                                System.out.println("Poseidon smirks as water fills a level of the pool.");
                                waterlevel = waterlevel + 1;
                                System.out.println(waterlevel + " levels of the pool is now filled with water, only " + (5 - waterlevel) + " levels left before you are drowned.");
                            }
                        }
                        if(waterlevel >= 5)
                        {
                            System.out.println("The water fills up the entire levels of the pool and you begin to drown.");
                            System.out.println("You see poseidon laughing as you suffocate and you finally die.");
                            System.out.println("Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    System.out.println("Poseidon: You have passed my test. Thus, I shall let you continue on your way. (Poseidon walks over to you)");
                    System.out.println("Poseidon: My feud is now gone, and you may take my beloved trident as a farewell gift. (Poseidon hands you his trident) ('trident')");
                    System.out.println("The 'trident' is one of the three master weapons, which will be crucial later on in the game.");
                    System.out.println("You stare at the god's back as he walk towards his throne. For some reason, he looks much older and weaker now.");
                    trident = true;
                    solvequestions = true;
                }
                else if(solvequestions)
                {
                    if(!Poseidonadvice)
                    {
                        System.out.println("Poseidon: You have passed my questions. You may proceed on. I have no power left in me to do much.");
                        System.out.println("Poseidon: The great monster that has captured my brother is slowly taking away the gods's power.");
                        System.out.println("Poseidon: Please try to defeat the evil monster, young hero. If not, the world will fall into chaos.");
                        Poseidonadvice = true;
                    }
                    else if(Poseidonadvice)
                    {
                        System.out.println("Poseidon: You have already talked to me. Continue on your way, young hero.");
                    }      
                }
            }
            else if(input.equals("look at turtle") || input.equals("look at the turtle"))
            {
                if(!solvequestions)
                {
                    System.out.println("you try to approach the 'turtle' beneath the throne, but you back away as 'Poseidon' points his trident at you.");
                }
                else if(solvequestions)
                {
                    System.out.println("It's a large, navy sea 'turtle' with a wide shell.");
                    System.out.println("On its back shell, you see the following writings carved into it.");
                    System.out.println("vwurqi");
                    System.out.println("Bring the letters down x spots in aphabetical order, where x is the number of holes in the 'hatch'.");
                    System.out.println("For example, if x is 4, e --> a, if x is 1, e --> d.");
                    keyword3 = true;
                }    
            }    
            else if(input.equals("talk to turtle") || input.equals("talk to the turtle"))
            {
                if(!solvequestions)
                {
                    System.out.println("you try to talk to the 'turtle', but the glare of 'Poseidon' stops you from doing so.");
                }
                else if(solvequestions)
                {
                    if(!talktoturtle)
                    {
                        System.out.println("Turtle: You have successfully resolved my master's wrath. Congratulation! Yet you should be aware of the god in the next stage.");
                        talktoturtle = true;
                    }
                    System.out.println("Turtle: The god is resides in the next stage is the god of violence, and he should not be trusted.");
                    System.out.println("Turtle: He is the one that has released the monsters from tartarus, and rebelled against the king of god.");
                    System.out.println("Turtle: Destroy the god no matter what. If else, he will turn the entire world into a pit of fire and war.");
                    System.out.println("Turtle: I trust in your strength, hero " + name + ".");
                }
            }     
            else if(input.equals("look at hatch") || input.equals("look at the hatch") || input.equals("open hatch") || input.equals("open the hatch"))
            {
                if(!solvequestions)
                {
                    System.out.println("You try to go around the sea god's throne to reach the 'hatch', but 'Poseidon' points his trident into your chest, so you back up."); 
                }
                else if(!stage4)
                {
                    System.out.println("The 'hatch' looks like a stadard submarine hatch, except that it has three 'holes' lined at its equator. ('holes')");
                    lookhatch = true;
                }
                else if(stage4)
                {
                    System.out.println("The 'hatch' is now open, and you may proceed to 'stage4'.");
                }    
            }
            else if(input.equals("look at holes") || input.equals("look at the holes"))
            {
                if(!stage4)
                {
                    System.out.println("They are three holes in the 'hatch', which seems to act like keyholes.");
                    System.out.println("You may be able to 'use' one of your equipments to open the 'hatch'.");
                    lookholes = true;
                }
                else if(stage4)
                {
                    System.out.println("The 'holes' have no meanings now, as for the 'hatch' is open and you can now proceed to the 'stage4'.");
                }    
            }
            else if(input.equals("look at trident") || input.equals("look at trident"))
            {
                if(!trident)
                {
                    System.out.println("The trident is a three-tipped spear that Poseidon is holding in his hand. You do not possess it yet."); 
                }
                else if(trident)
                {
                    System.out.println("The 'trident' is a three-tipped bronze weapon that radiates energy through you as you hold it.");
                    System.out.println("It's an unusually powerful weapon, one of the three master weapons. This weapon will be needed in the future.");
                }    
            }    
            else if(input.equals("use trident") || input.equals("use the trident"))
            {
                if(trident)
                {
                    if(!lookholes)
                    {
                        System.out.println("You don't know where to use the 'trident' yet.");
                    }
                    else if(!stage4)
                    {
                        System.out.println("You stab the 'trident' straight into the three 'holes'.");
                        while(!stage4)
                        {
                            System.out.println("You may now either 'push', 'twist', or 'pull' the trident. (Type in your action)");
                            input = kb.nextLine();
                            if(input.equals("push"))
                            {
                                System.out.println("The hatch doesn't move a bit. Try another action.");
                            }
                            else if(input.equals("pull"))
                            {
                                System.out.println("The hatch doesn't move a bit. Try another action.");
                            }
                            else if(input.equals("twist"))
                            {
                                System.out.println("As you twist the 'trident', the 'hatch' pops open.");
                                System.out.println("You may now use 'stage4' to move to the next stage. ('stage4')");
                                System.out.println("You pull out the 'trident' for future use. You may 'strike with' it during combats.");
                                System.out.println("You may also move back to the previous stages, by 'stagex', where x is the number of the stage.");
                                stage4 = true;
                            }
                            else
                            {
                                System.out.println("Your action doesn't work. Try another action.");
                            }    
                        }    
                    }
                    else if(stage4)
                    {
                        System.out.println("You don't need to use the 'trident', as for the 'hatch' is already open.");
                    }    
                }
                else if(!trident)
                {
                    System.out.println("You do not possess a 'trident' to use yet.");
                }    
            } 
            else if(input.equals("inventory") || input.equals("Inventory"))
            {
                 inventory();
            }
            else if(input.equals("market") || input.equals("Market"))
            {
                 market();
            }
            else if(input.equals("stage1"))
            {
                 System.out.println("You walk back all the way to the first stage.");
                 stage1();
            }
            else if(input.equals("stage2"))
            {
                 System.out.println("You walk back through the 'door' and into the previous stage.");
                 stage2();
            }
            else if(input.equals("stage4"))
            {
                 if(stage4)
                 {
                     System.out.println("You walk through the 'hatch' and enter the next stage.");
                     stage4();
                 }
                 else
                 {
                     System.out.println("You haven't opened the 'hatch' yet.");
                 }
            } 
            else
            {
                 System.out.println("Sorry, you cannot do that. Please try something else.");
            }
        }    
    }
    public static void stage4()
    {
        if(!introstage4)
        {
            System.out.println("'stage4': Dungeon of Ares (God of Violence) - Use 'room'. ('room')");
            introstage4 = true;
        }   
        i = 4;
        while(true)     
        {
            System.out.println("What is your command?");
            input = kb.nextLine();
            if(input.equals("look at room") || input.equals("look at the room"))
            {
                lookroom4 = true;
                if(Phobos)
                {
                    System.out.println("You see a dark dungeon with basalt walls and black-marble greek columns lining the sides, the dungeon is lit by blood-red oil-lamps.");
                    System.out.println("You see three gods in the dungeon. Two are 'Ares' and 'Phobos' standing at the end of the dungeon, guarding the 'passage'.");
                    System.out.println("The last god is 'Asclepius' (god of medicine), who is croutching over a hearth in the corner.");
                    System.out.println("('Ares', 'Phobos', 'Asclepius', 'passage')");
                }
                else if(Ares)
                {
                    System.out.println("You see a dark dungeon with basalt walls and black-marble greek columns lining the sides, the dungeon is lit by blood-red oil-lamps");
                    System.out.println("You see two gods in the dungeon. One is 'Ares' who is guarding the 'passage'.");
                    System.out.println("The other god is 'Asclepius', who is croutching over a hearth in the corner. ('Ares', 'Asclepius', 'passage')");
                }
                else if(!Ares)
                {
                    System.out.println("You see a dark dungeon with basalt walls and black-marble greek columns lining the sides, the dungeon is lit by blood-red oil-lamps");
                    System.out.println("The only things you see is the god 'Asclepius' and the 'passage' at the end of the dungeon. ('Asclepius', 'passage')");
                }    
            }
            else if(input.equals("look at Phobos") || input.equals("look at phobos"))
            {
                if(!panic)
                {
                    if(!potionpanic)
                    {
                        System.out.println("The look of the god 'Phobos' (god of fear) is tremendously terrifying, with bleeding eyes an face paler than the moonlight.");
                        System.out.println("You become frightened and have panic attack. The panic will stay with you until you find a way to get rid of it.");
                        panic = true;
                    }
                    else if(potionpanic)
                    {
                        System.out.println("The look of 'Phobos' is terrifying, but because you drank the potion, you don't get a panic attack.");
                    }    
                }    
                else if(Phobos)
                {
                    System.out.println("Because you are panicking, you cannot bear to look at the terrible face of 'Phobos'.");
                }
                else if(!Phobos)
                {
                    System.out.println("The god 'Phobos' is destroyed and now he is just a pile of golden dust.");
                }    
            }
            else if(input.equals("talk to Phobos") || input.equals("talk to phobos"))
            {
                if(!panic)
                {
                    if(!potionpanic)
                    {
                        System.out.println("Phobos: Before you may face my father, you'll need to go through me.");
                        System.out.println("Phobos: I'm the god of fear, and you'll fear me. Duel me if you dare. I'm curious how frightened you'll be when you face death!");
                        System.out.println("The voice of 'Phobos' is so petrifying that you run away with panic. The panic will stay with you until you find a way to get rid of it.");
                        panic = true;
                    }
                    else if(potionpanic)
                    {
                        System.out.println("Phobos: I see that the god 'Asclepius' has provided you with some of his medicine to keep you brave.");
                        System.out.println("Phobos: You may be less terrified, but you'll soon realize the power of god when you duel me.");
                    }    
                }    
                else if(Phobos)
                {
                    System.out.println("Because you are panicking, the voice of 'Phobos' itself makes you flee off.");
                }
                else if(!Phobos)
                {
                    System.out.println("The god 'Phobos' is destroyed and you cannot talk to him anymore.");
                }    
            }
            else if(input.equals("duel Phobos") || input.equals("duel phobos"))
            {
                if(!panic)
                {
                    if(!potionpanic)
                    {
                        System.out.println("As you raise your weapons to duel 'Phobos', 'Phobos' lunges at you with his scimitar. (curved sword)");
                        System.out.println("The war shrill of 'Phobos' is so terrifying that you flee in panic. The panic will stay with you until you find a way to get rid of it.");
                        panic = true;
                    }
                    else if(potionpanic)
                    {
                        System.out.println("Phobos: You may not be frightened of me anymore, but you'll fear my wrath!");
                        System.out.println("Phobos charges at you with his scimitar, crying out a horrible war cry.");
                        System.out.println("The duel with the gods will be different from ones with monsters.");
                        System.out.println("You'll take your first action, then the opposing god will take an action, and this will alternate until one flees or dies.");
                        System.out.println("Phobos starts with " + HPPhobos + " HP.");
                        System.out.println("You have " + HP + " HP left.");
                        while(!done)
                        {
                            offense = true;
                            while(offense)
                            {
                                System.out.println("What is your offensive action?");
                                input = kb.nextLine();
                                int rand4a = rand.nextInt(2);
                                if(input.equals("strike with sword") || input.equals("strike with the sword") || input.equals("strike with trident") || input.equals("strike with the trident"))
                                {
                                    if(rand4a <= 0)
                                    {
                                        System.out.println("As 'Phobos' lunged at you, you stab your weapon deep into his chest, dealing -40HP to 'Phobos'");
                                        HPPhobos = HPPhobos - 40;
                                        System.out.println("Phobos now has " + HPPhobos + " HP left.");
                                        if(HPPhobos <= 0)
                                        {
                                            System.out.println("Phobos is destroyed, and he turns into a pile of golden dust.");
                                            Phobos = false;
                                            System.out.println("You gain +1000 pt for destroying Phobos.");
                                            pt = pt + 1000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                    }
                                    else if(rand4a <= 1)
                                    {
                                        System.out.println("As you stab your weapon at 'Phobos', he steps aside and you barely miss maiming him."); 
                                    }
                                    offense = false;
                                }
                                else if(input.equals("strike with shield") || input.equals("strike with the shield") || input.equals("use shield") || input.equals("use the shield"))
                                {
                                    if(shield)
                                    {
                                        if(rand4a <= 0)
                                        {
                                            System.out.println("As 'Phobos' lunged at you, you ram your shield into his face, dealing -20HP to 'Phobos'");
                                            HPPhobos = HPPhobos - 20;
                                            System.out.println("Phobos now has " + HPPhobos + " HP left.");
                                            if(HPPhobos <= 0)
                                            {
                                                System.out.println("Phobos is destroyed, and he turns into a pile of golden dust.");
                                                Phobos = false;
                                                System.out.println("You gain +1000 pt for destroying Phobos.");
                                                pt = pt + 1000;
                                                System.out.println("You now have " + pt + " pt.");
                                            } 
                                        }
                                        else if(rand4a <= 1)
                                        {
                                            System.out.println("As you ram your shield at 'Phobos', he steps aside and avoid getting pushed by your shield."); 
                                        }
                                        offense = false;
                                    }
                                    else if(!shield)
                                    {
                                        System.out.println("You do not possess a shield to use. Please try another move.");
                                    }    
                                }
                                else if(input.equals("strike with arrows") || input.equals("strike with the arrows"))
                                {
                                    if(arrows > 0)
                                    {
                                        System.out.println("You release the Apollo's 'arrows' of Plague on the god of fear and deal tremendous damage to him.");
                                        System.out.println("The 'arrows' deal -60HP damage on 'Phobos.");
                                        HPPhobos = HPPhobos - 60;
                                        System.out.println("Phobos now has " + HPPhobos + " HP left.");
                                        if(HPPhobos <= 0)
                                        {
                                            System.out.println("Phobos is destroyed, and he turns into a pile of golden dust.");
                                            Phobos = false;
                                            System.out.println("You gain +1000 pt for destroying Phobos.");
                                            pt = pt + 1000;
                                            System.out.println("You now have " + pt + " pt.");
                                        } 
                                        arrows = arrows - 1;
                                        offense = false;
                                    }
                                    else if(arrows < 0)
                                    {
                                        System.out.println("You don't have any Apollo's 'arrows' of plague left to 'strike with'. Please try another action.");
                                    }    
                                }
                                else if(input.equals("flee") || input.equals("flee"))
                                {
                                    System.out.println("You run away from 'Phobos'. The fight is over for now.");
                                    flee = true;
                                    offense = false;
                                }
                                else
                                {
                                    System.out.println("Your action does not work. Please try another action.");
                                }
                            }
                            defense = true;
                            if(!Phobos)
                            {
                                done = true;
                                defense = false;
                            }
                            else if(flee)
                            {
                                done = true;
                                defense = false;
                            }
                            while(defense)
                            {
                                System.out.println("'Phobos' strikes his scimitar at you. You can chose to take one of the defensive moves below.");
                                System.out.println("With your sword, you can 'parry', or 'counterstrike'.");
                                System.out.println("Also if you have a 'shield', you can 'use' or 'strike with' it.");
                                System.out.println("What is your defensive action?");
                                input = kb.nextLine();
                                int rand4d = rand.nextInt(2);
                                if(input.equals("strike with shield") || input.equals("strike with the shield") || input.equals("use shield") || input.equals("use the shield"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("'Phobos' does a stabing movement with his scimitar.");
                                        System.out.println("Fortunately, your shield blocks the blade.");
                                        defense = false;
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("'Phobos' does a slashing movement with his scimitar.");
                                        System.out.println("You try to block it with your 'shield, but the blade slashes your side and deals -10HP damage on you.");
                                        HP = HP - 10;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                        defense = false;
                                    }
                                }
                                else if(input.equals("parry"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("'Phobos' does a stabing movement with his scimitar.");
                                        defense = false;
                                        System.out.println("Unfortunately, the blade gets pass your sword's parry and it stabs you. you receive -20HP damage.");
                                        HP = HP - 20;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("'Phobos' does a slashing movement with his scimitar.");
                                        System.out.println("Fortunately, you manage to parry the blade with your sword."); 
                                        defense = false;
                                    }
                                }
                                else if(input.equals("counterstrike"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("'Phobos' does a stabing movement with his scimitar.");
                                        System.out.println("As 'Phobos' stabs with his scimitar, your sword's counterstrike stabs him in the chest, dealing -20HP damage.");
                                        HPPhobos = HPPhobos - 20;
                                        System.out.println("Phobos has " + HPPhobos + " HP left.");
                                        System.out.println("Unfortuately, the scimitar of 'Phobos' stabs you deeply in the chest, and you recieve -40HP damage.");
                                        HP = HP - 40;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                        else if(HPPhobos <= 0)
                                        {
                                            System.out.println("Phobos is destroyed, and he turns into a pile of golden dust.");
                                            Phobos = false;
                                            System.out.println("You gain +1000 pt for destroying Phobos.");
                                            pt = pt + 1000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                        defense = false;
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("'Phobos' does a slashing movement with his scimitar.");
                                        System.out.println("As 'Phobos' tries to slash you, you counterstrike with your sword and embed it into his chest, dealing -20HP damage to 'Phobos'");
                                        HPPhobos = HPPhobos - 20;
                                        System.out.println("Phobos has " + HPPhobos + " HP left.");
                                        if(HPPhobos <= 0)
                                        {
                                            System.out.println("Phobos is destroyed, and he turns into a pile of golden dust.");
                                            Phobos = false;
                                            System.out.println("You gain +1000 pt for destroying Phobos.");
                                            pt = pt + 1000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                        defense = false;
                                    }
                                }
                                else if(input.equals("flee") || input.equals("flee"))
                                {
                                    System.out.println("You cannot 'flee' while defending. Please try another action.");
                                }
                                else
                                {
                                    System.out.println("Your action does not work. Please try another action.");
                                }
                            }
                            if(!Phobos)
                            {
                                done = true;
                            }     
                        }
                        if(!Phobos)
                        {
                            System.out.println("As 'Phobos' dies, his golden ichor (god's blood) trickles from his ashes, and you collect the Ichor in a glass vile.");
                            System.out.println("You can use 'vile' when you need the god's Ichor later on.");
                            vile = true;    
                        }    
                        done = false;
                        flee = false;
                        offense = false;
                        defense = false;
                    }    
                }    
                else if(panic)
                {
                    System.out.println("You try to lift your weapons, but you fall to the gorund in panic as 'Phobos' approaches you. You barely escape from the fight.");
                }
                else if(!Phobos)
                {
                    System.out.println("The god 'Phobos' is destroyed and turned into a pile of golden dust, so you cannot duel him.");
                }    
            }
            else if(input.equals("look at Asclepius") || input.equals("look at asclepius"))
            {
                System.out.println("He is an young god wearing a thick glasses and a white robe, crouching over the hearth in the corner, looking down at a boiling pot.");
            }
            else if(input.equals("talk to Asclepius") || input.equals("talk to asclepius"))
            {
                if(!potionpanic)
                {
                    if(!panic)
                    {
                        System.out.println("Asclepius: Hello my hero, I'm the great master of medicine, 'Asclepius'! (he says this as he sits in the corner like a homeless man");
                    }
                    else if(panic)
                    {
                        System.out.println("Asclepius: Oh. I see that 'Phobos' has put his panic curse on you. But I can fix it with the right potion.");
                    }
                    if(!Asclepiusintro)
                    {
                        System.out.println("Asclepius: I had been working for that monster 'Ares' so far to avoid Zeus's wrath.");
                        System.out.println("Asclepius: As you may know, Zeus would not be satisfied if he knew that I brought creatures back from the underworld using my medicines.");
                        System.out.println("Asclepius: I didn't want to be struck by his lighting bolt like the last time.");
                        System.out.println("Asclepius: But as I worked for 'Ares', I learned just how evil he was. He is planning to massacre the entire world and turn it into a pit of fire.");
                        Asclepiusintro = true; 
                    }
                    System.out.println("Asclepius: With this potion I'll make for you, you'll be able to defeat the 'Phobos', son of 'Ares'.");
                    System.out.println("Asclepius: First, you need the a specific object from Athena's chamber.");
                    if(!branch)
                    {
                        System.out.println("Asclepius: You do not possess the object. You'll need to go back to 'stage2' and acquire the it. (The object is a symbol of Athena)");
                    }
                    else if(branch)
                    {
                        System.out.println("Asclepius: I see that you have the object. (type 'offer + object name' to make the potion (ex: offer apple))");
                    }        
                }
                else if(potionpanic)
                {
                    if(!potiongod)
                    {
                        if(!vile)
                        {
                            System.out.println("Asclepius: You'll need my help one more time, but not before you destroy 'Phobos'.");
                        }
                        else if(vile)
                        {
                            System.out.println("Asclepius: I see that you have destroyed 'Phobos', yet you still have 'Ares' to defeat.");
                            System.out.println("Asclepius: Since 'Ares' is an olympian god, he cannot be destroyed by a mortal like you, but only by another god.");
                            System.out.println("Asclepius: But if you drink my potion made from the ichor of a god, you will gain the divine strength of a god.");
                            System.out.println("Asclepius: I can see that you have the Ichor. (type 'offer vile' to make the potion)");
                        }     
                    }
                    else if(potiongod)
                    {
                        System.out.println("Asclepius: You have already drank both of my potions. You do not need me anymore.");
                        if(Ares)
                        {
                            System.out.println("I do have one request. Please destroy 'Ares'. He is the one behind all this crisis.");
                        }
                    }    
                }    
            }
            else if(input.equals("offer branch") || input.equals("offer the branch"))
            {
                if(branch)
                {
                    System.out.println("Asclepius: Thank you. Now I will make a potion for you.");
                    System.out.println("Asclepius places the olive branch in the pot and boils it into a green liquid.");
                    System.out.println("Asclepius offers the liquid to you and you drink it. Now you are resistant to panic.");
                    panic = false;
                    potionpanic = true;
                }
                else if(!branch)
                {
                    if(potionpanic)
                    {
                        System.out.println("You have already offered the 'branch' in order to make the potion, and you have drank the potion.");
                    }
                    else
                    {
                        System.out.println("You do not possess the 'branch', and you need to grab it from 'stage2', the chamber of Athena.");
                    }
                }    
            }
            else if(input.equals("offer vile") || input.equals("offer the vile"))
            {
                if(vile)
                {   
                    System.out.println("Asclepius: Thank you. Now I will make another potion for you.");
                    System.out.println("Asclepius pours the 'vile' of ichor into the pot and boils it into a golden liquid.");
                    System.out.println("Asclepius offers the liquid to you and you drink it. Now you have the divine strength to destroy an olympian god.");
                    vile = false;
                    potiongod = true;
                }
                else if(!vile)
                {
                    if(Phobos)
                    {
                        System.out.println("You don't have the 'vile' yet. You can only acquire the ichor if you kill a god.");
                    }
                    else if(!Phobos)
                    {
                        System.out.println("You have drank the potion and used the ichor in the vile.");
                    }     
                }    
            }
            else if(input.equals("look at Ares") || input.equals("look at ares"))
            {
                if(Phobos)
                {
                    if(!panic)
                    {
                        System.out.println("'Ares' is a muscular and violent-looking god wearing a blood-red robe, a bronze helmet and armours, and assortment of weapons.");
                    }
                    else if(panic)
                    {
                        System.out.println("Becausing you are panicking, you cannot bear to look at the wrathful face of 'Ares'."); 
                    }    
                }    
                else if(!Phobos)
                {
                    System.out.println("'Ares' is a violent-looking god that is gazing at you with his eyes, which are literally burning with fire.");
                }
                else if(!Ares)
                {
                    System.out.println("The god 'Ares' is destroyed and now he is just a pile of golden dust, like his son 'Phobos'.");
                }
            }
            else if(input.equals("talk to Ares") || input.equals("talk to ares"))
            {
                if(Phobos)
                {
                    if(!panic)
                    {
                        System.out.println("Ares: Hahaha! A young hero has come forth to my dungeon.");
                        System.out.println("Ares: You think you can save the Olympus by yourself. But how will you go pass me?");
                        System.out.println("Ares: No mortal can destroy an Olympian god, including me.");
                    }
                    else if(panic)
                    {
                        System.out.println("Becausing you are panicking, you cannot bear to talk to the god of violence."); 
                    }    
                }    
                else if(!Phobos)
                {
                    System.out.println("Ares: You! You have killed my son 'Phobos'! I'll personally destroy you in a duel!");
                    System.out.println("Ares: Duel me if you dare!");
                }
                else if(!Ares)
                {
                    System.out.println("The god 'Ares' is destroyed and you cannot talk to him.");
                }
            }
            else if(input.equals("duel Ares") || input.equals("duel ares"))
            {
                if(!Phobos)
                {
                    if(!potiongod)
                    {
                        System.out.println("Ares charges at you feriously with a 'bident', breathing out fire and smoke.");
                        System.out.println("Before you can raise your weapon and fight, the fire from 'Ares' engulfs you.");
                        System.out.println("You barely escape with your life, but you recived -40HP damage.");
                        HP = HP - 40;
                        System.out.println("You now have " + HP + " HP left.");
                        if(HP <= 0)
                        {
                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    else if(potiongod)
                    {
                        System.out.println("Ares: I shall avenge my son's death! Face my wrath!");
                        System.out.println("Ares Sends a storm of fire at you, but because you drank the second potion from 'Asclepius', you recieve no harm.");
                        System.out.println("Ares: I see that you have acquired the divine strength. But you shall not be able to defeat an Olympian god!");
                        System.out.println("'Ares' then charges at you with his 'bident' (double-tipped spear), its deathly aura surrounding the entire god.");
                        System.out.println("You'll take your first action, then the opposing god will take an action, and this will alternate until one flees or dies.");
                        System.out.println("'Ares' starts with " + HPAres + " HP.");
                        System.out.println("You have " + HP + " HP left.");
                        while(!done)
                        {
                            offense = true;
                            while(offense)
                            {
                                System.out.println("What is your offensive action?");
                                input = kb.nextLine();
                                int rand4a = rand.nextInt(2);
                                if(input.equals("strike with sword") || input.equals("strike with the sword"))
                                {
                                    if(rand4a <= 0)
                                    {
                                        System.out.println("As 'Ares' charges at you, you side-step and stab your weapon into his side, dealing -40HP to 'Ares'");
                                        HPAres = HPAres - 40;
                                        System.out.println("'Ares' now has " + HPAres + " HP left.");
                                        if(HPAres <= 0)
                                        {
                                            System.out.println("'Ares' falls to the ground, and he slowly melts into a pile of golden dust, his eyes fixed on you as he is destroyed.");
                                            Ares = false;
                                            System.out.println("You gain +2000 pt for destroying 'Ares'.");
                                            pt = pt + 2000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                    }
                                    else if(rand4a <= 1)
                                    {
                                        System.out.println("As you swing your weapon at 'Ares', he deflects your blow and stabs you with the ends of his bident.");
                                        System.out.println("You recieve damage of -20HP from this counter-attack.");
                                        HP = HP - 20;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }  
                                    }
                                    offense = false;
                                }
                                if(input.equals("strike with trident") || input.equals("strike with the trident"))
                                {
                                    if(rand4a <= 0)
                                    {
                                        System.out.println("As 'Ares' charges at you, you raise the trident and take a stance.");
                                        System.out.println("When 'Ares' comes within arm-length from you, you stab the 'trident' deep into his chest, and your weapon punctures the god's armour.");
                                        System.out.println("'Ares' starts bleeding Ichor as you pull the 'trident' out. 'Ares' recieves the devastating -100HP damage.");
                                        HPAres = HPAres - 100;
                                        System.out.println("'Ares' now has " + HPAres + " HP left.");
                                        if(HPAres <= 0)
                                        {
                                            System.out.println("'Ares' falls to the ground, and he slowly melts into a pile of golden dust, his eyes fixed on you as he is destroyed.");
                                            Ares = false;
                                            System.out.println("You gain +2000 pt for destroying 'Ares'.");
                                            pt = pt + 2000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                    }
                                    else if(rand4a <= 1)
                                    {
                                        System.out.println("As you strike the 'trident' at 'Ares', he deflects your blow and stabs you with the ends of his bident.");
                                        System.out.println("You recieve damage of -20HP from this counter-attack.");
                                        HP = HP - 20;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }  
                                    }
                                    offense = false;
                                }
                                else if(input.equals("strike with shield") || input.equals("strike with the shield") || input.equals("use shield") || input.equals("use the shield"))
                                {
                                    if(shield)
                                    {
                                        System.out.println("As 'Ares' charges at you with his bident, you raise your 'shield' ram it into 'Ares'.");
                                        System.out.println("Unfortunately, it does nothing for than make 'Ares' stagger backward.");
                                        offense = false;
                                    }
                                    else if(!shield)
                                    {
                                        System.out.println("You do not possess a shield to use. Please try another move.");
                                    }    
                                }
                                else if(input.equals("strike with arrows") || input.equals("strike with the arrows"))
                                {
                                    if(arrows > 0)
                                    {
                                        System.out.println("You release the Apollo's 'arrows' of Plague on the god of fear and deal great damage to 'Ares'.");
                                        System.out.println("The 'arrows' deal -60HP damage on 'Ares'.");
                                        HPPhobos = HPPhobos - 60;
                                        System.out.println("Ares now has " + HPAres + " HP left.");
                                        if(HPAres <= 0)
                                        {
                                            System.out.println("'Ares' falls to the ground, and he slowly melts into a pile of golden dust, his eyes fixed on you as he is destroyed.");
                                            Ares = false;
                                            System.out.println("You gain +2000 pt for destroying 'Ares'.");
                                            pt = pt + 2000;
                                            System.out.println("You now have " + pt + " pt.");
                                        }
                                        arrows = arrows - 1;
                                        offense = false;
                                    }
                                    else if(arrows < 0)
                                    {
                                        System.out.println("You don't have any Apollo's 'arrows' of plague left to 'strike with'. Please try another action.");
                                    }    
                                }
                                else if(input.equals("flee") || input.equals("flee"))
                                {
                                    System.out.println("You run away from 'Ares'. The fight is over for now.");
                                    flee = true;
                                    offense = false;
                                }
                                else
                                {
                                    System.out.println("Your action does not work. Please try another action.");
                                }
                            }
                            defense = true;
                            if(!Ares)
                            {
                                done = true;
                                defense = false;
                            }
                            else if(flee)
                            {
                                done = true;
                                defense = false;
                            }
                            while(defense)
                            {
                                System.out.println("'Ares' lunges at you and jumps high in the air for a coup-de-grasse. You can chose to take one of the defensive moves below.");
                                System.out.println("With your sword, you can 'parry', or you can 'dodge'.");
                                System.out.println("Also if you have a 'shield', you can 'use' or 'strike with' it.");
                                System.out.println("What is your defensive action?");
                                input = kb.nextLine();
                                int rand4d = rand.nextInt(2);
                                if(input.equals("strike with shield") || input.equals("strike with the shield") || input.equals("use shield") || input.equals("use the shield"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("'Ares' rams his bipent into your 'shield' as you raise it above your head to block 'Ares'.");
                                        System.out.println("Fortunately, your 'shield' blocks the bident and you receive no damage.");
                                        defense = false;
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("As you raise your 'shield' to block 'Ares', 'Ares' lunges forward and lands behind you.");
                                        System.out.println("He turns his bident around and stabs you with his bident's two spear ends.");
                                        System.out.println("From this sudden attack, you recieve -40HP damage");
                                        HP = HP - 40;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                        defense = false;
                                    }
                                }
                                else if(input.equals("parry"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("'Ares' rams his bident from above as you parry his blow.");
                                        defense = false;
                                        System.out.println("Unfortunately, you couldn't parry it hard enough and the bident spears your side. you receive -40HP damage.");
                                        HP = HP - 40;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("'Ares' rams his bident from above as you parry his blow.");
                                        System.out.println("You manage to push the bident with enough force to avoid getting speared by it."); 
                                        defense = false;
                                    }
                                }
                                else if(input.equals("dodge"))
                                {
                                    if(rand4d <= 0)
                                    {
                                        System.out.println("As you try to dodge the bident of 'Ares', he slightly turns his weapon at your direction.");
                                        System.out.println("He stabs the weapon deep into your side, and you recieve -60HP damage.");
                                        HP = HP - 60;
                                        System.out.println("You now have " + HP + " HP left.");
                                        if(HP <= 0)
                                        {
                                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                            input = kb.nextLine();
                                            while(true)
                                            {
                                                if(input.equals("end") || input.equals("End"))
                                                {
                                                    System.exit(0);
                                                }
                                                else
                                                {
                                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                                }    
                                            }
                                        }
                                        defense = false;
                                    }
                                    else if(rand4d <= 1)
                                    {
                                        System.out.println("You dodge the blow from 'Ares' just in time to avoid getting speared.");                                  
                                        defense = false;
                                    }
                                }
                                else if(input.equals("flee") || input.equals("flee"))
                                {
                                    System.out.println("You cannot 'flee' while defending. Please try another action.");
                                }
                                else
                                {
                                    System.out.println("Your action does not work. Please try another action.");
                                }
                            }
                            if(!Ares)
                            {
                                done = true;
                            }     
                        }
                        done = false;
                        flee = false;
                        offense = false;
                        defense = false;
                    }
                    if(!Ares)
                    {
                        System.out.println("The only things remaining from 'Ares' are his golden dusts and his 'bident'.");
                        System.out.println("You pick up the 'bident' and realized that it doesn't originally belong to 'Ares'.");
                        System.out.println("The 'bident' is not just an ordinary weapon, but one of the tree master weapons.");
                        System.out.println("You keep the 'bident', knowing that soon, you'll come to need it. ('bident')");
                        System.out.println("The weapon is from one of the three major god you'll encounter soon, the god of the underworld.");
                        bident = true;
                    }     
                }    
                else if(Phobos)
                {
                    if(!panic)
                    {
                        System.out.println("'Ares' simply laughs and approaches you with his 'bident', fire and smoke starting to come out of his mouth." );
                        System.out.println("Before you can do anything, the fire from 'Ares' grows into a bonfire and it engulfs you.");
                        System.out.println("You barely escape with your life from the god of violence. However, you recieve -40HP damage.");
                        HP = HP - 40;
                        System.out.println("You now have " + HP + " HP left.");
                        if(HP <= 0)
                        {
                            System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                            input = kb.nextLine();
                            while(true)
                            {
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                                else
                                {
                                    System.out.println("You typed in the wrong word. Please type in 'end'.");
                                }    
                            }
                        }
                    }
                    else if(panic)
                    {
                        System.out.println("Since you are having panic attack, you cannt bear to challenge the god of violence.");
                    }
                }
                else if(!Ares)
                {
                    System.out.println("The god 'Ares' is destroyed and turned into a pile of golden dust, just like his son, 'Phobos'. Because of this, you cannot duel him.");
                }    
            }
            else if(input.equals("look at bident") || input.equals("look at the bident"))
            {
                System.out.println("It's a darkened-iron weapon that has two crude spear ends. It is one of the three master weapons.");
            }
            else if(input.equals("look at passage") || input.equals("look at the passage") || input.equals("open passage") || input.equals("open the passage"))
            {
                if(Ares)
                {
                    System.out.println("You try to approach the passage, but the god 'Ares' blocks your way furiously.");
                }
                else if(!Ares)
                {
                    if(!removestone)
                    {
                        System.out.println("You approach the 'passage', which has a tomb 'stone' blocking its entrance. ('stone')");
                        lookpassage = true;
                    }
                    else if(removestone)
                    {
                        System.out.println("It's a 'passage' leading down to the darkness, which is already open. Type 'stage5' to move to the next stage.");
                    }    
                }    
            }
            else if(input.equals("look at stone") || input.equals("look at the passage"))
            {
                if(!Ares)
                {
                    System.out.println("It's an ancient tomb stone that has a mathematical question written on it in greek letters.");
                    System.out.println("Problem: If it takes ten days for a human to go across the field of the dead to the underworld god's palace,");
                    System.out.println("How long would it take for a spirit that can travel half as fast, and needs to rest a full day for every twenty-one days?");
                    System.out.println("(call the answer 'x')");
                    System.out.println("Also, if a horse-rider named Hercules travelled three-fifth of the distance twice the speed as a normal human,");
                    System.out.println("and crawled the rest of the speed at a speed that is half-way between a normal human and a spirit,");
                    System.out.println("how many days would it take for Hercules to reach the palace? (call the answer 'y')");
                    System.out.println("Now, add 'x' and 'y' to get the final answer of 'z'. You should remember the numerical value of 'z' for the future use.");  
                    lookstone = true;
                    if(!removestone)
                    {
                        System.out.println("Beside the question, you try to remove the stone, but its too heavy.");
                        System.out.println("You might be able to 'use' one of your equipments and weapons to remove the stone.");
                    }
                    else if(removestone)
                    {
                        System.out.println("The tomb 'stone' is laying on the ground. And the passage is open. You can use 'stage5' to move to the next stage.");
                    }
                }
                else if(Ares)
                {
                    System.out.println("You try to approach the 'stone', but 'Ares' furiously blocks your way.");
                }    
            }
            else if(input.equals("use trident") || input.equals("use the trident") || input.equals("use bident") || input.equals("use the bident"))
            {
                if(lookstone)
                {
                    System.out.println("You use the master weapon as a leverage to lift the 'stone' and set it aside on the ground.");
                    System.out.println("The 'passage' is now open, and you may use 'stage5' to move to the next stage.");
                    stage5 = true;
                }
                else if(!lookstone)
                {
                    System.out.println("You don't know where to use the master weapon yet.");
                }    
            }    
            else if(input.equals("inventory") || input.equals("Inventory"))
            {
                 inventory();
            }
            else if(input.equals("market") || input.equals("Market"))
            {
                 market();
            }
            else if(input.equals("stage1"))
            {
                 System.out.println("You walk back all the way to the first stage.");
                 stage1();
            }
            else if(input.equals("stage2"))
            {
                 System.out.println("You walk back to the second stage.");
                 stage2();
            }
            else if(input.equals("stage3"))
            {
                 System.out.println("You walk back through the 'hatch' and into the previous stage.");
                 stage3();
            }
            else if(input.equals("stage5"))
            {
                 if(stage5)
                 {
                     System.out.println("You walk into the 'passage' and enter the next stage.");
                     stage5();
                 }
                 else
                 {
                     System.out.println("The 'passage' is not accessible yet, so you cannot enter the 'stage5' for now.");
                 }
            } 
            else
            {
                 System.out.println("Sorry, you cannot do that. Please try something else.");
            }
        }      
    }
    public static void stage5()
    {
        
    }    
    public static void inventory()
    {
        System.out.println("Basic commands: 'look at', 'talk to', 'open', 'use', , 'grab', 'duel', 'flee', 'strike with', 'buy'.");
        if(i <= 1)
        {
            System.out.println("In 'stage1', you have discovered the following objects.");
            if(!lookroom1)
            {
                System.out.println("You haven't found anything yet.");
            }    
            else if(!lookroom)
            {
                System.out.println("'torch', 'boulder'");
                if(looksword)
                {
                    System.out.println("'sword'");
                }
            }
            else if(lookroom)
            {
                System.out.println("'torch', 'boulder', 'Apollo', 'gate'");
                if(Python)
                {
                    System.out.println("'Python'");
                }    
                if(looksword)
                {
                    System.out.println("'sword'");
                }
                if(watchchain)
                {
                    if(chain)
                    {
                        System.out.println("'chain'");
                    }   
                }
            }
        }
        else if(i <= 2)
        {
            if(stage2)
            {
                System.out.println("In 'stage2', you have discovered the following object.");
                if(!lookroom2)
                {
                    System.out.println("You haven't found anything yet.");
                }    
                else if(lookroom2)
                {
                    System.out.println("'mirror', 'statue', 'door'");
                    if(!Athena)
                    {
                        System.out.println("'owl'");
                    }    
                    else if(Athena)
                    {
                        System.out.println("'Athena'");
                    }
                    if(Medusa)
                    {
                        System.out.println("'Medusa'");
                    }
                    else if(headofMedusa)
                    {
                        System.out.println("'head'");
                    }
                    if(lookatstatue)
                    {
                        System.out.println("'branch', 'shield'");
                        if(!Athena)
                        {
                            System.out.println("'helmet'");
                        }    
                    }
                }    
            }
        }
        else if(i <= 3)
        {
            if(stage3)
            {
                System.out.println("In 'stage3', you have discovered the following object.");
                if(!lookroom3)
                {
                    System.out.println("You haven't found anything yet.");
                }    
                else if(lookroom3)
                {
                    System.out.println("'Poseidon', 'hatch', 'turtle''");
                    if(lookhatch)
                    {
                        System.out.println("'holes'");
                    }
                    if(trident)
                    {
                        System.out.println("'trident'");
                    }
                }
            }
        }
        else if(i <= 4)
        {
            if(stage4)
            {
                System.out.println("In 'stage4', you have discovered the following object.");
                if(!lookroom4)
                {
                    System.out.println("You haven't found anything yet.");
                }    
                else if(lookroom4)
                {
                    System.out.println("'Ares', 'Phobos', 'Asclepius', 'passage'");
                    if(vile)
                    {
                        System.out.println("'vile'");
                    }
                    if(lookpassage)
                    {
                        System.out.println("'stone'");
                    }
                }
            }
        }
        System.out.println("You possess these following equipments.");
        {
            if(!sword)
            {
                System.out.println("You don't possess any equipments.");
            }    
            if(sword)
            {
                System.out.println("'sword' - use 'strike with' (well-rounded weapon)");
            }
            if(shield)
            {
                System.out.println("'shield' - use 'use' or 'strike with' (good for fighting against weak monsters, as for the 'head' of Medusa attached to it will turn it into stone)");
            }
            if(trident)
            {
                System.out.println("'trident' - use 'strike with' (well-rounded weapon, one of the three master weapons)");
            }
            if(arrows > 0)
            {
                System.out.println("'arrows' (full name: Apollo's 'arrows' of plague) - use 'strike with'");
                System.out.println("You have " + arrows + " set of arrows in your possesion. (deals enormous amount of damage)");
            }
            if(headofMedusa)
            {
                System.out.println("'head'");
            }
            if(branch)
            {
                System.out.println("'branch'");
            }
            if(helmet)
            {
                System.out.println("'helmet'");
            }
            if(vile)
            {
                System.out.println("'vile' - containing the ichor (blood) of the god 'Phobos'.");
            }    
        }
        System.out.println("Enter 'book' if you want to look at the key words you have discovered so far, along with some tips. (Type 'finish' to continue on your quest)");
        input = kb.nextLine();
        if(input.equals("book"))
        {
            book();
        }
    }
    public static void book()
    {
        System.out.println("Remember, 'look at' works for all objects/subjects, and 'talk to' works for every subject. use 'open' for any type of doors.");
        System.out.println("In this game, you are permitted to use commands on the same object multiple times. (in most cases)");
        System.out.println("Also, In combats, you can only 'flee' or 'strike with' your weapons, except that you may 'use' certain objects. (it'll be indicated below)");
        System.out.println("Makes sure you type in the commands, not type of attacks you will perform, when it asks 'what is your action during combat.");
        if(!keyword1)
        {
            System.out.println("You have not found the keyword in 'stage1'.");
        }
        else if(keyword1)
        {
            System.out.println("Through _oards of creatures / Shall a warrior _merge / F_om the swift blade's departure / Greatest _f evil must purge");
            System.out.println("Each _ represents a letter, combine all _ to make a password.");
            if(stage2)
            {
                System.out.println("'hero'");
            }
        }
        if(!keyword2)
        {
            System.out.println("You have not found the keyword in 'stage2'.");
        }
        else if(keyword2)
        {
            System.out.println("Athena: a n s t d (unscramble the word to make a password)");
        }
        if(!keyword3)
        {
            System.out.println("You have not found the keyword in 'stage3'.");
        }
        else if(keyword3)
        {
            System.out.println("vwurqi");
            System.out.println("Bring the letters down x spots in aphabetical order, where x is the number of holes in the 'hatch'.");
            System.out.println("For example, if x is 4, e --> a, if x is 1, e --> d.");
        }
        if(!lookstone)
        {
            System.out.println("You haven't found a key number in 'stage4' yet.");
        }
        else if(lookstone)
        {
            System.out.println("Problem: If it takes ten days for a human to go across the field of the dead to the underworld god's palace,");
            System.out.println("How long would it take for a spirit that can travel half as fast, and needs to rest a full day for every twenty-one days?");
            System.out.println("(call the answer 'x')");
            System.out.println("Also, if a horse-rider named Hercules travelled three-fifth of the distance twice the speed as a normal human,");
            System.out.println("and crawled the rest of the speed at a speed that is half-way between a normal human and a spirit,");
            System.out.println("how many days would it take for Hercules to reach the palace? (call the answer 'y')");
            System.out.println("Now, add 'x' and 'y' to get the final answer of 'z'. You should remember the numerical value of 'z' for the future use."); 
        }    
    }
    public static void market()
    {
        System.out.println("You can 'buy' the following equipments by paying the amount of points indicated for each object.");
        System.out.println("You currently have " + pt + "pt.");
        System.out.println("Healing 'potion' - increases your health by + 10HP. ('potion' - 100pt / you can buy any number of this)");
        System.out.println("Pandora's 'box' - You don't know what you are going to get. ('box' - 100pt / you can buy any number of this)");
        System.out.println("Apollo's 'arrows' of plague - one time use weapon, deals tremendous damage on your opponents. ('arrows' - 300pt / Can only use one 'arrows' at a time)"); 
        System.out.println("You can buy any number of these as long as you have enough points.");
        while(pt > 0)
        {
            while(!input.equals("finish"))
            {
                System.out.println("Which equipments would you like to buy? (type 'finish' to exit the market / type 'buy' + equipment to buy equipments)");
                input = kb.nextLine();
                int rand2 = rand.nextInt(3);
                if(input.equals("buy potion") || input.equals("buy the potion"))
                {
                    if(pt >= 100)
                    {
                        System.out.println("You drink the potion and your health is increased by + 10PH.");
                        HP = HP + 10;
                        System.out.println("Your health is now " + HP + "HP.");
                        pt = pt - 100;
                        System.out.println("you have " + pt + "pt left.");
                    }
                    else
                    {
                        System.out.println("You have " + pt + "pt left, which is not enough to buy this.");
                    }
                }
                if(input.equals("buy box") || input.equals("buy the box"))
                {
                    if(pt >= 100)
                    {
                        if(rand2 >= 2)
                        {
                            System.out.println("You opened the box and found hope. Your health is increased by 50PH because you feel the hope inside of you.");
                            HP = HP + 50;
                            System.out.println("Your health is now " + HP + "HP.");
                            pt = pt - 100;
                            System.out.println("you have " + pt + "pt left.");
                        }
                        else if(rand2 >= 1)
                        {
                            System.out.println("You opened the box and found plague. Your health is decreased by 20HP because the plague had infected you.");
                            HP = HP - 20;
                            System.out.println("Your health is now " + HP + "HP.");
                            if(HP > 0)
                            {
                                pt = pt - 100;
                                System.out.println("you have " + pt + "pt left.");
                            }
                            if(HP <= 0)
                            {
                                System.out.println("You died! You failed to rescue the gods from hands of the evil, and the world fell in chaos. Please enter 'end' to exit the game."); 
                                input = kb.nextLine();
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                            }
                        }
                        else
                        {
                            System.out.println("You opened the box and found hunger. Your point is decreased by 100pt.");
                            pt = pt - 200;
                            System.out.println("you have " + pt + "pt left.");
                        }
                    }
                    else
                    {
                        System.out.println("You have " + pt + "pt left, which is not enough to buy this.");
                    }
                }
                if(input.equals("buy arrows") || input.equals("buy the arrows"))
                {
                     if(pt >= 300)
                     {
                         System.out.println("You bought the Apollo's 'arrows' of plague, which is a one-time use weapon you can use in combats and other situations.");
                         pt = pt - 300;
                         System.out.println("you have " + pt + "pt left.");
                         arrows = arrows + 1;
                     }
                     else
                     {
                        System.out.println("You have " + pt + "pt left, which is not enough to buy this.");
                     }
                }
            }
        }
        if(pt < 0)
        {
            System.out.println("You don't have any money. You can earn money by defeating monsters or completing quests.");  
        }
        if(i <= 1)
        {
            stage1();
        }
        else if(i <= 2)
        {
            stage2();
        }
        else if(i <= 3)
        {
            stage3();
        }
        else if(i <= 4)
        {
            stage4();
        }    
    }
}    
