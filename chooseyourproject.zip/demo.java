import java.util.Scanner;
/**
 * Write a description of class demo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class demo
{
    static Scanner kb = new Scanner(System.in);    //you wouldn't need it anywhere else.
    static String input = "";
    
    //int key = 0; //This is a key where o means we do not pocess it and 1 means we have it.
    static boolean key = false; //This is a key where false means we do not posess it and true means we do pocess it.
    //make an inventory
    static boolean secondroom = false; 
    static boolean poster = true;
    static boolean lswitch = true;
    static boolean grate = true;
    public static void main()
    {
        System.out.println("Hello, welcome to this basic Escape Room styled game.");
        System.out.println("You will use your surroundings and basic commends to try and escape.");
        System.out.println("Commands you can use include 'look at', 'get', and 'use'.");
        System.out.println("Examples of how to use these commands could be 'look at room', 'get key', and 'use key'.");
        System.out.println("Are you ready to play? (yes/no)"); //Players need to be able to play without looking at the code.
        input  = kb.nextLine();
        if(input.equals("yes") || input.equals("Yes"))
        {
            System.out.println("Great, let's begin.");
            room1();
        }
        else
        {
            System.exit(0); //exited properly.
        }
    }
    public static void room1()
    {
        System.out.println("You wake up inside a brightly lit room. You don't remember how you got here. Try to get out.");
        while(true)     //infinite loop
        {
                System.out.println("What would you like to do?");
                input = kb.nextLine();
                if(input.equals("look at room"))
                {
                    System.out.println("You find yourself in a brightly lit room. The room is near empty with a table in the centre, a desk in one corner, and door on the far wall.");
                    if(!lswitch)
                    {
                        System.out.println("You can see light shining through a small keyhole shaped hole in the back wall of the room.");
                        System.out.println("Without the light shining through, you would never have noticed it here.");
                    }
                }
                else if(input.equals("use key") && key)
                {
                    System.out.println("You slide the key in the brightly lit hole. It seems to be a perfect fit. Upon turning the key you hear a loud clatter from the next room.");
                    grate = false;
                }
                else if(input.equals("look at table"))
                {
                    System.out.println("You see a large wooden table in the miidle of the room. There is a note on it that says 'You will never escape'.");
                }
                else if(input.equals("look at desk"))
                {
                    System.out.println("An old metal desk lies dormant in the corner of the room. It has layers of dust on the surface with one drawer on the side.");
                }
                else if(input.equals("look at door"))
                {
                    System.out.println("You see a metal door closed on the far side of the room. You can't see any means of opening it but has a keypad in the centre of the frame.");
                }
                else if(input.equals("look at drawer"))
                {
                    System.out.println("It's a drawer. What else do you want from me?");
                }
                else if(input.equals("use drawer"))
                {
                    System.out.println("You open the drawer and find the numbers '5911' edge into the side of the metal. You think to yourself this will help me somewhere else.");
                }
                else if(input.equals("look at keypad"))
                {
                    System.out.println("You see a simple keypad with the digits 0-9 as individual buttons. It looks like a 4 digit code is required.");
                }
                else if(input.equals("use keypad"))
                {
                    System.out.println("What 4 digit combination would you like to enter?");
                    input = kb.nextLine();
                    if(input.equals("5911"))
                    {
                        System.out.println("The keypad flashes green and the door opens in front of you. You may now go into the next room.");
                        System.out.println("You may use the commands 'next room' and previous room' to travel between rooms.");
                        secondroom = true;
                    }
                    else 
                    {
                        System.out.println("The keypad buzzes at you and flashes rad. The code must not be correct.");
                    }
                }
                else if(input.equals("next room"))
                {
                    if(secondroom)
                    {
                        System.out.println("You move into the next room.");
                        room2();
                    }
                    else
                    {
                        System.out.println("You cannot get through the door.");
                    }
                }    
                else if(input.equals("previous room"))
                {
                    System.out.println("You are already in the previous room.");
                }
                else
                {
                    System.out.println("You cannot do that. Please try something else.");
                }
        }
    }
    public static void room2()
    {
        while(true)
        {
            System.out.println("What would you like to do?");
            input = kb.nextLine();
            if(input.equals("look at room"))
            {
                System.out.println("You find yourself in the adjacent room. A cupboard is hanging from the wall.");
                if(grate)
                {
                    System.out.println("A metal grate is on the ceiling.");
                }
                else
                {
                    System.out.println("The metal grate is on the floor. A rope ladder is hanging down through the gap in the ceiling.");
                }
                if(poster)
                {
                    System.out.println("A poster is taped to the side on a wall.");
                }
                else
                {
                    System.out.println("The remains of a poster are littered across the ground.");
                }
            }    
            else if(input.equals("look at poster"))
            {
                System.out.println("You see a poster of what looks to be an old movie premiere. The tape has started to peel on the side.");
            }
            else if(input.equals("look at cupboard"))
            {
                System.out.println("The cupboard hangs maliciously halfway up the wall. I woudl stay away if I were you.");
            }
            else if(input.equals("look at metal grate") || input.equals("look at grate"))
            {  
                if(grate)
                {
                     System.out.println("The grate is firmly attached to the ceiling with no way to reach it. You can see light shining down through it from above.");
                }
                else
                {
                    
                }
            }   
            else if(input.equals("get poster"))
            {
                if(poster)
                {
                    System.out.println("You tear the poster off of the wall. It doesn't rip off cleanly and there isn't much left so you leave it on the ground. You see a hole in the wall where the poster was.");
                    poster = false;
                }
                else
                {
                    System.out.println("The poster is ripped apart on the ground. You don't see a purpose to picking it up anymore.");
                }
            }
            else if(input.equals("use poster"))
            {
                System.out.println("You don't see much purpose of the poster right now.");
            }
            else if(input.equals("use cupboard"))
            {
                System.out.println("You open the cupboard and find nothing inside. You shrug and close the cupboard.");
            }
            else if(input.equals("use metal grate") || input.equals("use grate"))
            {
                System.out.println("You can't reach the grate to try and use it.");
            }
            else if(input.equals("look at hole"))
            {
                if(!poster)   //The ! checks to see if the variable is false
                {
                    System.out.println("There is a shallow hole in the wall that the poster once covered. You side a switch inside the hole.");
                    if(!key)
                    {
                        System.out.println("You also see a brass key laying in the hole.");    
                    }
                }
            }
            else if(input.equals("look at switch"))
            {
                if(!poster)
                {
                    System.out.println("It's a simple two way switch that flips on and off.");
                }
            }
            else if(input.equals("look at key"))
            {
                if(!poster)
                {
                    if(!key)
                    {
                        System.out.println("There is a simple key left inside the hole.");
                    }    
                }
            }
            else if(input.equals("get key"))
            {
                if(!poster && !key)
                {
                    System.out.println("You pick up the key and place it in your pocket.");
                    key = true;
                }
            } 
            else if(input.equals("use switch"))
            {
                if(!poster)
                {
                    if(lswitch)
                    {
                        System.out.println("You hear a click coming from the previous room.");
                        lswitch = false;
                    }
                    else
                    {
                        System.out.println("You hear a click coming from the previous room.");
                        lswitch = true;
                    }
                }
                // Can just use if in beginning and put these inside of it.
            }
            else if(input.equals("previous room"))
            {
                System.out.println("You move into the previous room.");
                room1();
            }
            else if(input.equals("next room"))
            {
                System.out.println("You are already in the next room.");
            }
            else if((input.equals("look at rope ladder") || input.equals("look at ladder")) && !grate)
            {
                System.out.println("A simple rope ladder hangs down through the gap. It seems to be your way out!");       
            }
            else if((input.equals("use rope ladder") || input.equals("use ladder")) && !grate)
            {
                System.out.println("You begin to climb up the ladder and manage to escape! Congrats, you've won the game!");
                System.out.println("Press any key to exit the game.");
                input = kb.nextLine();
                System.exit(0);   
            }
            else
            {
                System.out.println("You cannot do that. Please try something else.");
            }
        }
    }
}
