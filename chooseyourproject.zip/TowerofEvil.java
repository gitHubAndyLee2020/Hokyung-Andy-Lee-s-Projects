



import java.util.Scanner;
import java.util.Random;
/**
 * Write a description of class TowerofEvil here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TowerofEvil
{
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    static String input = "";
    static boolean torch = false; 
    static boolean dagger = false;
    static boolean Sphinx = false;
    static boolean key = false;
    static boolean keyhole = false;
    static boolean room2 = false;
    static boolean Priest = false;
    static boolean curse = false;
    static boolean paper = false;
    static boolean ladder = false;
    static boolean mummy = false;
    static boolean carving = false;
    static boolean hole = false;
    static boolean use_cast = false;
    static boolean open = false;
    static boolean room3 = false;
    static boolean river = false;
    static boolean curse2 = false;
    static boolean Hades = false;
    static int hp = 100;
    public static void main()
    {
        System.out.println("Welcome to the game of 'Tower of Evil', where you are a warrior that must escape series of floors filled with dangers in order to escape the tower.");
        System.out.println("The tower is composed of 10 floors, with 3 stages of 3 floors (1st stage - Ancient, 2nd stage - Medival, 3rd stage - Post-Modern), and the final stage guarded by a Dark Lord.");
        System.out.println("You will use objects/subjects in the rooms and basic command words to escape the rooms.");
        System.out.println("Basic commands are (6 in total): 'look at', 'use', 'open', 'talk to', 'attack with', and 'flee'.");
        System.out.println("All the usable objects in the room will be inside '' mark, including some other features that are usable in the game.");
        System.out.println("This is the way to use commands: command + object name  - Example of this is: look at room. The command 'flee' is used without any object following it. (ex: flee).");
        System.out.println("Type in 'inventory' to look at commands and equipments in rooms you have discovered so far. Remember, command 'attack with' with only equipments, just use 'flee' in combats if you have no weapons.");
        System.out.println("Are you ready to enter the tower and face the evil? (yes or no)");
        input = kb.nextLine();
        if(input.equals("yes") || input.equals("Yes") || input.equals("yep") || input.equals("Yep"))
        {
            System.out.println("Excellent! Let's start the game.");
            room1();
        }
        else
        {
            System.exit(0);
        }
    }
    public static void room1()
    {
        System.out.println("You are a warrior fighting against the looming evil force. You infiltrate a Dark Tower to fight the Dark Lord.");
        System.out.println("When you enter the tower, the gate behind you shuts and you are trapped. Try to escape alive, and destroy the Dark Lord! You are in a 'room'. (Use the object word: 'room')");
        System.out.println("You start with 100 HP, and you lose when you have 0 HP left.");
        System.out.println("Stage 1, floor 1: The Chamber of the Guardian");
        while(true)     
        {
                System.out.println("What do you want to do?");
                input = kb.nextLine();
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                    if(!torch)
                    {
                        System.out.println("The room is very dark and you can only see silhouettes of two things: 'torch' and 'wall'");
                    }    
                    else
                    {
                        System.out.println("The room is an ancient Egyptian chamber with three things: 'chest', 'obelisk', and 'stage' at the other side of the chamber.");
                        System.out.println("There are also writing on 'wall' and the 'torch' that you've already ignited.");
                    }
                }
                else if(input.equals("look at wall") || input.equals("look at the wall"))
                {
                    System.out.println("You read Egyptian hierographies written in blood. It says that the 'curse' of the Evil Lord shall destroy you.");
                    System.out.println("The word 'curse' is stuck in your mind. It maybe useful in the future.");
                    curse = true;
                }
                else if(input.equals("look at torch") || input.equals("look at the torch"))
                {
                    if(!torch)
                    {
                        System.out.println("It's an old wooden torch that seems to be ignitable when you 'use' it.");
                    }
                    else
                    {
                        System.out.println("You already ignited the torch.");   
                    }
                }
                else if(input.equals("use torch") || input.equals("use the torch"))
                {
                    if(!torch)
                    {
                        System.out.println("You ignite the torch and suddenly the room glows brightly");
                        torch = true;
                        System.out.println("The room turns out to be an ancient Egytian chamber with three things: 'chest', 'obelisk', and 'stage' at the other side of the chamber, and includes the 'wall' and 'torch' you've discovered already.");
                    }
                    else
                    {
                        System.out.println("You already ignited the torch.");
                    }
                }
                else if(input.equals("look at chest") || input.equals("look at the chest"))
                {
                    System.out.println("It's a wooden chest that requires a five-letter password to open.");
                }
                else if(input.equals("look at obelisk") || input.equals("look at the obelisk") || input.equals("use obelisk") || input.equals("use the obelisk"))
                {
                    System.out.println("It has a puzzle written on it. Try to figure it out (Tip: look closely at letters, not their meanings), and remember the answer(It's a word). It may be useful.");
                    System.out.println("Cruel Uranus Rain Shower Epic");
                    curse = true;
                }
                else if(input.equals("look at stage") || input.equals("look at the stage"))
                {
                    System.out.println("You can see stairs leading up to a stone stage that is blood stained, with a 'Sphinx' guarding something behind it.");
                    Sphinx = true;
                    System.out.println("You can 'talk to' Sphinx if you wish.");
                }
                else if(input.equals("use chest") || input.equals("use the chest") || input.equals("open chest") || input.equals("open the chest"))
                {
                    System.out.println("You must enter a five-letter password in order to open the chest");
                    String input = kb.nextLine();
                    if(input.equals("Curse") || input.equals("curse") || input.equals("CURSE"))
                    {
                        if(!dagger)
                        {
                            System.out.println("You opened the chest! You find a 'dagger' and keep it. You can 'attack with' it whenever you are attacked. You close the chest and it locks again.");
                            dagger = true;
                        }
                        else
                        {
                            System.out.println("You already opened the chest and aquired a 'dagger'.");
                        }
                    }
                }
                else if(input.equals("talk to Sphinx") || input.equals("talk to sphinx"))
                {
                    if(!key)
                    {
                        System.out.println("You climb the stairs on to the stage.");
                        System.out.println("The Sphinx on the stage speaks to you.");
                        System.out.println("Sphinx: Answer my riddle. If you answer it true, I shall let you continue your way up the tower. If you get it wrong, I shall attack you.");
                        System.out.println("Sphinx: Who is the hero that bathed in the river Styx? (choices: Achilles / Heracules / Horus / Odysseus");
                        input = kb.nextLine();
                        if(input.equals("Achilles") || input.equals("achilles"))
                        {
                            System.out.println("Sphinx: Your answer was true. You may continue your way. I shall also give you a 'key' that you shall need to open the 'gate' behind me.");
                            System.out.println("You should remember the word 'Achilles'. It'll be important.");
                            key = true;
                            System.out.println("You received an object: 'key', and an object in room: 'gate'");
                        }
                        else
                        {
                            System.out.println("Sphinx: Your answer is false! The Sphinx than attacks you. What will you do? (type in your reaction of your choice)");
                            input = kb.nextLine();
                            if(input.equals("flee") || input.equals("Flee"))
                            {
                                System.out.println("You barely escape the Sphinx.");
                            }
                            else if(input.equals("attack with dagger"))
                            {
                                System.out.println("Your weapon doesn't penetrate the monster's hide. You are attacked by the Sphinx and you lose 10 HP.");
                                hp = hp - 10;
                                if(hp <= 0)
                                {
                                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                    input = kb.nextLine();
                                    if(input.equals("end") || input.equals("End"))
                                    {
                                        System.exit(0);
                                    }
                                }
                                System.out.println("You have " + hp + "HP left.");
                            }
                            else
                            {
                                System.out.println("Your action have no effect on the monster. You are attacked by the Sphinx and you lose 10 HP.");
                                hp = hp - 10;  
                                if(hp <= 0)
                                {
                                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                    input = kb.nextLine();
                                    if(input.equals("end") || input.equals("End"))
                                    {
                                        System.exit(0);
                                    }
                                }
                                System.out.println("You have " + hp + "HP left.");
                            }
                        }
                    }
                    else if(key)
                    {
                        System.out.println("You already have passed the Sphinx's riddle. You may proceed to the 'gate'.");
                    }
                }  
                else if(input.equals("look at gate") || input.equals("look at the gate"))
                {
                        System.out.println("It's an old wooden gate with a 'keyhole' in the centre.");
                        keyhole = true;
                }
                else if(input.equals("open gate") || input.equals("open the gate") || input.equals("look at keyhole") || input.equals("look at the keyhole"))
                {
                    if(!room2)
                    {
                        if(input.equals("look at keyhole") || input.equals("look at the keyhole"))
                        {
                            System.out.println("The keyhole looks like its the perfect size for the key you posess.");
                        }
                        System.out.println("Please insert your key into the keyhole on the gate.");
                        System.out.println("You can 'use' one of your objects to open the gate.");
                        input = kb.nextLine();
                        if(input.equals("use key") || input.equals("use the key"))
                        {
                            System.out.println("The gate is open! you may proceed to the next room by typing command 'room2' and return to this chamber by 'room1'.");
                            room2 = true;
                        }
                    }
                    else
                    {
                        System.out.println("The gate is already open. You can proceed to the next room by typing command 'room2' and return to this chamber by 'room1'.");
                    }
                }
                else if(input.equals("inventory") || input.equals("inventory"))
                {
                    inventory();
                }
                else if(input.equals("room2"))
                {
                    if(room2)
                    {
                        System.out.println("You pass through the 'gate' and climb a stair to the next floor's room.");
                        room2();
                    }
                    else
                    {
                        System.out.println("The 'gate' is locked.");
                    }
                }  
                else
                {
                    System.out.println("Sorry, you cannot do that. Please try something else.");
                }
        }
    }
    public static void room2()
    {
        System.out.println("Stage 1, floor 2: The Undead's Tomb");
        System.out.println("You enter the 'room'.");
        while(true)     
        {
            System.out.println("What do you want to do?");
            input = kb.nextLine();
            if(input.equals("look at room") || input.equals("look at the room"))
            {
                System.out.println("It's an ancient Egyptian tomb with four objects/subject: 'cast', 'Priest', 'closet', and 'door'.");
            }
            else if(input.equals("look at closet") || input.equals("look at the closet"))
            {
                System.out.println("It's a ivory closet that seems to be openable.");
            }
            else if(input.equals("open closet") || input.equals("open the closet"))
            {
                if(!paper)
                {
                    System.out.println("You find 'toilet papers' in the closet, and you keep it to yourself thinking it might be a useful tool in the future.");
                    paper = true;
                }
                else if(paper)
                {
                    System.out.println("You already opened the closet, and it is empty.");
                }
            }    
            else if(input.equals("look at cast") || input.equals("look at the cast"))
            {
                System.out.println("It's a golden Egyptian cast with a 'hole' on the side.");
                System.out.println("There is also a 'carving' in the side of the cast.");
                hole = true;
            }
            else if(input.equals("look at carving") || input.equals("look at the carving"))
            {
                System.out.println("There are small letters written in hierography. It looks like a poem. ( each _ is a letter that you must guess)");
                System.out.println("_ver the hill stood the Pharoah with his almighty,"); 
                System.out.println("who _ell to the Dark Lord's curse and laid in the cast for eternity.");
                System.out.println("Try to figure out the letters and combine them to make a word. Remember it for future use.");
                carving  = true;
            }
            else if(input.equals("look at hole") || input.equals("look at the hole") || input.equals("open hole") || input.equals("open the hole"))
            {
                System.out.println("It's a keyhole that looks as if it can fit a key in it.");
                input = kb.nextLine();
                if(input.equals("use key") || input.equals("use the key"))
                {   
                    if(!mummy)
                    {
                        System.out.println("The cast opens and you see a king 'mummy' sit up and stare at you with its void eye sockets. (Type in your response)");
                        input = kb.nextLine();
                        open = true;
                        if(input.equals("talk to mummy") || input.equals("talk to the mummy"))
                        {
                            System.out.println("Mummy: I'm the Pharaoh that has been cursed by the Dark Lord. Answer my problem or face my curse!");
                            System.out.println("Mummy: What is one Bromine + one Oxgen?");
                            input = kb.nextLine();
                            if(input.equals("BRO") || input.equals("Bro") || input.equals("bro"))
                            {
                                System.out.println("Mummy: You do know your chemistry, bro. You are allowed to proceed. The pharaoh crumbles to dust, and you can see a 'ladder' going down from the cast down to the darkness.");  
                                mummy  = true;
                                ladder = true;
                            }
                            else
                            {
                                System.out.println("You are incorrect, and the mummy attacks you! (Type in your response)");
                                {
                                    if(input.equals("attack with dagger") || input.equals("attack with the dagger"))
                                    {
                                        System.out.println("Your weapon does nothing to kill the undead. You lose 20 HP and the cast closes.");
                                        hp = hp - 20;
                                        if(hp <= 0)
                                        {
                                            System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                            input = kb.nextLine();
                                            if(input.equals("end") || input.equals("End"))
                                            {
                                                System.exit(0);
                                            }
                                        }
                                    }
                                    System.out.println("You have " + hp + "HP left.");
                                }
                                if(input.equals("attack with toliet paper") || input.equals("attack with the toliet paper"))
                                {
                                    paper = false;
                                    System.out.println("The toliet paper wraps around the undead and he falls to the ground like a ball of cotton. You find a 'ladder' going down from the cast down to the darkness.");
                                    System.out.println("The toliet paper is used up and you cannot use it anymore."); 
                                    mummy  = true;
                                    ladder = true;
                                }
                            }
                        }
                        else if(input.equals("attack with dagger") || input.equals("attack with the dagger"))
                        {
                            System.out.println("Your weapon does nothing to kill the undead. You lose 20 HP and the cast closes.");
                            hp = hp - 20;
                            if(hp <= 0)
                            {
                                System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                input = kb.nextLine();
                                if(input.equals("end") || input.equals("End"))
                                {
                                    System.exit(0);
                                }
                            }
                            System.out.println("You have " + hp + "HP left.");
                        }
                        else if(input.equals("attack with toliet paper") || input.equals("attack with the toliet paper"))
                        {
                            paper = false;
                            System.out.println("The toliet paper wraps around the undead and he falls to the ground like a ball of cotton. You find a 'ladder' going down from the cast down to the darkness.");
                            System.out.println("The toliet paper is used up and you cannot use it anymore."); 
                            mummy  = true;
                            ladder = true;
                        }
                    }
                    else if(mummy)
                    {
                        System.out.println("The mummy is defeated and you can see a 'ladder' leading into the darkness.");
                    }
                }    
            }
            else if(input.equals("use cast") || input.equals("use the cast") || input.equals("open cast") || input.equals("open the cast"))
            {
                if(!mummy)
                {
                    System.out.println("The cast would not be opened by hand, but you notice a 'hole' on the side of the cast. (You must look at the 'hole' before you do anything to it)");
                    use_cast = true;
                }
                else if(mummy)
                {
                    System.out.println("The cast is open and the mummy is gone. You see a 'ladder' leading down to the darkness.");
                }
            }
            else if(input.equals("look at priest") || input.equals("look at Priest"))
            {
                System.out.println("He is an old man wearing a dark robe, and he wears a necklace with the symbol of the Dark Lord.");
            }
            else if(input.equals("talk to priest") || input.equals("talk to Priest"))
            {
                if(!Priest)
                {
                    System.out.println("Priest: I've been waiting for you. My guard Sphinx have told me about the your arrival. I'm the messenger of the Dark Lord, but I have no intention of fighting you just yet.");
                    System.out.println("Priest: I'll let you guess whether the coin in my hand is head or tail. After all, the success of a warrior all depends on luck. (type in 'head' or 'tail')");
                    input = kb.nextLine();
                    int number = rand.nextInt(2); //1 = head, 2 = tail
                    Priest = true;
                    if(number >= 1)
                    {
                        if(input.equals("head") || input.equals("Head"))
                        {
                            System.out.println("Priest: Your guess correct. I have a head. I'll give you a potion that will heal your wounds. Good luck in your future journey. My master is not as forgiving as I am.");
                            System.out.println("You drink the potion and your HP is boosted by 50 HP.");
                            hp = hp + 50;
                            System.out.println("Your health is now " + hp + " HP.");
                        }
                        else
                        {
                            System.out.println("Priest: You are wrong. I have a tail. I guess you are just as lucky as others who have entered this tower. I shall follow my master's order and attack you! (Type in your response)");
                            input = kb.nextLine();
                            if(input.equals("attack with dagger"))
                            {
                                System.out.println("You killed the Priest, and his body dissolves into black sand.");
                            }
                            else
                            {
                                System.out.println("Your action has no affect, and he bites your neck. You manage to get away, but you receive 20 HP damage.");
                                hp = hp - 20;
                                if(hp <= 0)
                                {
                                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                    input = kb.nextLine();
                                    if(input.equals("end") || input.equals("End"))
                                    {
                                        System.exit(0);
                                    }
                                }
                                System.out.println("You have " + hp + "HP left.");
                            }
                        }
                    }    
                    else if(number < 1)
                    {      
                        if(input.equals("tail") || input.equals("Tail"))
                        {
                            System.out.println("Priest: Your guess correct. I have a tail. I'll give you a potion that will heal your wounds. Good luck in your future journey. My master is not as forgiving as I am.");
                            System.out.println("You drink the potion and your HP is boosted by 50 HP.");
                            hp = hp + 50;
                        }
                        else
                        {
                            System.out.println("Priest: You are wrong. I have a head. I guess you are just as lucky as others who have entered this tower. I shall follow my master's order and attack you! (Type in your response)");
                            input = kb.nextLine();
                            if(input.equals("attack with dagger"))
                            {
                                System.out.println("You killed the Priest, and his body dissolves into black sand.");
                            }
                            else
                            {
                                System.out.println("Your action has no affect, and he bites your neck. You manage to get away, but you receive 20 HP damage.");
                                hp = hp - 20;
                                if(hp <= 0)
                                {
                                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                    input = kb.nextLine();
                                    if(input.equals("end") || input.equals("End"))
                                    {
                                        System.exit(0);
                                    }
                                }
                                System.out.println("You have " + hp + "HP left.");
                            }
                        }
                    }
                }    
                else if(Priest)
                {
                    System.out.println("You have already talked to me. Keep goinig on your journey up this tower.");
                }
            }        
            else if(input.equals("look at door") || input.equals("look at the door"))
            {
                System.out.println("It's a stone door that seems to swirl open when you nudge it. I think you can 'open' it without using any tools.");
            }
            else if(input.equals("open door") || input.equals("open the door"))
            {
                System.out.println("The trapdoor swings open and you fall into a pit. You find yourself surrounded by scorpions in a room and you lose 20 HP before you manage to climb out.");
                hp = hp - 20;
                if(hp <= 0)
                {
                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                    input = kb.nextLine();
                    if(input.equals("end") || input.equals("End"))
                    {
                        System.exit(0);
                    }
                }
                System.out.println("You have " + hp + "HP left.");
            }
            else if(input.equals("inventory") || input.equals("inventory"))
            {
                inventory();
            }
            else if(input.equals("room1"))
            {
                System.out.println("You climb down the stairs into the room in first floor.");
                room1();
            }
            else if(input.equals("use ladder") || input.equals("use the ladder"))
            {
                if(ladder)
                {
                    System.out.println("You descend down to the abyss. From now on, you can use 'room3' to get to the floor3 and 'room2' to return to the current floor.");
                    room3 = true;
                    room3();
                }
                else
                {
                    System.out.println("You have not unlocked the ladder yet.");
                }
            }
            else if(input.equals("room3"))
            {
                System.out.println("You descend to the floor3, The Dungeon of the Underground God.");
                room3();
            }
            else
            {
                System.out.println("Sorry, you cannot do that. Please try something else.");
            }
        }
    }
    public static void room3()
    {
        System.out.println("Stage 1, floor 3 (last floor of the stage): The Dungeon of the Underground God");
        System.out.println("After you descend from the rope, you see a dark, wet underground chamber. use 'room'.");
        while(true)     
        {
            System.out.println("What do you want to do?");
            input = kb.nextLine();
            if(!river)
            {
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                    System.out.println("It's a dungeon filled with the most gruesome monsters you've ever seen. You see one central figure: 'guide'.");
                }
                else if(input.equals("look at guide") || input.equals("look at the guide") || input.equals("look at Guide") || input.equals("look at the Guide"))
                {
                    System.out.println("The guide is wearing a withering robe and is holding a pole in front of a churning river. He looks like a Greek mythical feature (You can use one of your commands on him)");
                }
                else if(input.equals("talk to guide") || input.equals("talk to the guide") || input.equals("talk to Guide") || input.equals("talk to the Guide"))
                {
                    if(!river)
                    {
                        System.out.println("Guide: My name is Charon, but just call me 'guard'. My lord is waiting for you across the Styx river, but you must fist pass the test.");
                        System.out.println("_____ __ ________. Enter the words corresponding to the quiz in lower case (each _ is a letter). The words are the key words you could have found in the floor 1 and floor 2.");
                        input = kb.nextLine();
                        if(input.equals("curse of love"))
                        {
                            System.out.println("Charon: Good! You have passed the test, now you may ride my boat across the river to face your trials.");
                            river = true;
                            System.out.println("Charon takes you on his boat and across the river Styx filled with corpses of past warriors.");
                            System.out.println("Charon: If you dip your body into the river, you will become invinsible like Achilles. (Type in 'yes' or 'no')");
                            input = kb.nextLine();
                            if(input.equals("yes") || input.equals("Yes") || input.equals("yep") || input.equals("Yep"))
                            {
                                System.out.println("Charon: Hahahahaha!!! (Charon pushes you off the boat)");
                                System.out.println("You fall into the river and your body starts to burn. You manage to swim out of the river and you notice that your body is glowing!");
                                System.out.println("You have acquired the Curse of Achilles, and you will take no damage unless you are attacked at your heel, which somehow didn't touch the water.");
                                curse2 = true;
                                System.out.println("You are now on the other side of the river, and you can go back by just using 'room1' or 'room2' (Charon left the boat for you to use)");
                            }
                        }
                    }
                    else if(river)
                    {
                        System.out.println("You have already passed the test and Charon has left a boat for you to use. (You don't need to use the boat)");
                    }
                }
            }
            else if(!Hades)
            {
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                    System.out.println("You can see ");
                }
            }
            else if(Hades)
            {
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                    System.out.println("");
                }
            }
            else if(input.equals("inventory") || input.equals("inventory"))
            {
                inventory();
            }
            else if(input.equals("room1"))
            {
                System.out.println("You climb up the ladder to the room in first floor.");
                room1();
            }
            else if(input.equals("room2"))
            {
                System.out.println("You climb up the ladder to the room in second floor.");
                room2();
            }
        }
    }
    public static void inventory()
    {
        System.out.println("The commands you can use are: 'look at', 'use', 'open', 'trade', 'attack with', and 'flee'.");
        System.out.println("In Stage1, floor1, ('room1') you've discover the following:");
        if(!torch)
        {
            System.out.println("'torch', 'wall'");
        }
        else if(!Sphinx)
        {
            System.out.println("'torch', 'wall', 'chest', 'obelisk', 'stage'");
        }
        else if(!key)
        {
            System.out.println("'torch', 'wall', 'chest', 'obelisk', 'stage', 'Sphinx'");
        }
        else if(!keyhole)
        {
            System.out.println("'torch', 'wall', 'chest', 'obelisk', 'stage', 'Sphinx', 'gate', you also possess an object called 'key'.");
        }
        else if(keyhole)
        {
            System.out.println("'torch', 'wall', 'chest', 'obelisk', 'stage', 'Sphinx', 'gate', 'keyhole', you also possess an object called 'key'.");
        }
        if(dagger)
        {
            System.out.println("You also possess follwing equipments: 'dagger'");
        }
        if(room2)
        {   
            System.out.println("In Stage1, floor2, ('room2') you've discover the following:");
            if(!hole)
            {
                System.out.println("'cast', 'Priest', 'closet', and 'door'.");
                if(use_cast)
                {
                    System.out.println("'hole'");
                }
            }
            else if(!ladder)
            {
                System.out.println("'cast', 'Priest', 'closet', 'door', 'carving', and 'hole'.");
            }
            else if(ladder)
            {
                System.out.println("'cast', 'Priest', 'closet', 'door', 'carving', 'hole', and 'ladder'.");
            }
            if(paper)
            {
                System.out.println("You also possess follwing equipments: 'dagger', 'toliet paper'."); 
            }
            if(open && !mummy)
            {
                System.out.println("'mummy'");
            }
        }    
        System.out.println("To look at the key words you've discovered so far, type 'book'.");
        input = kb.nextLine();
        {
            if(input.equals("book"))
            {
                book();
            }
        }
    } 
    public static void book()
    {
        if(curse)
        {
            System.out.println("curse");
        }
        if(key)
        {
            System.out.println("Achilles");
        }
        if(carving)
        {
            System.out.println("Each _ is a letter, and the two letters combinded makes the word you need.");
            System.out.println("_ver the hill stood the Pharoah with his almighty,"); 
            System.out.println("who _ell to the Dark Lord's curse and laid in the cast for eternity.");
        }
    }
} 