import java.util.Scanner;
import java.util.Random;
/**
 * Write a description of class twofonechooseyourown here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MazeofTime
{
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    static String input = "";
    static boolean torch = false; 
    static boolean paper = false;
    static boolean key = false;
    static boolean room2 = false;
    static int hp = 100;
    public static void main()
    {
        System.out.println("Welcome to the game of 'Escape the Maze of Time', where you'll have to make your way out of series of mythical rooms to escape the maze.");
        System.out.println("You will use objects/subjects in the rooms and basic command words to escape the rooms.");
        System.out.println("Basic commands are (6 in total): 'look at', 'use', 'open', 'trade with', 'attack with', and 'flee'.");
        System.out.println("All the usable objects in the room will be inside '' mark, including some other features that are usable in the game.");
        System.out.println("This is the way to use commands: command + object name  - Example of this is: look at room");
        System.out.println("The command 'flee' is used without any object following it. (ex: flee). Also, if you do not have a weapon and you are attacked, just type in 'flee'.");
        System.out.println("Type in 'inventory' to look at commands and objects/treasures in rooms you have discovered so far.");
        System.out.println("Are you ready to travel back in time and enter the maze? (yes or no)");
        input = kb.nextLine();
        if(input.equals("yes") || input.equals("Yes") || input.equals("yep") || input.equals("Yep"))
        {
            System.out.println("Excellent! Let's now enter the maze.");
            room1();
        }
        else
        {
            System.exit(0);
        }
    }
    public static void room1()
    {
        System.out.println("You are an archaelogist surveying an ancient Egyptian temple.");
        System.out.println("Suddenly, the sand beneath you fails and you fall into a 'room'.");
        System.out.println("The ceiling above you shuts and you can't see a way out of this 'room'. Try to escape alive!");
        System.out.println("You start with 100 HP, and you lose when you have 0 HP left. "); /** **/
        while(true)     
        {
                System.out.println("What do you want to do?");
                input = kb.nextLine();
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                    if(!torch)
                    {
                        System.out.println("The room is very dark and you can only see silhouettes of two things: 'torch' and 'wall'");
                    }    
                    else
                    {
                        System.out.println("The room is an ancient Egyptian chamber with three things: 'chest', 'obelisk', and 'stage' at the other side of the chamber.");
                        System.out.println("There are also writing on 'wall' and the 'torch' that you've already ignited.");
                    }
                }
                else if(input.equals("look at wall") || input.equals("look at the wall"))
                {
                    System.out.println("You read an Egyptian hierographies, and it says that you will be trapped down here until the Great Pharaoh awakes to 'curse' you.");
                    System.out.println("The word 'curse' is stuck in your mind. It maybe useful in the future."); 
                }
                else if(input.equals("look at torch") || input.equals("look at the torch"))
                {
                    if(!torch)
                    {
                        System.out.println("It's an old wooden torch that seems to be ignitable when you 'use' it.");
                    }
                    else
                    {
                        System.out.println("You already ignited the torch.");   
                    }
                }
                else if(input.equals("use torch") || input.equals("use the torch"))
                {
                    if(!torch)
                    {
                        System.out.println("You ignite the torch and suddenly the room glows brightly");
                        torch = true;
                        System.out.println("The room turns out to be a golden Egytian chamber with three things: 'chest', 'obelisk', and 'stage' at the other side of the chamber, and includes the 'wall' and 'torch' you've discovered already.");
                    }
                    else
                    {
                        System.out.println("You already ignited the torch.");
                    }
                }
                else if(input.equals("look at chest") || input.equals("look at the chest"))
                {
                    System.out.println("It's a wooden chest that requires a five-letter password to open.");
                }
                else if(input.equals("look at obelisk") || input.equals("look at the obelisk") || input.equals("use obelisk") || input.equals("use the obelisk"))
                {
                    System.out.println("It has a puzzle written on it. Try to figure it out (Tip: look closely at letters, not their meanings), and remember the answer(It's a word). It may be useful.");
                    System.out.println("Cat U Rinse Shower Eew");
                }
                else if(input.equals("look at stage") || input.equals("look at the stage"))
                {
                    System.out.println("You can see stone stairs leading up to a golden stage, with a Sphinx guarding something behind it.");
                    System.out.println("You can 'use' the stage to climb it.");
                }
                else if(input.equals("use chest") || input.equals("use the chest") || input.equals("open chest") || input.equals("open the chest"))
                {
                    System.out.println("You must enter a five-letter password in order to open the chest");
                    String password1 = kb.nextLine();
                    if(password1.equals("Curse") || password1.equals("curse") || password1.equals("CURSE"))
                    {
                        if(!paper)
                        {
                            System.out.println("You opened the chest! You find some 'toliet paper' and keep it. You can 'attack with' it whenever you are attacked.");
                            paper = true;
                        }
                        else
                        {
                            System.out.println("You already opened the chest and aquired toliet papers.");
                        }
                    }
                }
                else if(input.equals("use stage") || input.equals("use the stage"))
                {
                    if(!key)
                    {
                        System.out.println("You climb the stairs on to the stage.");
                        System.out.println("A Sphinx on the stage speaks to you.");
                        System.out.println("Sphinx: Answer my riddle. If you answer it true, I shall let you continue your way. If you get it wrong, I shall attack you.");
                        System.out.println("Sphinx: What can be lost, but not retured? (Type in your answer)");
                        input = kb.nextLine();
                        if(input.equals("life") || input.equals("Life"))
                        {
                            System.out.println("Sphinx: Your answer was true. You may continue your way. I shall also give you a 'key' that you shall need to open the 'gate' behind me.");
                            key = true;
                            System.out.println("You received an object: 'key', and an object in room: 'gate'");
                        }
                        else
                        {
                            System.out.println("Sphinx: Your answer is false! The Sphinx than attacks you. What will you do? (type in your reaction of your choice)");
                            input = kb.nextLine();
                            if(input.equals("flee") || input.equals("Flee"))
                            {
                                System.out.println("You barely escape the Sphinx.");
                            }
                            else 
                            {
                                System.out.println("Your method doesn't work. You are attacked by the Sphinx and you lose 1 life.");
                                hp = hp - 1;  /** **/
                                if(hp <= 0)
                                {
                                    System.out.println("You died! You failed to escape the maze. Please enter 'end' to exit the game.");
                                    input = kb.nextLine();
                                    if(input.equals("end") || input.equals("End"))
                                    {
                                        System.exit(0);
                                    }
                                }
                                System.out.println("You have " + hp + "HP left.");
                            }
                        }
                    }
                    else if(key)
                    {
                        System.out.println("You already have passed the Sphinx's riddle. You may proceed to the 'gate'.");
                    }
                }  
                else if(input.equals("look at gate") || input.equals("look at the gate"))
                {
                        System.out.println("It's an old wooden gate with a keyhole in the centre.");
                }
                else if(input.equals("open gate") || input.equals("open the gate"))
                {
                    if(!room2)
                    {
                        System.out.println("Please insert your key into the keyhole on the gate.");
                        System.out.println("You can 'use' one of your objects to open the gate.");
                        input = kb.nextLine();
                        if(input.equals("use key") || input.equals("use the key"))
                        {
                            System.out.println("The gate is open! you may proceed to the next room by typing command 'room2' and return to this chamber by 'room1'.");
                            room2 = true;
                        }
                    }
                    else
                    {
                        System.out.println("The gate is already open. You can proceed to the next room by typing command 'room2' and return to this chamber by 'room1'.");
                    }
                }
                else if(input.equals("inventory") || input.equals("inventory"))
                {
                    inventory();
                }
                else if(input.equals("room2"))
                {
                    if(room2)
                    {
                        System.out.println("You pass through the 'gate' into the second room.");
                        room2();
                    }
                    else
                    {
                        System.out.println("The 'gate' is locked.");
                    }
                }  
                else
                {
                    System.out.println("Sorry, you cannot do that. Please try something else.");
                }
        }
    }
    public static void room2()
    {
        System.out.println("You enter the 'room'.");
        while(true)     
        {
                System.out.println("What do you want to do?");
                input = kb.nextLine();
                if(input.equals("look at room") || input.equals("look at the room"))
                {
                        System.out.println("It's an ancient Egyptian tomb with four objects/subject: 'cast', 'priest', 'vase' and 'door'.");
                }
                else if(input.equals("look at cast") || input.equals("look at the cast"))
                {
                    System.out.println("It's a golden Egyptian cast with a 'hole' on the side.");
                    System.out.println("There is also a 'carving' in the side of the cast.");
                }
                else if(input.equals("use cast") || input.equals("use the cast") || input.equals("open cast") || input.equals("open the cast"))
                {
                    System.out.println("The cast would not be opened by hand, but you notice a 'hole' on the side of the cast.");
                }
                else if(input.equals("look at priest") || input.equals("look at the priest"))
                {
                    System.out.println("");
                }
                else if(input.equals("use priest") || input.equals("use the priest"))
                {
                    System.out.println("");
                }
                else if(input.equals("look at door") || input.equals("look at the door"))
                {
                    System.out.println("It's a stone door that seems to swirl open when you nudge it. I think you can 'open' it without using any tools.");
                }
                else if(input.equals("open door") || input.equals("open the door"))
                {
                    System.out.println("The door swings open and you fall into the abyss.");
                    traproom();
                }
                else if(input.equals("inventory") || input.equals("inventory"))
                {
                    inventory();
                }
                else if(input.equals("room3"))
                {
                    if(room2)
                    {
                        System.out.println("You pass through the 'gate' into the second room.");
                        room2();
                    }
                    else
                    {
                        System.out.println("The 'gate' is locked.");
                    }
                }  
                else
                {
                    System.out.println("Sorry, you cannot do that. Please try something else.");
                }
        }       
    }
    public static void inventory()
    {
        System.out.println("The commands you can use are: 'look at', 'use', 'open', 'trade', 'attack with', and 'flee'.");
        System.out.println("In Egytian chamber you've discover the following:");
        if(!torch)
        {
            System.out.println("'torch', 'wall'");
        }
        else if(!key)
        {
            System.out.println("'torch', 'wall', 'chest', 'scroll', 'stage'");
        }
        else
        {
            System.out.println("'torch', 'wall', 'chest', 'scroll', 'stage', 'gate'");
        }
        if(paper)
        {
            System.out.println("You also possess a Egyptian weapon called 'toliet paper'.");
        }
        if(key)
        {
            System.out.println("You also possess an object called 'key'.");
        }
    }
}