import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
/**
 * 여기에 RISK_METHOD 클래스 설명을 작성하십시오.
 * 
 * @author (작성자 이름) 
 * @version (버전번호나 날짜)
 */
public class RISK_METHOD
{
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    public static void main()
    {
        
    }   
}
