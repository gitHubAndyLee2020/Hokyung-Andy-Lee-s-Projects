import java.util.Scanner;
/**
 * TicTacToe game
 * 
 * @Andy_Lee 
 * @version (1.0)
 * This is a lesson from CodeHS AP Java course, I used the method titles from the online learning course, but I created all the other codes.
 */
public class TicTacToe
{
   //copy over your constructor from the Tic Tac Toe Board activity in the previous lesson!
   public static final int NUM_SPACES = 3;
   private static int turn;
   private static String[][] board;
   
   public static void main()
    {
        //This is to help you test your methods. Feel free to add code at the end to check
        //to see if your checkWin method works!
        TicTacToe game = new TicTacToe();
        System.out.println("Initial Game Board:");
        game.printBoard();
        
        //Prints the first row of turns taken
        game.takeTurn(0,0);
        game.takeTurn(1,1);
        game.takeTurn(1,0);
        game.takeTurn(2,1);
        game.takeTurn(2,0);
        game.printBoard();
        System.out.println(game.checkWin());
    
    }
   public TicTacToe()
    {
        this.board = new String[NUM_SPACES][NUM_SPACES]; 
        for(int row = 0; row < board.length; row++)
        {
            for(int col = 0; col < board[row].length; col++)
            {
                board[row][col] = "-";
            }
        }    
    }
   //this method returns the current turn
   public int getTurn()
   {
      return turn; 
   }
   
   /*This method prints out the board array on to the console
   */
   public void printBoard()
   {
       System.out.print(" ");
       for(int num = 0; num < board[0].length; num++)
       {
           System.out.print(" " + num);
       }
       System.out.println();
       for(int row = 0; row < board.length; row++)
       {
           System.out.print(row + " ");
           for(int col = 0; col < board[row].length; col++)
           {
                System.out.print(board[row][col] + " ");    
           }
           System.out.println();
       }
   }
   
   //This method returns true if space row, col is a valid space
   public boolean pickLocation(int row, int col)
   {
       if(board[row][col].equals("-"))
       {
           return true;
       }
       else
       {
           return false;
       }
   }
   
   //This method places an X or O at location row,col based on the int turn
   public void takeTurn(int row, int col)
   {
       turn++;
       if(turn % 2 == 0 && pickLocation(row,col))
       {
           board[row][col] = "O";
       }
       else if(turn % 2 == 1 && pickLocation(row,col))
       {
           board[row][col] = "X";
       }
   }
   
   //This method returns a boolean that returns true if a row has three X or O's in a row
   public boolean checkRow()
   {
       boolean checkRowFull = false;
       int numX = 0;
       int numO = 0;
       for(int row = 0; row < board.length; row++)
       {
           for(int col = 0; col < board[row].length; col++)
           {
               if(board[row][col].equals("O"))
               {
                   numO++;
               }
               else if(board[row][col].equals("X"))
               {
                   numX++;
               }
           }
           if(numO == 3)
           {
               checkRowFull = true;
           }
           else if(numX == 3)
           {
               checkRowFull = true;
           }
           numO = 0;
           numX = 0;
       }
       return checkRowFull;
   }
   
    //This method returns a boolean that returns true if a col has three X or O's
   public boolean checkCol()
   {
       boolean checkColFull = false;
       int numX = 0;
       int numO = 0;
       for(int row = 0; row < board.length; row++)
       {
           for(int col = 0; col < board[row].length; col++)
           {
               if(board[col][row].equals("O"))
               {
                   numO++;
               }
               else if(board[col][row].equals("X"))
               {
                   numX++;
               }
           }
           if(numO == 3)
           {
               checkColFull = true;
           }
           else if(numX == 3)
           {
               checkColFull = true;
           }
           numO = 0;
           numX = 0;
       }
       return checkColFull;
   }
   
    //This method returns a boolean that returns true if either diagonal has three X or O's
   public boolean checkDiag()
   {
       boolean checkDiagFull = false;
       int numX = 0;
       int numO = 0;
       for(int num = 0; num < board.length; num++)
       {
           if(board[num][num].equals("O"))
           {
               numO++;
           }
           else if(board[num][num].equals("X"))
           {
               numX++;
           }
       }
       if(numO == 3)
       {
           checkDiagFull = true;
       }
       else if(numX == 3)
       {
           checkDiagFull = true;
       }
       numO = 0;
       numX = 0;
       for(int num = 0; num < board.length; num++)
       {
           if(board[num][2 - num].equals("O"))
           {
               numO++;
           }
           else if(board[num][2 - num].equals("X"))
           {
               numX++;
           }
       }
       if(numO == 3)
       {
           checkDiagFull = true;
       }
       else if(numX == 3)
       {
           checkDiagFull = true;
       }
       return checkDiagFull;
   }
   
   //This method returns a boolean that checks if someone has won the game
   public boolean checkWin()
   {
       if(checkRow())
       {
           return true;
       }
       else if(checkCol())
       {
           return true;
       }
       else if(checkDiag())
       {
           return true;
       }
       else
       {
           return false;
       }
   }

}
