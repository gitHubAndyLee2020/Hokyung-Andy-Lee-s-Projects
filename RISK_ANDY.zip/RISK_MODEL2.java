import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.lang.String;
/**
 * RISK_Model
 * 
 * @author (Andy Lee) 
 * @version (No.1)
 */
public class RISK_MODEL2
{
    static Scanner kb = new Scanner(System.in);
    static Random rand = new Random();
    static String input = "";
    static String armyComp = "";
    static String territory = ""; 
    //
    static String botChosenLand = "";
    static String playerChosenLand = "";
    //
    static String land1 = "";
    static String land2 = "";
    //
    static ArrayList<String> listLand = new ArrayList<String>();
    static String[] land = {"AK", "NT", "AB", "ON", "E.CAN", "W.USA", "E.USA", "C.NA", "GL", "VEN", "PER", "BRA", "ARG", "ISL", "GBR", "W.EU", "N.EU", "S.EU", "SCAND", "RUS", "N.AF", "EGY", "E.AF", "C.AF", "S.AF", "MDG", "URAL", "SI", "YAKT", "PETT", "IRKT", "AFG", "MNG", "JPN", "CHN", "ME", "IND", "SE.AS", "IDN", "PNG", "W.AUS", "E.AUS"};
    static String[] North_America = {"AK", "NT", "AB", "ON", "E.CAN", "W.USA", "E.USA", "C.NA", "GL"};
    static String[] South_America = {"VEN", "PER", "BRA", "ARG"};
    static String[] Europe = {"ISL", "GBR", "W.EU", "N.EU", "S.EU", "SCAND", "RUS"};
    static String[] Africa = {"N.AF", "EGY", "E.AF", "C.AF", "S.AF", "MDG"};
    static String[] Asia = {"URAL", "SI", "YAKT", "PETT", "IRKT", "AFG", "MNG", "JPN", "CHN", "ME", "IND", "SE.AS"};
    static String[] Australia = {"IDN", "PNG", "W.AUS", "E.AUS"};
    static int[] playerArmy = new int[land.length];
    static int[] botArmy = new int[land.length];
    static int[] landImp = new int[land.length];
    static int[] landImpOff = new int[land.length];
    static int[] landImpDef = new int[land.length];
    static double[] desirability = new double[6];
    static boolean[] botControlledContinents = new boolean[6];
    static boolean[] landBoolean = new boolean[land.length];
    static ArrayList<String> playerLand = new ArrayList<String>();
    static ArrayList<String> botLand = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefNA = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefSA = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefEU = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefAF = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefAS = new ArrayList<String>();
    static ArrayList<String> surroundingTerrDefAU = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffNA = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffSA = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffEU = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffAF = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffAS = new ArrayList<String>();
    static ArrayList<String> surroundingTerrOffAU = new ArrayList<String>();
    static String[] playerPicked = new String[land.length];
    static String[] botPicked = new String[land.length];
    static boolean playerFirst = true;
    static boolean playerPickTurn = true;
    static boolean botPickTurn = true;
    static boolean alreadyPickedLand = true;
    static boolean flip = false;
    static boolean randomRight = false;
    static boolean available = false;
    static boolean own = false;
    static boolean playerTurn = true;
    static boolean tradeInCards = false;
    static boolean trade = false;
    static boolean matchTerritory = false;
    static boolean match = false;
    static boolean placeTroop = false;
    static boolean deployment = false;
    static boolean lackOfCard = false;
    //
    static boolean alreadyBotPick = false;
    static boolean botNorth_America = false;
    static boolean botSouth_America = false;
    static boolean botEurope = false;
    static boolean botAfrica = false;
    static boolean botAsia = false;
    static boolean botAustralia = false;
    static boolean playerChoose = false;
    //
    static boolean ranOutPlayerTroop = false;
    static boolean ranOutBotTroop = false;
    static boolean firstAddPlayerArmy = false;
    static boolean firstAddBotArmy = false;
    static boolean landAttackAvailability = false;
    static boolean botPlace = false;
    static boolean playerPlacementDone = false;
    static boolean bordering = false;
    static boolean botTroopPlacementRand = false;
    static boolean firstFlip = false;
    static boolean pMB1 = false;
    static boolean pMB2 = false;
    static boolean firstCard = false;
    //
    static boolean AK = false;
    static boolean NT = false;
    static boolean GL = false;
    static boolean AB = false;
    static boolean ON = false;
    static boolean ECAN = false;
    static boolean WUSA = false;
    static boolean EUSA = false;
    static boolean CNA = false;
    static boolean VEN = false;
    static boolean PER = false;
    static boolean BRA = false;
    static boolean ARG = false;
    static boolean ISL = false;
    static boolean GBR = false;
    static boolean SCAND = false;
    static boolean WEU = false;
    static boolean NEU = false;
    static boolean RUS = false;
    static boolean SEU = false;
    static boolean NAF = false;
    static boolean EGY = false;
    static boolean CAF = false;
    static boolean EAF = false;
    static boolean SAF = false;
    static boolean MDG = false;
    static boolean URAL = false;
    static boolean SI = false;
    static boolean YAKT = false;
    static boolean PETT = false;
    static boolean AFG = false;
    static boolean IRKT = false;
    static boolean MNG = false;
    static boolean JPN = false;
    static boolean ME = false;
    static boolean IND = false;
    static boolean CHN = false;
    static boolean SEAS = false;
    static boolean IDN = false;
    static boolean PNG = false;
    static boolean WAUS = false;
    static boolean EAUS = false;
    //
    static boolean pAK = false;
    static boolean pNT = false;
    static boolean pGL = false;
    static boolean pAB = false;
    static boolean pON = false;
    static boolean pECAN = false;
    static boolean pWUSA = false;
    static boolean pEUSA = false;
    static boolean pCNA = false;
    static boolean pVEN = false;
    static boolean pPER = false;
    static boolean pBRA = false;
    static boolean pARG = false;
    static boolean pISL = false;
    static boolean pGBR = false;
    static boolean pSCAND = false;
    static boolean pWEU = false;
    static boolean pNEU = false;
    static boolean pRUS = false;
    static boolean pSEU = false;
    static boolean pNAF = false;
    static boolean pEGY = false;
    static boolean pCAF = false;
    static boolean pEAF = false;
    static boolean pSAF = false;
    static boolean pMDG = false;
    static boolean pURAL = false;
    static boolean pSI = false;
    static boolean pYAKT = false;
    static boolean pPETT = false;
    static boolean pAFG = false;
    static boolean pIRKT = false;
    static boolean pMNG = false;
    static boolean pJPN = false;
    static boolean pME = false;
    static boolean pIND = false;
    static boolean pCHN = false;
    static boolean pSEAS = false;
    static boolean pIDN = false;
    static boolean pPNG = false;
    static boolean pWAUS = false;
    static boolean pEAUS = false;
    //
    static boolean goAK = false;
    static boolean goNT = false;
    static boolean goGL = false;
    static boolean goAB = false;
    static boolean goON = false;
    static boolean goECAN = false;
    static boolean goWUSA = false;
    static boolean goEUSA = false;
    static boolean goCNA = false;
    static boolean goVEN = false;
    static boolean goPER = false;
    static boolean goBRA = false;
    static boolean goARG = false;
    static boolean goISL = false;
    static boolean goGBR = false;
    static boolean goSCAND = false;
    static boolean goWEU = false;
    static boolean goNEU = false;
    static boolean goRUS = false;
    static boolean goSEU = false;
    static boolean goNAF = false;
    static boolean goEGY = false;
    static boolean goCAF = false;
    static boolean goEAF = false;
    static boolean goSAF = false;
    static boolean goMDG = false;
    static boolean goURAL = false;
    static boolean goSI = false;
    static boolean goYAKT = false;
    static boolean goPETT = false;
    static boolean goAFG = false;
    static boolean goIRKT = false;
    static boolean goMNG = false;
    static boolean goJPN = false;
    static boolean goME = false;
    static boolean goIND = false;
    static boolean goCHN = false;
    static boolean goSEAS = false;
    static boolean goIDN = false;
    static boolean goPNG = false;
    static boolean goWAUS = false;
    static boolean goEAUS = false;
    //
    static boolean bAK = false;
    static boolean bNT = false;
    static boolean bGL = false;
    static boolean bAB = false;
    static boolean bON = false;
    static boolean bECAN = false;
    static boolean bWUSA = false;
    static boolean bEUSA = false;
    static boolean bCNA = false;
    static boolean bVEN = false;
    static boolean bPER = false;
    static boolean bBRA = false;
    static boolean bARG = false;
    static boolean bISL = false;
    static boolean bGBR = false;
    static boolean bSCAND = false;
    static boolean bWEU = false;
    static boolean bNEU = false;
    static boolean bRUS = false;
    static boolean bSEU = false;
    static boolean bNAF = false;
    static boolean bEGY = false;
    static boolean bCAF = false;
    static boolean bEAF = false;
    static boolean bSAF = false;
    static boolean bMDG = false;
    static boolean bURAL = false;
    static boolean bSI = false;
    static boolean bYAKT = false;
    static boolean bPETT = false;
    static boolean bAFG = false;
    static boolean bIRKT = false;
    static boolean bMNG = false;
    static boolean bJPN = false;
    static boolean bME = false;
    static boolean bIND = false;
    static boolean bCHN = false;
    static boolean bSEAS = false;
    static boolean bIDN = false;
    static boolean bPNG = false;
    static boolean bWAUS = false;
    static boolean bEAUS = false;
    //
    static boolean eAK = false;
    static boolean eNT = false;
    static boolean eGL = false;
    static boolean eAB = false;
    static boolean eON = false;
    static boolean eECAN = false;
    static boolean eWUSA = false;
    static boolean eEUSA = false;
    static boolean eCNA = false;
    static boolean eVEN = false;
    static boolean ePER = false;
    static boolean eBRA = false;
    static boolean eARG = false;
    static boolean eISL = false;
    static boolean eGBR = false;
    static boolean eSCAND = false;
    static boolean eWEU = false;
    static boolean eNEU = false;
    static boolean eRUS = false;
    static boolean eSEU = false;
    static boolean eNAF = false;
    static boolean eEGY = false;
    static boolean eCAF = false;
    static boolean eEAF = false;
    static boolean eSAF = false;
    static boolean eMDG = false;
    static boolean eURAL = false;
    static boolean eSI = false;
    static boolean eYAKT = false;
    static boolean ePETT = false;
    static boolean eAFG = false;
    static boolean eIRKT = false;
    static boolean eMNG = false;
    static boolean eJPN = false;
    static boolean eME = false;
    static boolean eIND = false;
    static boolean eCHN = false;
    static boolean eSEAS = false;
    static boolean eIDN = false;
    static boolean ePNG = false;
    static boolean eWAUS = false;
    static boolean eEAUS = false;
    //
    static boolean botTerrInNA = false;
    static boolean botTerrInSA = false;
    static boolean botTerrInEU = false;
    static boolean botTerrInAF = false;
    static boolean botTerrInAS = false;
    static boolean botTerrInAU = false;
    //
    static int pick = 0;
    static int playerSpareArmy = 0;
    static int botSpareArmy = 0;
    static int matchContinent = 0;
    static int card = 0;
    static int numDeployed = 0;
    static int botDeployed = 0;
    //
    static int sameContinent = 5;
    static int additionalBotLand = 198;
    static int diffContinent = 1;
    static int botIndexLand = 0;
    static int securePlacement = 5;
    static int freePlacement = 0;
    static int botPlaceIndex = 0;
    static int numAttack = 0;
    static int botCard = 0;
    
    static int vulnerabilityNA = 0;
    static int vulnerabilitySA = 0;
    static int vulnerabilityEU = 0;
    static int vulnerabilityAF = 0;
    static int vulnerabilityAS = 0;
    static int vulnerabilityAU = 0;
    
    static boolean landAttackAvailability2 = false;
    public static void main(String[] args)
    {
        setUp();
    }
    private static void setUp()
    {
        for(String list : land)
        {
            listLand.add(list);
        }    
        coinFlip();
    }    
    private static void playerMasterBoard()
    {
        addPlayerArmy();
        if(attackTurnsAvailability(playerLand, botLand, playerArmy))
        {
            numAttack = getNumAttack();
            while(numAttack > 0)
            {
                if(attackTurnsAvailability(playerLand, botLand, playerArmy))
                {
                    while(!pMB1)
                    {
                        if(playerLand.size() == land.length)
                        {
                            System.out.println("Congratulation! You have defeated Athena and conquered the world!");
                            System.out.println("Please enter any keys to exit the game.");
                            input = kb.nextLine();
                            System.exit(0);
                        }    
                        System.out.println("You can attack Athena's territories up to " + numAttack + " time(s).");
                        System.out.println("Would you like to attack? (type yes or no)");
                        input = kb.nextLine();
                        if(input.equals("yes") || input.equals("Yes") || input.equals("YES"))
                        {
                            pMB1 = true;
                            playerAttack();
                        }   
                        else if(input.equals("no") || input.equals("No") || input.equals("NO"))
                        {
                            pMB1 = true;
                            numAttack = 0;
                        }
                        else
                        {
                            System.out.println("Sorry, please type in either yes or no.");
                        }    
                    }
                    pMB1 = false;
                }
                else
                {
                    System.out.println("Non of the territories you control that have more than 1 troop is bordering an Athena's territory, so you cannot attack anymore.");
                    numAttack = 0;
                }    
            }
        }
        else
        {
            System.out.println("Non of the territories you control that have more than 1 troop is bordering an Athena's territory, so you cannot attack this turn.");
        }    
        if(playerLand.size() == land.length)
        {
            System.out.println("Congratulation! You have defeated Athena and conquered the world!");
            System.out.println("Please enter any keys to exit the game.");
            input = kb.nextLine();
            System.exit(0);
        }
        while(!pMB2)
        {
            System.out.println("Please type in yes or no whether you want to move your troops in one of the territories to another.");
            input = kb.nextLine();
            if(input.equals("yes") || input.equals("Yes") || input.equals("YES")) 
            {
                playerMove();
                pMB2 = true;
            }
            else if(input.equals("no") || input.equals("No") || input.equals("NO"))
            {
                pMB2 = true;
            }
            else
            {
                System.out.println("Sorry, please type in yes or no.");
            }   
        }
        pMB2 = false;
        System.out.println("Your turn is finished. Now Athena will go.");
        botMasterBoard();
    }
    private static void botMasterBoard() 
    {
        botAddArmy();
        playerMasterBoard();
    }
    private static void playerMove()
    {
        boolean pM1 = false;
        boolean pM2 = false;
        boolean pM3 = false;
        boolean move = false;
        boolean movable = false;
        int numTroop = 0;
        int numTroopMove = 0;
        while(!movable)
        {
            while(!pM1)
            {
                System.out.println("Please type in the name of the territory you want to move your troop(s) from.");
                input = kb.nextLine();
                for(int i = 0; i < playerLand.size(); i++)
                {
                    if(input.equals(playerLand.get(i)))
                    {
                        land1 = input;
                        numTroop = playerArmy[getIndex(land1)];
                        if(numTroop > 1)
                        {
                            pM1 = true;
                        }
                        else
                        {
                            System.out.println("Please pick a land that has more than 1 troop on it.");
                        }    
                    }    
                }    
            }
            pM1 = false;
            while(!pM3)
            {
                System.out.println("Please type in the name of the territory you want to move your troop(s) to.");
                input = kb.nextLine();
                for(int i = 0; i < playerLand.size(); i++)
                {
                    if(input.equals(playerLand.get(i)))
                    {
                        land2 = input;
                        pM3 = true; 
                    }     
                }    
            }
            pM3 = false;
            boolean connectivity = getPlayerConnectivity(land1, land2);
            if(connectivity)
            {
                movable = true;
            }
            else
            {
                System.out.println(land1 + " and " + land2 + " are not connected. Please try again using different combination of territories.");
            }    
        }
        while(!pM2)
        {
            System.out.println("How many troops will you move from " + land1 + "?");
            input = kb.nextLine();
            for(int i = 1; i < numTroop; i++)
            {
                String str = String.valueOf(i);
                if(input.equals(str))
                {
                    move = true;
                    numTroopMove = i;
                    i = numTroop;
                }    
            }
            if(move)
            {
                pM2 = true;
            }
            else
            {
                System.out.println("Please type in the number in integer that is between 1 and " + (numTroop - 1) + ".");
            }    
        }
        playerArmy[getIndex(land1)] -= numTroopMove;
        playerArmy[getIndex(land2)] += numTroopMove;
        getMap();
    }
    public static boolean getPlayerConnectivity(String land1, String land2)
    {
        AK = false;
        NT = false;
        GL = false;
        AB = false;
        ON = false;
        ECAN = false;
        WUSA = false;
        EUSA = false;
        CNA = false;
        VEN = false;
        PER = false;
        BRA = false;
        ARG = false;
        ISL = false;
        GBR = false;
        SCAND = false;
        WEU = false;
        NEU = false;
        RUS = false;
        SEU = false;
        NAF = false;
        EGY = false;
        CAF = false;
        EAF = false;
        SAF = false;
        MDG = false;
        URAL = false;
        SI = false;
        YAKT = false;
        PETT = false;
        AFG = false;
        IRKT = false;
        MNG = false;
        JPN = false;
        ME = false;
        IND = false;
        CHN = false;
        SEAS = false;
        IDN = false;
        PNG = false;
        WAUS = false;
        EAUS = false;
        //
        pAK = false;
        pNT = false;
        pGL = false;
        pAB = false;
        pON = false;
        pECAN = false;
        pWUSA = false;
        pEUSA = false;
        pCNA = false;
        pVEN = false;
        pPER = false;
        pBRA = false;
        pARG = false;
        pISL = false;
        pGBR = false;
        pSCAND = false;
        pWEU = false;
        pNEU = false;
        pRUS = false;
        pSEU = false;
        pNAF = false;
        pEGY = false;
        pCAF = false;
        pEAF = false;
        pSAF = false;
        pMDG = false;
        pURAL = false;
        pSI = false;
        pYAKT = false;
        pPETT = false;
        pAFG = false;
        pIRKT = false;
        pMNG = false;
        pJPN = false;
        pME = false;
        pIND = false;
        pCHN = false;
        pSEAS = false;
        pIDN = false;
        pPNG = false;
        pWAUS = false;
        pEAUS = false;
        //
        goAK = false;
        goNT = false;
        goGL = false;
        goAB = false;
        goON = false;
        goECAN = false;
        goWUSA = false;
        goEUSA = false;
        goCNA = false;
        goVEN = false;
        goPER = false;
        goBRA = false;
        goARG = false;
        goISL = false;
        goGBR = false;
        goSCAND = false;
        goWEU = false;
        goNEU = false;
        goRUS = false;
        goSEU = false;
        goNAF = false;
        goEGY = false;
        goCAF = false;
        goEAF = false;
        goSAF = false;
        goMDG = false;
        goURAL = false;
        goSI = false;
        goYAKT = false;
        goPETT = false;
        goAFG = false;
        goIRKT = false;
        goMNG = false;
        goJPN = false;
        goME = false;
        goIND = false;
        goCHN = false;
        goSEAS = false;
        goIDN = false;
        goPNG = false;
        goWAUS = false;
        goEAUS = false;
        //
        boolean playerConnected = false;
        for(int i = 0; i < playerLand.size(); i++)
        {
            if(playerLand.get(i).equals("AK"))
            {
                pAK = true;
            }
            else if(playerLand.get(i).equals("NT"))
            {
                pNT = true;
            }
            else if(playerLand.get(i).equals("GL"))
            {
                pGL = true;
            }
            else if(playerLand.get(i).equals("AB"))
            {
                pAB = true;
            }
            else if(playerLand.get(i).equals("ON"))
            {
                pON = true;
            }
            else if(playerLand.get(i).equals("E.CAN"))
            {
                pECAN = true;
            }
            else if(playerLand.get(i).equals("W.USA"))
            {
                pWUSA = true;
            }
            else if(playerLand.get(i).equals("E.USA"))
            {
                pEUSA = true;
            }
            else if(playerLand.get(i).equals("C.NA"))
            {
                pCNA = true;
            }
            else if(playerLand.get(i).equals("VEN"))
            {
                pVEN = true;
            }
            else if(playerLand.get(i).equals("PER"))
            {
                pPER = true;
            }
            else if(playerLand.get(i).equals("BRA"))
            {
                pBRA = true;
            }
            else if(playerLand.get(i).equals("ARG"))
            {
                pARG = true;
            }
            else if(playerLand.get(i).equals("N.AF"))
            {
                pNAF = true;
            }
            else if(playerLand.get(i).equals("EGY"))
            {
                pEGY = true;
            }
            else if(playerLand.get(i).equals("C.AF"))
            {
                pCAF = true;
            }
            else if(playerLand.get(i).equals("E.AF"))
            {
                pEAF = true;
            }
            else if(playerLand.get(i).equals("S.AF"))
            {
                pSAF = true;
            }
            else if(playerLand.get(i).equals("MDG"))
            {
                pMDG = true;
            }
            else if(playerLand.get(i).equals("ISL"))
            {
                pISL = true;
            }
            else if(playerLand.get(i).equals("GBR"))
            {
                pGBR = true;
            }
            else if(playerLand.get(i).equals("SCAND"))
            {
                pSCAND = true;
            }
            else if(playerLand.get(i).equals("W.EU"))
            {
                pWEU = true;
            }
            else if(playerLand.get(i).equals("N.EU"))
            {
                pNEU = true;
            }
            else if(playerLand.get(i).equals("RUS"))
            {
                pRUS = true;
            }
            else if(playerLand.get(i).equals("S.EU"))
            {
                pSEU = true;
            }
            else if(playerLand.get(i).equals("URAL"))
            {
                pURAL = true;
            }
            else if(playerLand.get(i).equals("SI"))
            {
                pSI = true;
            }
            else if(playerLand.get(i).equals("YAKT"))
            {
                pYAKT = true;
            }
            else if(playerLand.get(i).equals("PETT"))
            {
                pPETT = true;
            }
            else if(playerLand.get(i).equals("AFG"))
            {
                pAFG = true;
            }
            else if(playerLand.get(i).equals("IRKT"))
            {
                pIRKT = true;
            }
            else if(playerLand.get(i).equals("MNG"))
            {
                pMNG = true;
            }
            else if(playerLand.get(i).equals("JPN"))
            {
                pJPN = true;
            }
            else if(playerLand.get(i).equals("ME"))
            {
                pME = true;
            }
            else if(playerLand.get(i).equals("IND"))
            {
                pIND = true;
            }
            else if(playerLand.get(i).equals("CHN"))
            {
                pCHN = true;
            }
            else if(playerLand.get(i).equals("SE.AS"))
            {
                pSEAS = true;
            }
            else if(playerLand.get(i).equals("IDN"))
            {
                pIDN = true;
            }
            else if(playerLand.get(i).equals("PNG"))
            {
                pPNG = true;
            }
            else if(playerLand.get(i).equals("W.AUS"))
            {
                pWAUS = true;
            }
            else if(playerLand.get(i).equals("E.AUS"))
            {
                pEAUS = true;
            }
        }
        if(land1.equals("AK"))
        {
            AK = true;
        }
        else if(land1.equals("NT"))
        {
            NT = true;
        }
        else if(land1.equals("GL"))
        {
            GL = true;
        }
        else if(land1.equals("AB"))
        {
            AB = true;
        }
        else if(land1.equals("ON"))
        {
            ON = true;
        }
        else if(land1.equals("E.CAN"))
        {
            ECAN = true;
        }
        else if(land1.equals("W.USA"))
        {
            WUSA = true;
        }
        else if(land1.equals("E.USA"))
        {
            EUSA = true;
        }
        else if(land1.equals("C.NA"))
        {
            CNA = true;
        }
        else if(land1.equals("VEN"))
        {
            VEN = true;
        }
        else if(land1.equals("PER"))
        {
            PER = true;
        }
        else if(land1.equals("BRA"))
        {
            BRA = true;
        }
        else if(land1.equals("ARG"))
        {
            ARG = true;
        }
        else if(land1.equals("N.AF"))
        {
            NAF = true;
        }
        else if(land1.equals("EGY"))
        {
            EGY = true;
        }
        else if(land1.equals("C.AF"))
        {
            CAF = true;
        }
        else if(land1.equals("E.AF"))
        {
            EAF = true;
        }
        else if(land1.equals("S.AF"))
        {
            SAF = true;
        }
        else if(land1.equals("MDG"))
        {
            MDG = true;
        }
        else if(land1.equals("ISL"))
        {
            ISL = true;
        }
        else if(land1.equals("GBR"))
        {
            GBR = true;
        }
        else if(land1.equals("SCAND"))
        {
            SCAND = true;
        }
        else if(land1.equals("W.EU"))
        {
            WEU = true;
        }
        else if(land1.equals("N.EU"))
        {
            NEU = true;
        }
        else if(land1.equals("RUS"))
        {
            RUS = true;
        }
        else if(land1.equals("S.EU"))
        {
            SEU = true;
        }
        else if(land1.equals("URAL"))
        {
            URAL = true;
        }
        else if(land1.equals("SI"))
        {
            SI = true;
        }
        else if(land1.equals("YAKT"))
        {
            YAKT = true;
        }
        else if(land1.equals("PETT"))
        {
            PETT = true;
        }
        else if(land1.equals("AFG"))
        {
            AFG = true;
        }
        else if(land1.equals("IRKT"))
        {
            IRKT = true;
        }
        else if(land1.equals("MNG"))
        {
            MNG = true;
        }
        else if(land1.equals("JPN"))
        {
            JPN = true;
        }
        else if(land1.equals("ME"))
        {
            ME = true;
        }
        else if(land1.equals("IND"))
        {
            IND = true;
        }
        else if(land1.equals("CHN"))
        {
            CHN = true;
        }
        else if(land1.equals("SE.AS"))
        {
            SEAS = true;
        }
        else if(land1.equals("IDN"))
        {
            IDN = true;
        }
        else if(land1.equals("PNG"))
        {
            PNG = true;
        }
        else if(land1.equals("W.AUS"))
        {
            WAUS = true;
        }
        else if(land1.equals("E.AUS"))
        {
            EAUS = true;
        }
        //
        for(int i = 0; i < 10; i++)
        {
            if(!goAK)
            {
                if(AK)
                {
                    if(pNT)
                    {
                        NT = true;
                    }
                    if(pAB)
                    {
                        AB = true;
                    }
                    if(pPETT)
                    {
                        PETT = true;
                    }
                    goAK = true;
                }
            }
            if(!goNT)
            {
                if(NT)
                {
                    if(pAK)
                    {
                        AK = true;
                    }
                    if(pAB)
                    {
                        AB = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pGL)
                    {
                        GL = true;
                    }
                    goNT = true;
                }
            }
            if(!goAB)
            {
                if(AB)
                {
                    if(pAK)
                    {
                        AK = true;
                    }
                    if(pNT)
                    {
                        NT = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pWUSA)
                    {
                        WUSA = true;
                    }
                    goAB = true;
                }
            }
            if(!goON)
            {
                if(ON)
                {
                    if(pNT)
                    {
                        NT = true;
                    }
                    if(pAB)
                    {
                        AB = true;
                    }
                    if(pWUSA)
                    {
                        WUSA = true;
                    }
                    if(pEUSA)
                    {
                        EUSA = true;
                    }
                    if(pECAN)
                    {
                        ECAN = true;
                    }
                    if(pGL)
                    {
                        GL = true;
                    }
                    goON = true;
                }
            }
            if(!goECAN)
            {
                if(ECAN)
                {
                    if(pGL)
                    {
                        GL = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pEUSA)
                    {
                        EUSA = true;
                    }
                    goECAN = true;
                }
            }
            if(!goWUSA)
            {
                if(WUSA)
                {
                    if(pAB)
                    {
                        AB = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pEUSA)
                    {
                        EUSA = true;
                    }
                    if(pCNA)
                    {
                        CNA = true;
                    }
                    goWUSA = true;
                }
            }
            if(!goEUSA)
            {
                if(EUSA)
                {
                    if(pECAN)
                    {
                        ECAN = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pWUSA)
                    {
                        WUSA = true;
                    }
                    if(pCNA)
                    {
                        CNA = true;
                    }
                    goEUSA = true;
                }
            }
            if(!goCNA)
            {
                if(CNA)
                {
                    if(pWUSA)
                    {
                        WUSA = true;
                    }
                    if(pEUSA)
                    {
                        EUSA = true;
                    }
                    if(pVEN)
                    {
                        VEN = true;
                    }
                    goCNA = true;
                }
            }
            if(!goGL)
            {
                if(GL)
                {
                    if(pNT)
                    {
                        NT = true;
                    }
                    if(pON)
                    {
                        ON = true;
                    }
                    if(pECAN)
                    {
                        ECAN = true;
                    }
                    if(pISL)
                    {
                        ISL = true;
                    }
                    goGL = true;
                }
            }
            if(!goVEN)
            {
                if(VEN)
                {
                    if(pCNA)
                    {
                        CNA = true;
                    }
                    if(pPER)
                    {
                        PER = true;
                    }
                    if(pBRA)
                    {
                        BRA = true;
                    }
                    goVEN = true;
                }
            }
            if(!goPER)
            {
                if(PER)
                {
                    if(pVEN)
                    {
                        VEN = true;
                    }
                    if(pBRA)
                    {
                        BRA = true;
                    }
                    if(pARG)
                    {
                        ARG = true;
                    }
                    goPER = true;
                }
            }
            if(!goBRA)
            {
                if(BRA)
                {
                    if(pVEN)
                    {
                        VEN = true;
                    }
                    if(pPER)
                    {
                        PER = true;
                    }
                    if(pARG)
                    {
                        ARG = true;
                    }
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    goBRA = true;
                }
            }
            if(!goARG)
            {
                if(ARG)
                {
                    if(pPER)
                    {
                        PER = true;
                    }
                    if(pBRA)
                    {
                        BRA = true;
                    }
                    goARG = true;
                }
            }
            if(!goISL)
            {
                if(ISL)
                {
                    if(pGL)
                    {
                        GL = true;
                    }
                    if(pGBR)
                    {
                        GBR = true;
                    }
                    if(pSCAND)
                    {
                        SCAND = true;
                    }
                    goISL = true;
                }
            }
            if(!goGBR)
            {
                if(GBR)
                {
                    if(pISL)
                    {
                        ISL = true;
                    }
                    if(pSCAND)
                    {
                        SCAND = true;
                    }
                    if(pNEU)
                    {
                        NEU = true;
                    }
                    if(pWEU)
                    {
                        WEU = true;
                    }
                    goGBR = true;
                }
            }
            if(!goWEU)
            {
                if(WEU)
                {
                    if(pGBR)
                    {
                        GBR = true;
                    }
                    if(pNEU)
                    {
                        NEU = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    goWEU = true;
                }
            }
            if(!goNEU)
            {
                if(NEU)
                {
                    if(pGBR)
                    {
                        GBR = true;
                    }
                    if(pWEU)
                    {
                        WEU = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    if(pSCAND)
                    {
                        SCAND = true;
                    }
                    goNEU = true;
                }
            }
            if(!goSEU)
            {
                if(SEU)
                {
                    if(pWEU)
                    {
                        WEU = true;
                    }
                    if(pNEU)
                    {
                        NEU = true;
                    }
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    if(pME)
                    {
                        ME = true;
                    }
                    if(pEGY)
                    {
                        EGY = true;
                    }
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    goSEU = true;
                }
            }
            if(!goSCAND)
            {
                if(SCAND)
                {
                    if(pISL)
                    {
                        ISL = true;
                    }
                    if(pGBR)
                    {
                        GBR = true;
                    }
                    if(pNEU)
                    {
                        NEU = true;
                    }
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    goSCAND = true;
                }
            }
            if(!goRUS)
            {
                if(RUS)
                {
                    if(pSCAND)
                    {
                        SCAND = true;
                    }
                    if(pNEU)
                    {
                        NEU = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    if(pME)
                    {
                        ME = true;
                    }
                    if(pAFG)
                    {
                        AFG = true;
                    }
                    if(pURAL)
                    {
                        URAL = true;
                    }
                    goRUS = true;
                }
            }
            if(!goNAF)
            {
                if(NAF)
                {
                    if(pBRA)
                    {
                        BRA = true;
                    }
                    if(pCAF)
                    {
                        CAF = true;
                    }
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pEGY)
                    {
                        EGY = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    if(pWEU)
                    {
                        WEU = true;
                    }
                    goNAF = true;
                }
            }
            if(!goEGY)
            {
                if(EGY)
                {
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pME)
                    {
                        ME = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    goEGY = true;
                }
            }
            if(!goEAF)
            {
                if(EAF)
                {
                    if(pME)
                    {
                        ME = true; 
                    }
                    if(pEGY)
                    {
                        EGY = true;
                    }
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    if(pCAF)
                    {
                        CAF = true;
                    }
                    if(pSAF)
                    {
                        SAF = true;
                    }
                    if(pMDG)
                    {
                        MDG = true;
                    }
                    goEAF = true;
                }
            }
            if(!goCAF)
            {
                if(CAF)
                {
                    if(pNAF)
                    {
                        NAF = true;
                    }
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pSAF)
                    {
                        SAF = true;
                    }
                    goCAF = true;
                }
            }
            if(!goSAF)
            {
                if(SAF)
                {
                    if(pCAF)
                    {
                        CAF = true;
                    }
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pMDG)
                    {
                        MDG = true;
                    }
                    goSAF = true;
                }
            }
            if(!goMDG)
            {
                if(MDG)
                {
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pSAF)
                    {
                        SAF = true;
                    }
                    goMDG = true;
                }
            }
            if(!goURAL)
            {
                if(URAL)
                {
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    if(pAFG)
                    {
                        AFG = true;
                    }
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pSI)
                    {
                        SI = true;
                    }
                    goURAL = true;
                }
            }
            if(!goSI)
            {
                if(SI)
                {
                    if(pURAL)
                    {
                        URAL = true;
                    }
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pMNG)
                    {
                        MNG = true;
                    }
                    if(pYAKT)
                    {
                        YAKT = true;
                    }
                    if(pIRKT)
                    {
                        IRKT = true;
                    }
                    goSI = true;
                }
            }
            if(!goYAKT)
            {
                if(YAKT)
                {
                    if(pSI)
                    {
                        SI = true;
                    }
                    if(pIRKT)
                    {
                        IRKT = true;
                    }
                    if(pPETT)
                    {
                        PETT = true;
                    }
                    goYAKT = true;
                }
            }
            if(!goPETT)
            {
                if(PETT)
                {
                    if(pYAKT)
                    {
                        YAKT = true;
                    }
                    if(pIRKT)
                    {
                        IRKT = true;
                    }
                    if(pMNG)
                    {
                        MNG = true;
                    }
                    if(pJPN)
                    {
                        JPN = true;
                    }
                    if(pAK)
                    {
                        AK = true;
                    }
                    goPETT = true;
                }
            }
            if(!goIRKT)
            {
                if(IRKT)
                {
                    if(pSI)
                    {
                        SI = true;
                    }
                    if(pMNG)
                    {
                        MNG = true;
                    }
                    if(pPETT)
                    {
                        PETT = true;
                    }
                    if(pYAKT)
                    {
                        YAKT = true;
                    }
                    goIRKT = true;
                }
            }
            if(!goAFG)
            {
                if(AFG)
                {
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    if(pME)
                    {
                        ME = true;
                    }
                    if(pIND)
                    {
                        IND = true;
                    }
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pURAL)
                    {
                        URAL = true;
                    }
                    goAFG = true;
                }
            }
            if(!goMNG)
            {
                if(MNG)
                {
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pSI)
                    {
                        SI = true;
                    }
                    if(pIRKT)
                    {
                        IRKT = true;
                    }
                    if(pPETT)
                    {
                        PETT = true;
                    }
                    if(pJPN)
                    {
                        JPN = true;
                    }
                    goMNG = true;
                }
            }
            if(!goJPN)
            {
                if(JPN)
                {
                    if(pMNG)
                    {
                        MNG = true;
                    }
                    if(pPETT)
                    {
                        PETT = true;
                    }
                    goJPN = true;
                }
            }
            if(!goCHN)
            {
                if(CHN)
                {
                    if(pMNG)
                    {
                        MNG = true;
                    }
                    if(pSI)
                    {
                        SI = true;
                    }
                    if(pURAL)
                    {
                        URAL = true;
                    }
                    if(pAFG)
                    {
                        AFG = true;
                    }
                    if(pIND)
                    {
                        IND = true;
                    }
                    if(pSEAS)
                    {
                        SEAS = true;
                    }
                    goCHN = true;
                }
            }
            if(!goME)
            {
                if(ME)
                {
                    if(pRUS)
                    {
                        RUS = true;
                    }
                    if(pSEU)
                    {
                        SEU = true;
                    }
                    if(pEGY)
                    {
                        EGY = true;
                    }
                    if(pEAF)
                    {
                        EAF = true;
                    }
                    if(pIND)
                    {
                        IND = true;
                    }
                    if(pAFG)
                    {
                        AFG = true;
                    }
                    goME = true;
                }
            }
            if(!goIND)
            {
                if(IND)
                {
                    if(pME)
                    {
                        ME = true;
                    }
                    if(pAFG)
                    {
                        AFG = true;
                    }
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pSEAS)
                    {
                        SEAS = true;
                    }
                    goIND = true;
                }
            }
            if(!goSEAS)
            {
                if(SEAS)
                {
                    if(pIND)
                    {
                        IND = true;
                    }
                    if(pCHN)
                    {
                        CHN = true;
                    }
                    if(pIDN)
                    {
                        IDN = true;
                    }
                    goSEAS = true;
                }
            }
            if(!goIDN)
            {
                if(IDN)
                {
                    if(pSEAS)
                    {
                        SEAS = true;
                    }
                    if(pPNG)
                    {
                        PNG = true;
                    }
                    if(pWAUS)
                    {
                        WAUS = true;
                    }
                    goIDN = true;
                }
            }
            if(!goPNG)
            {
                if(PNG)
                {
                    if(pIDN)
                    {
                        IDN = true;
                    }
                    if(pEAUS)
                    {
                        EAUS = true;
                    }
                    goPNG = true;
                }
            }
            if(!goWAUS)
            {
                if(WAUS)
                {
                    if(pIDN)
                    {
                        IDN = true;
                    }
                    if(pEAUS)
                    {
                        EAUS = true;
                    }
                    goWAUS = true;
                }
            }
            if(!goEAUS)
            {
                if(EAUS)
                {
                    if(pWAUS)
                    {
                        WAUS = true;
                    }
                    if(pPNG)
                    {
                        PNG = true;
                    }
                    goEAUS = true;
                }
            }
        }    
        //
        if(land2.equals("AK"))
        {
            if(AK)
            {
                playerConnected = true;
            }    
        }
        else if(land2.equals("NT"))
        {
            if(NT)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("GL"))
        {
            if(GL)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("AB"))
        {
            if(AB)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("ON"))
        {
            if(ON)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("E.CAN"))
        {
            if(ECAN)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("W.USA"))
        {
            if(WUSA)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("E.USA"))
        {
            if(EUSA)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("C.NA"))
        {
            if(CNA)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("VEN"))
        {
            if(VEN)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("PER"))
        {
            if(PER)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("BRA"))
        {
            if(BRA)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("ARG"))
        {
            if(ARG)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("N.AF"))
        {
            if(NAF)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("EGY"))
        {
            if(EGY)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("C.AF"))
        {
            if(CAF)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("E.AF"))
        {
            if(EAF)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("S.AF"))
        {
            if(SAF)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("MDG"))
        {
            if(MDG)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("ISL"))
        {
            if(ISL)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("GBR"))
        {
            if(GBR)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("SCAND"))
        {
            if(SCAND)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("W.EU"))
        {
            if(WEU)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("N.EU"))
        {
            if(NEU)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("RUS"))
        {
            if(RUS)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("S.EU"))
        {
            if(SEU)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("URAL"))
        {
            if(URAL)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("SI"))
        {
            if(SI)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("YAKT"))
        {
            if(YAKT)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("PETT"))
        {
            if(PETT)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("AFG"))
        {
            if(AFG)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("IRKT"))
        {
            if(IRKT)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("MNG"))
        {
            if(MNG)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("JPN"))
        {
            if(JPN)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("ME"))
        {
            if(ME)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("IND"))
        {
            if(IND)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("CHN"))
        {
            if(CHN)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("SE.AS"))
        {
            if(SEAS)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("IDN"))
        {
            if(IDN)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("PNG"))
        {
            if(PNG)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("W.AUS"))
        {
            if(WAUS)
            {
                playerConnected = true;
            }
        }
        else if(land2.equals("E.AUS"))
        {
            if(EAUS)
            {
                playerConnected = true;
            }
        }
        return playerConnected;
    }    
    public static boolean attackTurnsAvailability(ArrayList<String> arr1, ArrayList<String> arr2, int[] army)
    {
        boolean possibleAttacking = false;
        for(int i = 0; i < arr1.size(); i++)
        {
            for(int j = 0; j < arr2.size(); j++)
            {
                if(army[getIndex(arr1.get(i))] > 1)
                {
                    if(getAttackAvailability(arr1.get(i), arr2.get(j)))
                    {
                        possibleAttacking = true;
                    }    
                }    
            }    
        }
        return possibleAttacking;
    }    
    public static int getNumAttack()
    {
        int totalTroop = 0;
        int attackTurns = 5;
        for(int j = 0; j < playerLand.size(); j++)
        {
            for(int i = 0; i < land.length; i++)
            {
                if(playerLand.get(j).equals(land[i]))
                {
                    totalTroop += playerArmy[i];
                } 
            }
        }
        for(int j = 0; j < botLand.size(); j++)
        {
            for(int i = 0; i < land.length; i++)
            {
                if(botLand.get(j).equals(land[i]))
                {
                    totalTroop += botArmy[i];
                } 
            }
        }
        while(totalTroop > 50)
        {
            attackTurns++;
            totalTroop -= 10;
        }
        return attackTurns;
    }    
    private static void coinFlip()
    {
        playerFirst = true;
        System.out.println("A coin will be flipped deciding whether you or Athena will go first.");
        while(!flip)
        {
            int rand1 = rand.nextInt(2);
            System.out.println("Please pick one of the following: head or tail.");
            input = kb.nextLine();
            if(input.equals("head") || input.equals("Head") || input.equals("HEAD")) 
            {
                if(rand1 < 1)
                {
                    System.out.println("head");
                    System.out.println("You can go first.");
                }
                else
                {
                    System.out.println("tail");
                    System.out.println("Athena will go first.");
                    playerFirst = false;
                }
                flip = true;
            }
            else if(input.equals("tail") || input.equals("Tail") || input.equals("TAIL"))
            {
                if(rand1 < 1)
                {
                    System.out.println("head");
                    System.out.println("Athena will go first.");
                    playerFirst = false;
                }
                else
                {
                    System.out.println("tail");
                    System.out.println("You can go first.");
                }
                flip = true;
            }
            else
            {
                System.out.println("Sorry, please try again.");
            }
        }
        flip = false;
        if(!firstFlip)
        {
            firstFlip = true;
            if(playerFirst)
            {
                playerPick();
            }
            else
            {
                botPick();
            }
        }
        else
        {
            if(playerFirst)
            {
                playerMasterBoard();
            }
            else
            {
                botMasterBoard();
            }
        }    
    }
    private static void playerPick()
    {
        while(playerPickTurn)
        {
            while(alreadyPickedLand)
            {
                getMap();
                System.out.println("Please pick one the following territories");
                for(int i = 0; i < listLand.size(); i++)
                {
                    System.out.print(listLand.get(i) + "\t");
                    if(i % 2 == 1)
                    {
                        System.out.println();
                    }    
                }    
                input = kb.nextLine();
                for(String list : listLand)
                {
                    if(input.equals(list))
                    {
                        available = true;
                    } 
                }    
                if(available)
                {
                    alreadyPickedLand = false;
                }  
            }
            for(int i = 0; i < land.length; i++)
            {
                if(input.equals(land[i]))
                {
                    playerLand.add(land[i]);
                    pick++;
                    playerPicked[i] = land[i];
                    playerChosenLand = land[i];
                    playerChoose = true;
                    listLand.remove(land[i]);
                }
            }
            playerPickTurn = false;
        }
        System.out.print("You have the following territories: ");
        for(String list : playerLand)
        {
           System.out.print(list);
           System.out.print(" | ");
        }
        System.out.println();
        if(pick < land.length)
        {
            botPickTurn = true;
            randomRight = false;
            available = false;
            botPick();
        }
        else
        {
            getMap();
            divider();
            armyPlacement();
        }    
    }
    private static void divider()
    {
        System.out.println();
        System.out.println("======================================================================================================================================================");
        System.out.println();
        System.out.println("Moving on to the next part");
        System.out.println("One troop will be automatically added to each territory");
        System.out.println();
        System.out.println("======================================================================================================================================================");
        System.out.println();    
    }    
    private static void botPick()
    {
        while(botPickTurn)
        {
            while(!randomRight)
            {
                int randBotLand = rand.nextInt(land.length + additionalBotLand);
                //Control additionalBotLand to have additional chance of selecting a territory. 
                int rand1 = rand.nextInt(sameContinent);
                if(!alreadyBotPick)
                {
                    alreadyBotPick = true;
                    if(randBotLand < land.length)
                    {
                        botChosenLand = land[randBotLand];
                    } 
                    else
                    {
                        if(randBotLand < land.length + 6)
                        {
                            botChosenLand = land[0];
                            //Ak
                        }
                        else if(randBotLand < land.length + 12)
                        {
                            botChosenLand = land[7];
                            //C.NA
                        }  
                        else if(randBotLand < land.length + 18)
                        {
                            botChosenLand = land[8];
                            //GL
                        }
                        else
                        {
                            if(playerChoose)
                            {
                                for(String list : North_America)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botNorth_America = true;
                                    }     
                                }
                                for(String list : South_America)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botSouth_America = true;
                                    }     
                                }
                                for(String list : Europe)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botEurope = true;
                                    }     
                                }
                                for(String list : Africa)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botAfrica = true;
                                    }     
                                }
                                for(String list : Asia)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botAsia = true;
                                    }     
                                }
                                for(String list : Australia)
                                {
                                    if(playerChosenLand.equals(list))
                                    {
                                        botAustralia = true;
                                    }     
                                }
                                if(botNorth_America)
                                {
                                    int rand2 = rand.nextInt(North_America.length);
                                    botChosenLand = North_America[rand2];
                                }
                                else if(botSouth_America)
                                {
                                    int rand2 = rand.nextInt(South_America.length);
                                    botChosenLand = South_America[rand2];
                                }
                                else if(botEurope)
                                {
                                    int rand2 = rand.nextInt(Europe.length);
                                    botChosenLand = Europe[rand2];
                                }
                                else if(botAfrica)
                                {
                                    int rand2 = rand.nextInt(Africa.length);
                                    botChosenLand = Africa[rand2];
                                }
                                else if(botAsia)
                                {
                                int rand2 = rand.nextInt(Asia.length);
                                    botChosenLand = Asia[rand2];
                                }
                                else
                                {
                                    int rand2 = rand.nextInt(Australia.length);
                                    botChosenLand = Australia[rand2];
                                }
                                botNorth_America = false;
                                botSouth_America = false;
                                botEurope = false;
                                botAfrica = false;
                                botAsia = false;
                                botAustralia = false;
                            }
                            else
                            {
                                botChosenLand = land[7];
                            }    
                        }    
                    }
                }
                else
                {
                    if(rand1 < diffContinent)
                    {
                        if(randBotLand < land.length)
                        {
                            botChosenLand = land[randBotLand];
                        } 
                        else
                        {
                            if(randBotLand < land.length + 6)
                            {
                                botChosenLand = land[0];
                                //Ak
                            }
                            else if(randBotLand < land.length + 12)
                            {
                                botChosenLand = land[7];
                                //C.NA
                            }  
                            else if(randBotLand < land.length + 18)
                            {
                                botChosenLand = land[8];
                                //GL
                            }
                            else
                            {
                                if(playerChoose)
                                {
                                    for(String list : North_America)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botNorth_America = true;
                                        }     
                                    }
                                    for(String list : South_America)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botSouth_America = true;
                                        }     
                                    }
                                    for(String list : Europe)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botEurope = true;
                                        }     
                                    }
                                    for(String list : Africa)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botAfrica = true;
                                        }     
                                    }
                                    for(String list : Asia)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botAsia = true;
                                        }     
                                    }
                                    for(String list : Australia)
                                    {
                                        if(playerChosenLand.equals(list))
                                        {
                                            botAustralia = true;
                                        }     
                                    }
                                    if(botNorth_America)
                                    {
                                        int rand2 = rand.nextInt(North_America.length);
                                        botChosenLand = North_America[rand2];
                                    }
                                    else if(botSouth_America)
                                    {
                                        int rand2 = rand.nextInt(South_America.length);
                                        botChosenLand = South_America[rand2];
                                    }
                                    else if(botEurope)
                                    {
                                        int rand2 = rand.nextInt(Europe.length);
                                        botChosenLand = Europe[rand2];
                                    }
                                    else if(botAfrica)
                                    {
                                        int rand2 = rand.nextInt(Africa.length);
                                        botChosenLand = Africa[rand2];
                                    }
                                    else if(botAsia)
                                    {
                                        int rand2 = rand.nextInt(Asia.length);
                                        botChosenLand = Asia[rand2];
                                    }
                                    else
                                    {
                                        int rand2 = rand.nextInt(Australia.length);
                                        botChosenLand = Australia[rand2];
                                    }
                                    botNorth_America = false;
                                    botSouth_America = false;
                                    botEurope = false;
                                    botAfrica = false;
                                    botAsia = false;
                                    botAustralia = false;
                                }
                                else
                                {
                                    botChosenLand = land[7];
                                }    
                            }   
                        }
                    }
                    else
                    {
                        for(String list : North_America)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botNorth_America = true;
                            }     
                        }
                        for(String list : South_America)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botSouth_America = true;
                            }     
                        }
                        for(String list : Europe)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botEurope = true;
                            }     
                        }
                        for(String list : Africa)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botAfrica = true;
                            }     
                        }
                        for(String list : Asia)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botAsia = true;
                            }     
                        }
                        for(String list : Australia)
                        {
                            if(botChosenLand.equals(list))
                            {
                                botAustralia = true;
                            }     
                        }
                        if(botNorth_America)
                        {
                            int rand2 = rand.nextInt(North_America.length);
                            botChosenLand = North_America[rand2];
                        }
                        else if(botSouth_America)
                        {
                            int rand2 = rand.nextInt(South_America.length);
                            botChosenLand = South_America[rand2];
                        }
                        else if(botEurope)
                        {
                            int rand2 = rand.nextInt(Europe.length);
                            botChosenLand = Europe[rand2];
                        }
                        else if(botAfrica)
                        {
                            int rand2 = rand.nextInt(Africa.length);
                            botChosenLand = Africa[rand2];
                        }
                        else if(botAsia)
                        {
                            int rand2 = rand.nextInt(Asia.length);
                            botChosenLand = Asia[rand2];
                        }
                        else
                        {
                            int rand2 = rand.nextInt(Australia.length);
                            botChosenLand = Australia[rand2];
                        }
                    }    
                }
                for(String list : listLand)
                {
                    if(botChosenLand.equals(list))
                    {
                        available = true;
                    }    
                }
                if(available)
                {
                    for(int i = 0; i < land.length; i++)
                    {
                        if(land[i].equals(botChosenLand))
                        {
                            botIndexLand = i;
                        }    
                    }
                    botLand.add(land[botIndexLand]);
                    botPicked[botIndexLand] = land[botIndexLand];
                    listLand.remove(land[botIndexLand]);
                    pick++;
                    randomRight = true;
                    botPickTurn = false;
                    available = false;    
                }    
            }
        }
        botNorth_America = false;
        botSouth_America = false;
        botEurope = false;
        botAfrica = false;
        botAsia = false;
        botAustralia = false;
        System.out.print("Athena has the following territories: ");
        for(String list : botLand)
        {
           System.out.print(list);
           System.out.print(" | ");
        }
        System.out.println();
        if(pick < land.length)
        {
            playerPickTurn = true;
            alreadyPickedLand = true;
            playerPick();
        }
        else
        {
            divider();
            armyPlacement();
        }
    }
    private static void armyPlacement()
    {
        for(int i = 0; i < land.length; i++)
        {
            for(int j = 0; j < playerLand.size(); j++)
            {
                if(land[i].equals(playerLand.get(j)))
                {
                    own = true;
                    j = playerLand.size();
                }
            }
            if(own)
            {
                playerArmy[i] += 1;
                own = false;
            }    
        }
        own = false;
        for(int i = 0; i < land.length; i++)
        {
            for(int j = 0; j < botLand.size(); j++)
            {
                if(land[i].equals(botLand.get(j)))
                {
                    own = true;
                    j = botLand.size();
                }
            }
            if(own)
            {
                botArmy[i] += 1;
                own = false;
            }    
        }
        if(playerFirst)
        {
            beginAddPlayerArmy();
        }
        else
        {
            beginAddBotArmy();
        }    
    }
    private static void beginAddPlayerArmy()
    {
        if(!firstAddPlayerArmy)
        {
            playerSpareArmy += (40 - playerLand.size());
            firstAddPlayerArmy = true;
        }
        getMap();
        System.out.println("You have " + playerSpareArmy + " troops to place.");
        while(!matchTerritory)
        {    
            System.out.println("Type in the name of the territory you want to place your troops in. (ex: ON)");
            input = kb.nextLine();
            for(int i = 0; i < playerPicked.length; i++)
            {
                if(input.equals(playerPicked[i]))
                {
                    territory  = playerPicked[i];
                    match = true;
                    i = playerPicked.length;
                }    
            }
            if(match)
            {
                matchTerritory = true;
            }
            else
            {
                System.out.println("Please try again, with the correct name of a territory that you control.");
            }    
        }
        match = false;
        matchTerritory = false;
        while(!placeTroop)
        {
            System.out.println("How many troops will you place in " + territory + "?");
            input = kb.nextLine();
            for(int i = 1; i <= playerSpareArmy; i++)
            {
                String s = String.valueOf(i);
                if(input.equals(s))
                {
                    deployment = true;
                    numDeployed = i;
                    i = (playerSpareArmy + 1);
                }    
            }
            if(deployment)
            {
                placeTroop = true;
            }
            else
            {
                System.out.println("Please type in the number in integer that is between 1 and the number of troops you have in reserve. (ex: 7)");
            }    
        }
        placeTroop = false;
        deployment = false;
        playerSpareArmy -= numDeployed;
        int index = getIndexOfArray(playerPicked, territory);
        playerArmy[index] += numDeployed;
        if(playerSpareArmy == 0)
        {
            ranOutPlayerTroop = true;
        }
        if(!ranOutPlayerTroop)
        {
            if(!ranOutBotTroop)
            {
                beginAddBotArmy();
            }
            else
            {
                beginAddPlayerArmy();
            }    
        }    
        else
        {
            if(!ranOutBotTroop)
            {
                beginAddBotArmy();
            }
            else
            {
                getMap();
                coinFlip();    
            }
        }    
    }
    private static void beginAddBotArmy()
    {
        boolean numDeployedSelected = false;
        if(!firstAddBotArmy)
        {
            botSpareArmy += (40 - botLand.size());
            firstAddBotArmy = true; 
        }
        while(!botPlace)
        {
            int randX = rand.nextInt(botLand.size() + 40);
            int randY = rand.nextInt(6);
            int rand0 = rand.nextInt(securePlacement);
            int rand1 = rand.nextInt(playerLand.size());
            if(!firstAddPlayerArmy || playerPlacementDone)
            {
                if(playerPlacementDone)
                {
                    territory = "";
                }    
                while(!botTroopPlacementRand)
                {   
                    int randZ = rand.nextInt(3);
                    botDeployed = (randZ + 1);
                    if(botDeployed <= botSpareArmy)
                    {
                        botTroopPlacementRand = true;
                    }    
                }
                botTroopPlacementRand = false;
                if(randX < botLand.size())
                {
                    territory = botLand.get(randX);
                }
                else
                {
                    if(randY == 0)
                    {
                        int territoryInNA = 0;
                        int randNA = rand.nextInt(3);
                        for(int i = 0; i < North_America.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(North_America[i]))
                                {
                                    territoryInNA++;
                                }    
                            }    
                        }
                        if(territoryInNA > (North_America.length/2))
                        {
                            if(randNA == 0)
                            {
                                territory = "AK";
                            } 
                            else if(randNA == 1)
                            {
                                territory = "GL";
                            }
                            else if(randNA == 2)
                            {
                                territory = "C.NA";
                            }
                        }     
                    }
                    if(randY == 1)
                    {
                        int territoryInSA = 0;
                        int randSA = rand.nextInt(2);
                        for(int i = 0; i < South_America.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(South_America[i]))
                                {
                                    territoryInSA++;
                                }    
                            }    
                        }
                        if(territoryInSA > (South_America.length/2))
                        {
                            if(randSA == 0)
                            {
                                territory = "VEN";
                            } 
                            else if(randSA == 1)
                            {
                                territory = "BRA";
                            }
                        }     
                    }
                    if(randY == 2)
                    {
                        int territoryInEU = 0;
                        int randEU = rand.nextInt(4);
                        for(int i = 0; i < Europe.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(Europe[i]))
                                {
                                    territoryInEU++;
                                }    
                            }    
                        }
                        if(territoryInEU > (Europe.length/2))
                        {
                            if(randEU == 0)
                            {
                                territory = "ISL";
                            } 
                            else if(randEU == 1)
                            {
                                territory = "W.EU";
                            }
                            else if(randEU == 2)
                            {
                                territory = "S.EU";
                            }
                            else if(randEU == 3)
                            {
                                territory = "RUS";
                            }
                        }
                    }
                    if(randY == 3)
                    {
                        int territoryInAF = 0;
                        int randAF = rand.nextInt(7);
                        for(int i = 0; i < Africa.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(Africa[i]))
                                {
                                    territoryInAF++;
                                }    
                            }    
                        }
                        if(territoryInAF > (Africa.length/2))
                        {
                            if(randAF == 0 || randAF == 3 || randAF == 4 || randAF == 5)
                            {
                                territory = "N.AF";
                            } 
                            else if(randAF == 1 || randAF == 6 || randAF == 7)
                            {
                                territory = "EGY";
                            }
                            else if(randAF == 2)
                            {
                                territory = "E.AF";
                            }
                        }
                    }
                    if(randY == 4)
                    {
                        int territoryInAS = 0;
                        int randAS = rand.nextInt(8);
                        for(int i = 0; i < Asia.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(Asia[i]))
                                {
                                    territoryInAS++;
                                }    
                            }    
                        }
                        if(territoryInAS > (Asia.length/2))
                        {
                            if(randAS == 0 || randAS == 5)
                            {
                                territory = "PETT";
                            } 
                            else if(randAS == 1 || randAS == 6)
                            {
                                territory = "SE.AS";
                            }
                            else if(randAS == 2 || randAS == 7)
                            {
                                territory = "ME";
                            }
                            else if(randAS == 3)
                            {
                                territory = "URAL";
                            }
                            else if(randAS == 4)
                            {
                                territory = "AFG";
                            }
                        }
                    }
                    if(randY == 5)
                    {
                        int territoryInAU = 0;
                        int randAU = rand.nextInt(8);
                        for(int i = 0; i < Australia.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(Australia[i]))
                                {
                                    territoryInAU++;
                                }    
                            }    
                        }
                        if(territoryInAU > (Australia.length/2))
                        {
                            territory = "IND";
                        }
                    }
                }    
            }
            else
            {
                while(!numDeployedSelected)
                {
                    int rand2 = rand.nextInt(numDeployed);
                    int rand3 = rand.nextInt(2);
                    if(rand3 > 0)
                    {
                        botDeployed = numDeployed + rand2; 
                    }
                    else
                    {
                        botDeployed = numDeployed - rand2;
                    }
                    if(botDeployed <= botSpareArmy)
                    {
                        numDeployedSelected = true;
                    }    
                }    
                if(rand0 > freePlacement)
                {
                    if(getAttackAvailability(territory, botLand.get(rand1)))
                    {
                        territory = botLand.get(rand1);
                    }    
                }
                else
                {
                    if(randY == 0)
                    {
                        int territoryInNA = 0;
                        int randNA = 3;
                        for(int i = 0; i < North_America.length; i++)
                        {
                            for(int j = 0; j < botLand.size(); j++)
                            {
                                if(botLand.get(j).equals(North_America[i]))
                                {
                                    territoryInNA++;
                                }    
                            }    
                        }
                        if(territoryInNA > (North_America.length/2))
                        {
                            if(randNA == 0)
                            {
                                territory = "AK";
                            } 
                            else if(randNA == 1)
                            {
                                territory = "GL";
                            }
                            else if(randNA == 2)
                            {
                                territory = "C.NA";
                            }
                        }     
                    } 
                }
            }
                for(int i = 0; i < botLand.size(); i++)
                {
                    if(getAttackAvailability(territory, botLand.get(i)))
                    {
                        bordering = true;
                    }    
                }
                if(!bordering) 
                {
                    while(!botTroopPlacementRand)
                    {   
                        int randZ = rand.nextInt(3);
                        botDeployed = (randZ + 1);
                        if(botDeployed <= botSpareArmy)
                        {
                            botTroopPlacementRand = true;
                        }    
                    }
                    botTroopPlacementRand = false;
                    if(randX < botLand.size())
                    {
                        territory = botLand.get(randX);
                    }
                    else
                    {
                        if(randY == 0)
                        {
                            int territoryInNA = 0;
                            int randNA = 3;
                            for(int i = 0; i < North_America.length; i++)
                            {
                                for(int j = 0; j < botLand.size(); j++)
                                {
                                    if(botLand.get(j).equals(North_America[i]))
                                    {
                                        territoryInNA++;
                                    }    
                                }    
                            }
                            if(territoryInNA > (North_America.length/2))
                            {
                                if(randNA == 0)
                                {
                                    territory = "AK";
                                } 
                                else if(randNA == 1)
                                {
                                    territory = "GL";
                                }
                                else if(randNA == 2)
                                {
                                    territory = "C.NA";
                                }
                            }     
                        }    
                    } 
                }
            bordering = false;
            for(int i = 0; i < land.length; i++)
            {
                if(land[i].equals(territory))
                {
                    botPlaceIndex = i; 
                }    
            }
            for(int i = 0; i < botLand.size(); i++)
            {
                if(botLand.get(i).equals(territory))
                {
                    botPlace = true;
                }
            }             
        } 
        botTroopPlacementRand = false;
        botPlace = false;
        botSpareArmy -= botDeployed;
        botArmy[botPlaceIndex] += botDeployed;
        System.out.print(territory + ": ");
        System.out.println(botDeployed);
        getMap();
        System.out.println();
        if(botSpareArmy <= 0)
        {
            ranOutBotTroop = true;
        }
        if(ranOutPlayerTroop)
        {
            playerPlacementDone = true;
        }
        if(!ranOutBotTroop)
        {
            if(!ranOutPlayerTroop)
            {
                beginAddPlayerArmy();
            }
            else
            {
                beginAddBotArmy();
            }    
        }    
        else
        {
            if(!ranOutPlayerTroop)
            {
                beginAddPlayerArmy();
            }
            else
            {
                coinFlip();
            }
        }
    }   
    private static void playerAttack()
    {
        boolean PAB1 = false;
        boolean PAB2 = false;
        boolean PAB3 = false;
        boolean PAB4 = false;
        boolean PAB5 = false;
        int playerLandNum = 0;
        int botLandNum = 0;
        int playerAttackTroopNum = 0;
        int botDefendTroopNum = 0;
        while(!PAB3)
        {
            getMap();
            while(!PAB1)
            {
                organizeArrayList(playerLand);
                System.out.println("Please type in the territory you want to attack from that you control.");
                input = kb.nextLine();
                for(int i = 0; i < playerLand.size(); i++)
                {
                    if(input.equals(playerLand.get(i)))
                    {
                        PAB1 = true;
                        land1 = input;
                        for(int j = 0; j < land.length; j++)
                        {
                            if(playerLand.get(i).equals(land[j]))
                            {
                                playerLandNum = j;
                            }    
                        }
                    }    
                }
            }
            PAB1 = false;
            while(!PAB2)
            {
                organizeArrayList(botLand);
                System.out.println("Please type in the territory that you want to attack that Athena controls.");
                input = kb.nextLine();
                for(int i = 0; i < botLand.size(); i++)
                {
                    if(input.equals(botLand.get(i)))
                    {
                        PAB2 = true;
                        land2  = input;
                        for(int j = 0; j < land.length; j++)
                        {
                            if(botLand.get(i).equals(land[j]))
                            {
                                botLandNum = j;
                            }    
                        }
                    }    
                }    
            }
            PAB2 = false;
            if(getAttackAvailability(land1, land2) && playerArmy[playerLandNum] > 1)
            {
                PAB3 = true;
            }
            else
            {
                System.out.println("Sorry, you cannot attack from " + land1 + " to " + land2 + ".");
                if(playerArmy[playerLandNum] < 2)
                {
                    System.out.println("You have only " + playerArmy[playerLandNum] + " troop in " + land1 + ", which is not enough to attack from that land.");
                }    
            }    
        }
        PAB3 = false;
        if(playerArmy[playerLandNum] > 3)
        {
            playerAttackTroopNum = 3;
        }
        else if(playerArmy[playerLandNum] > 2)
        {
            playerAttackTroopNum = 2;
        }
        else if(playerArmy[playerLandNum] > 1)
        {
            playerAttackTroopNum = 1;
        }
        if(botArmy[botLandNum] > 1)
        {
            botDefendTroopNum = 2;
        }
        else
        {
            botDefendTroopNum = 1;
        }
        System.out.println("You are attacking with " + playerAttackTroopNum + " troops while Athena is defending with " + botDefendTroopNum + " troops.");
        ArrayList<Integer> attackingDices = new ArrayList<Integer>();
        ArrayList<Integer> defendingDices = new ArrayList<Integer>();
        int randA1 = rand.nextInt(6);
        int randA2 = rand.nextInt(6);
        int randA3 = rand.nextInt(6);
        int randD1 = rand.nextInt(6);
        int randD2 = rand.nextInt(6);
        int playerTroopKilled = 0;
        int botTroopKilled = 0;
        if(playerAttackTroopNum == 3)
        {
            attackingDices.add(randA1 + 1);
            attackingDices.add(randA2 + 1);
            attackingDices.add(randA3 + 1);
        }
        else if(playerAttackTroopNum == 2)
        {
            attackingDices.add(randA1 + 1);
            attackingDices.add(randA2 + 1);
        }
        else if(playerAttackTroopNum == 1)
        {
            attackingDices.add(randA1 + 1);
        }
        if(botDefendTroopNum == 2)
        {
            defendingDices.add(randD1 + 1);
            defendingDices.add(randD2 + 1);
        }
        else if(botDefendTroopNum == 1)
        {
            defendingDices.add(randD1 + 1);
        }
        attackingDices = orderArrayList(attackingDices);
        defendingDices = orderArrayList(defendingDices);
        System.out.println("You rolled the following: " + ArrayListPrint(attackingDices));
        System.out.println("Athena rolled the following: " + ArrayListPrint(defendingDices));
        //The dices are now lined up in the order of their rolls, they still need to be compared
        if(attackingDices.size() > 1)
        {
            for(int i = 0; i < defendingDices.size(); i++)
            {
                if(attackingDices.get(i) > defendingDices.get(i))
                {
                    botTroopKilled++;
                }
                else
                {
                    playerTroopKilled++;
                }    
            }    
        }
        else if(attackingDices.size() < 2)
        {
            if(attackingDices.get(0) > defendingDices.get(0))
            {
                botTroopKilled++;
            }
            else
            {
                playerTroopKilled++;
            }
        }
        System.out.println(playerTroopKilled + " troops are eliminated on your side.");
        System.out.println(botTroopKilled + " troops are eliminated on bot's side.");
        playerArmy[getIndex(land1)] -= playerTroopKilled;
        botArmy[getIndex(land2)] -= botTroopKilled;
        System.out.println("You have " + playerArmy[getIndex(land1)] + " troops on the land " + land1);
        System.out.println("Athena has " + botArmy[getIndex(land2)] + " troops on the land " + land2);
        int playerSurvivingTroop = 0;
        if(botArmy[getIndex(land2)] <= 0)
        {
            System.out.println("You have successfully conquered " + land2 + "!");
            if(!firstCard)
            {
                card++;
                System.out.println("You get a territory card for conquering a land in your turn. You have " + card + " cards.");
                firstCard = true;
            }    
            botLand.remove(land2);
            playerLand.add(land2);
            transfer(botLand, botPicked);
            transfer(playerLand, playerPicked);
            playerSurvivingTroop = playerAttackTroopNum - playerTroopKilled;
            System.out.println(playerSurvivingTroop + " of your troops that attacked from " + land1 + " will be placed in " + land2 + ".");
            playerArmy[getIndex(land1)] -= playerSurvivingTroop;
            playerArmy[getIndex(land2)] += playerSurvivingTroop;
            while(!PAB4)
            {
                System.out.println("You have " + playerArmy[getIndex(land1)] + " troop left in " + land1);
                if(playerArmy[getIndex(land1)] < 2)
                {
                    PAB4 = true;
                }
                else
                {
                    System.out.println("How many troops from " + land1 + " would you like to move to " + land2 + "? (type in whole numbers, such as 3, type 0 to move no troops)");
                    input = kb.nextLine();
                    for(int i = 0; i <= playerArmy[getIndex(land1)] - 1; i++)
                    {
                        String str = String.valueOf(i);
                        if(str.equals(input))
                        {
                            PAB5 = true;
                        }    
                    }
                    if(PAB5)
                    {
                        int moveTroops = Integer.parseInt(input);
                        if(moveTroops <= playerArmy[getIndex(land1)] - 1 && moveTroops > 0)
                        {
                            playerArmy[getIndex(land1)] -= moveTroops;
                            playerArmy[getIndex(land2)] += moveTroops;
                            PAB4 = true;
                        }
                        else if(moveTroops == 0)
                        {
                            System.out.println("No additional troops will be moved into " + land2);
                            PAB4 = true;
                        }    
                        else
                        {
                            System.out.println("Sorry, please type an integer that is between 0 and " + (playerArmy[getIndex(land1)] - 1) + ".");
                        } 
                    }
                    else
                    {
                        System.out.println("Sorry, please type an integer that is between 0 and " + (playerArmy[getIndex(land1)] - 1) + ".");
                    }    
                }
            }
            transferTroop(playerLand, playerArmy);
            transferTroop(botLand, botArmy);
            PAB4 = false;
            PAB5 = false;
        }
        numAttack--;
        getMap();
        System.out.println();
    }
    private static void botAttack()
    {
        
    }
    private static void transferTroop(ArrayList<String> str, int[] troop)
    {
        int[] troopNew = new int[land.length];
        for(int j = 0; j < str.size(); j++)
        {
            for(int i = 0; i < land.length; i++)
            {
                if(str.get(j).equals(land[i]))
                {
                    troopNew[i] = troop[i];
                }    
            }
        }
        troop = troopNew;
    }    
    private static void transfer(ArrayList<String> list, String[] arr)
    {
        String[] arrNew = new String[land.length];
        for(int i = 0; i < list.size(); i++)
        {
            for(int j = 0; j < land.length; j++)
            {
                if(list.get(i).equals(land[j]))
                {
                    arrNew[j] = land[j];
                }    
            }    
        }
        arr = arrNew;
    }
    private static void organizeArrayList(ArrayList<String> str)
    {
        ArrayList<String> strNew = new ArrayList<String>();
        for(int i = 0; i < land.length; i++)
        {
            for(int j = 0; j < str.size(); j++)
            {
                if(land[i].equals(str.get(j)))
                {
                    strNew.add(land[i]);
                }    
            }    
        }
        str.equals(strNew);
    }    
    public static int getIndex(String str)
    {
        int index = 0;
        for(int i = 0; i < land.length; i++)
        {
            if(str.equals(land[i]))
            {
                index = i;
            }    
        }
        return index;
    }    
    public static String ArrayListPrint(ArrayList<Integer> arr)
    {
        String rolls = "";
        for(int i = 0; i < arr.size() - 1; i++)
        {
            rolls += arr.get(i) + ", ";
        }
        rolls += arr.get(arr.size() - 1);
        return rolls;
    }    
    public static ArrayList<Integer> orderArrayList(ArrayList<Integer> arr)
    {
        ArrayList<Integer> orderedArr = new ArrayList<Integer>();
        int numRepeat = arr.size();
        for(int i = 0; i < numRepeat; i++)
        {
            int max = 0;
            int index = 0;
            int cur = 0;
            for(int j = 0; j < arr.size(); j++)
            {   
                cur = arr.get(j);
                if(cur > max)
                {
                    max = cur;
                    index = j;
                }    
            }
            orderedArr.add(max);
            arr.remove(index);
        }
        return orderedArr;
    }
    public static boolean getAttackAvailability(String landStart, String landEnd)
    {
        landAttackAvailability = false;
        if(landStart.equals("AK"))
        {
            if(landEnd.equals("NT") || landEnd.equals("AB") || landEnd.equals("PETT"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("NT"))
        {
            if(landEnd.equals("AK") || landEnd.equals("AB") || landEnd.equals("ON") || landEnd.equals("GL"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("AB"))
        {
            if(landEnd.equals("AK") || landEnd.equals("NT") || landEnd.equals("ON") || landEnd.equals("W.USA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("ON"))
        {
            if(landEnd.equals("NT") || landEnd.equals("AB") || landEnd.equals("W.USA") || landEnd.equals("E.USA") || landEnd.equals("E.CAN") || landEnd.equals("GL"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("E.CAN"))
        {
            if(landEnd.equals("GL") || landEnd.equals("ON") || landEnd.equals("E.USA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("W.USA"))
        {
            if(landEnd.equals("AB") || landEnd.equals("ON") || landEnd.equals("E.USA") || landEnd.equals("C.NA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("E.USA"))
        {
            if(landEnd.equals("E.CAN") || landEnd.equals("ON") || landEnd.equals("W.USA") || landEnd.equals("C.NA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("C.NA"))
        {
            if(landEnd.equals("W.USA") || landEnd.equals("E.USA") || landEnd.equals("VEN"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("GL"))
        {
            if(landEnd.equals("NT") || landEnd.equals("ON") || landEnd.equals("E.CAN") || landEnd.equals("ISL"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("VEN"))
        {
            if(landEnd.equals("C.NA") || landEnd.equals("PER") || landEnd.equals("BRA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("PER"))
        {
            if(landEnd.equals("VEN") || landEnd.equals("BRA") || landEnd.equals("ARG"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("BRA"))
        {
            if(landEnd.equals("VEN") || landEnd.equals("PER") || landEnd.equals("ARG") || landEnd.equals("N.AF"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("ARG"))
        {
            if(landEnd.equals("PER") || landEnd.equals("BRA"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("ISL"))
        {
            if(landEnd.equals("GL") || landEnd.equals("GBR") || landEnd.equals("SCAND"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("GBR"))
        {
            if(landEnd.equals("ISL") || landEnd.equals("SCAND") || landEnd.equals("N.EU") || landEnd.equals("W.EU"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("W.EU"))
        {
            if(landEnd.equals("GBR") || landEnd.equals("N.EU") || landEnd.equals("S.EU") || landEnd.equals("N.AF"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("N.EU"))
        {
            if(landEnd.equals("GBR") || landEnd.equals("W.EU") || landEnd.equals("S.EU") || landEnd.equals("RUS") || landEnd.equals("SCAND"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("S.EU"))
        {
            if(landEnd.equals("W.EU") || landEnd.equals("N.EU") || landEnd.equals("RUS") || landEnd.equals("ME") || landEnd.equals("EGY") || landEnd.equals("N.AF"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("SCAND"))
        {
            if(landEnd.equals("ISL") || landEnd.equals("GBR") || landEnd.equals("N.EU") || landEnd.equals("RUS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("RUS"))
        {
            if(landEnd.equals("SCAND") || landEnd.equals("N.EU") || landEnd.equals("S.EU") || landEnd.equals("ME") || landEnd.equals("AFG") || landEnd.equals("URAL"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("N.AF"))
        {
            if(landEnd.equals("BRA") || landEnd.equals("C.AF") || landEnd.equals("E.AF") || landEnd.equals("EGY") || landEnd.equals("S.EU") || landEnd.equals("W.EU"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("EGY"))
        {
            if(landEnd.equals("N.AF") || landEnd.equals("E.AF") || landEnd.equals("ME") || landEnd.equals("S.EU"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("E.AF"))
        {
            if(landEnd.equals("ME") || landEnd.equals("EGY") || landEnd.equals("N.AF") || landEnd.equals("C.AF") || landEnd.equals("S.AF") || landEnd.equals("MDG"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("C.AF"))
        {
            if(landEnd.equals("N.AF") || landEnd.equals("E.AF") || landEnd.equals("S.AF"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("S.AF"))
        {
            if(landEnd.equals("C.AF") || landEnd.equals("E.AF") || landEnd.equals("MDG"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("MDG"))
        {
            if(landEnd.equals("E.AF") || landEnd.equals("S.AF"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("URAL"))
        {
            if(landEnd.equals("RUS") || landEnd.equals("AFG") || landEnd.equals("CHN") || landEnd.equals("SI"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("SI"))
        {
            if(landEnd.equals("URAL") || landEnd.equals("CHN") || landEnd.equals("MNG") || landEnd.equals("IRKT") || landEnd.equals("YAKT"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("YAKT"))
        {
            if(landEnd.equals("SI") || landEnd.equals("IRKT") || landEnd.equals("PETT"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("PETT"))
        {
            if(landEnd.equals("YAKT") || landEnd.equals("IRKT") || landEnd.equals("MNG") || landEnd.equals("JPN") || landEnd.equals("AK"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("IRKT"))
        {
            if(landEnd.equals("SI") || landEnd.equals("MNG") || landEnd.equals("PETT") || landEnd.equals("YAKT"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("AFG"))
        {
            if(landEnd.equals("RUS") || landEnd.equals("ME") || landEnd.equals("IND") || landEnd.equals("CHN") || landEnd.equals("URAL"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("MNG"))
        {
            if(landEnd.equals("CHN") || landEnd.equals("SI") || landEnd.equals("IRKT") || landEnd.equals("PETT") || landEnd.equals("JPN"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("JPN"))
        {
            if(landEnd.equals("MNG") || landEnd.equals("PETT") )
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("CHN"))
        {
            if(landEnd.equals("MNG") || landEnd.equals("SI") || landEnd.equals("URAL") || landEnd.equals("AFG") || landEnd.equals("IND") || landEnd.equals("SE.AS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("ME"))
        {
            if(landEnd.equals("RUS") || landEnd.equals("S.EU") || landEnd.equals("EGY") || landEnd.equals("E.AF") || landEnd.equals("IND") || landEnd.equals("AFG"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("IND"))
        {
            if(landEnd.equals("ME") || landEnd.equals("AFG") || landEnd.equals("CHN") || landEnd.equals("SE.AS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("SE.AS"))
        {
            if(landEnd.equals("IND") || landEnd.equals("CHN") || landEnd.equals("IDN"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("IDN"))
        {
            if(landEnd.equals("SE.AS") || landEnd.equals("PNG") || landEnd.equals("W.AUS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("PNG"))
        {
            if(landEnd.equals("IDN") || landEnd.equals("E.AUS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("W.AUS"))
        {
            if(landEnd.equals("IDN") || landEnd.equals("PNG") || landEnd.equals("E.AUS"))
            {
                landAttackAvailability = true;
            }
        }
        else if(landStart.equals("E.AUS"))
        {
            if(landEnd.equals("W.AUS") || landEnd.equals("PNG"))
            {
                landAttackAvailability = true;
            }
        }
        return landAttackAvailability;
    }    
    public static int getIndexOfArray(String[] array, String pickedTerritory)
    {
        int returnIndex = 0;
        for(int i = 0; i < array.length; i++)
        {
            if(array[i] != null)
            {
                if(array[i].equals(pickedTerritory))
                {
                    returnIndex = i;
                }
            }    
        }
        return returnIndex;
    }
    private static void getMap()
    {
        String[] map = new String[land.length];
        for(int i = 0; i < land.length; i++)
        {
            map[i] = land[i];
        }    
        for(int i = 0; i < land.length; i++)
        {
            for(String list : playerLand)
            {
                if(land[i].equals(list))
                {
                    map[i] = "P:" + land[i] + ":" + playerArmy[i]; 
                }    
            }
            for(String list : botLand)
            {
                if(land[i].equals(list))
                {
                    map[i] = "A:" + land[i] + ":" + botArmy[i]; 
                }    
            }
        }
        for(int i = 0; i < land.length; i++)
        {
            if(map[i].equals(land[i]))
            {
                map[i] = "  " + land[i] + "  ";
            }    
        }
        for(int i = 0; i < land.length; i++)
        {
            for(String list : North_America)
            {
                if(land[i].equals(list))
                {
                    map[i] = "NA)" + map[i];
                }    
            }
            for(String list : South_America)
            {
                if(land[i].equals(list))
                {
                    map[i] = "SA)" + map[i];
                }    
            }
            for(String list : Europe)
            {
                if(land[i].equals(list))
                {
                    map[i] = "EU)" + map[i];
                }    
            }
            for(String list : Africa)
            {
                if(land[i].equals(list))
                {
                    map[i] = "AF)" + map[i];
                }    
            }
            for(String list : Asia)
            {
                if(land[i].equals(list))
                {
                    map[i] = "AS)" + map[i];
                }    
            }
            for(String list : Australia)
            {
                if(land[i].equals(list))
                {
                    map[i] = "AU)" + map[i];
                }    
            }
        }     
        System.out.print(map[0] + "  " + map[1] + "      " + map[8]);
        System.out.print("       " + map[13] + "  " + map[18]);
        System.out.println("        " + map[26] + "  " + map[27] + "  " + map[28] + "  " + map[29]);
        System.out.print("  " + map[2] + "  " + map[3] + "  " + map[4]);
        System.out.print("   " + map[14] + "    " + map[16] + "  " + map[19]);
        System.out.println("  " + map[31] + "  " + map[30] + "  " + map[32] + "  " + map[33]);
        System.out.print("    " + map[5] + "   " + map[6]);
        System.out.print("          " + map[15] + "  " + map[17]);
        System.out.println("   " + map[35] + "      " + map[36] + "      " + map[34]);
        System.out.print("         " + map[7]);
        System.out.println("                                                                          " + map[37]);
        System.out.print("           " + map[9]);
        System.out.println("                     " + map[20] + "  " + map[21]);
        System.out.print("        " + map[10] + "  " + map[11]);
        System.out.print("                     " + map[23] + "  " + map[22]);
        System.out.println("                     " + map[38] + "    " + map[39]);
        System.out.print("             " + map[12]);
        System.out.print("                             " + map[24] + "   " + map[25]);
        System.out.println("                       " + map[40] + "  " + map[41]);
    }    
    private static void addPlayerArmy()
    {
        playerSpareArmy += 3;
        if(playerLand.size() >= 12 && playerLand.size() < 15)
        {
            playerSpareArmy += 1;
        }
        else if(playerLand.size() >= 15 && playerLand.size() < 18)
        {
            playerSpareArmy += 2;
        }
        else if(playerLand.size() >= 18 && playerLand.size() < 21)
        {
            playerSpareArmy += 3;
        }
        else if(playerLand.size() >= 21 && playerLand.size() < 24)
        {
            playerSpareArmy += 4;
        }
        else if(playerLand.size() >= 24 && playerLand.size() < 27)
        {
            playerSpareArmy += 5;
        }
        else if(playerLand.size() >= 27 && playerLand.size() < 30)
        {
            playerSpareArmy += 6;
        }
        else if(playerLand.size() >= 30 && playerLand.size() < 33)
        {
            playerSpareArmy += 7;
        }
        else if(playerLand.size() >= 33 && playerLand.size() < 36)
        {
            playerSpareArmy += 8;
        }
        else if(playerLand.size() >= 36 && playerLand.size() < 40)
        {
            playerSpareArmy += 9;
        }
        else if(playerLand.size() >= 40 && playerLand.size() < 43)
        {
            playerSpareArmy += 10;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : North_America)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == North_America.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : South_America)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == South_America.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : Europe)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Europe.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : Africa)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Africa.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : Asia)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Asia.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : playerLand)
        {
            for(String c : Australia)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Australia.length)
        {
            playerSpareArmy += 5;
        }
        matchContinent = 0;
        if(card >= 2)
        {
            while(!tradeInCards)
            {
                System.out.println("How many cards would you like to trade in for troops (enter no to refuse, can only trade between 2 - 10 cards, type the number of cards in integer (ex: 7))");
                input = kb.nextLine();
                int j = 0;
                for(int i = 2; i < 11; i++)
                {
                    String s = String.valueOf(i);
                    if(input.equals(s))
                    {
                        if(card >= i)
                        {
                            trade = true;
                            j = i;
                            i = 11;
                        }
                        else
                        {
                            lackOfCard = true;
                        }    
                    }    
                }    
                if(trade)
                {
                    card -= j;
                    if(j == 2)
                    {
                        playerSpareArmy += 2;
                    }
                    else if(j == 3)
                    {
                        playerSpareArmy += 4;
                    }
                    else if(j == 4)
                    {
                        playerSpareArmy += 7;
                    }
                    else if(j == 5)
                    {
                        playerSpareArmy += 10;
                    }
                    else if(j == 6)
                    {
                        playerSpareArmy += 13;
                    }
                    else if(j == 7)
                    {
                        playerSpareArmy += 17;
                    }
                    else if(j == 8)
                    {
                        playerSpareArmy += 21;
                    }
                    else if(j == 9)
                    {
                        playerSpareArmy += 25;
                    }
                    else if(j == 10)
                    {
                        playerSpareArmy += 30;
                    }
                    System.out.println("You have " + card + "cards.");
                    tradeInCards = true;
                }
                else
                {
                    if(input.equals("no"))
                    {
                        tradeInCards = true;
                    }
                    else if(lackOfCard)
                    {
                        System.out.println("You have " + card + "cards.");
                        System.out.println("You don't have enough cards to trade.");
                        lackOfCard = false;
                    }    
                    else
                    {
                        System.out.println("Sorry. Please try again with proper typing.");
                    }    
                }    
            }
        }
        trade = false;
        tradeInCards = false;
        lackOfCard = false;
        getMap();
        ranOutPlayerTroop = false;
        matchTerritory = false;
        match = false;
        int index = 0;
        while(!ranOutPlayerTroop)
        {
            System.out.println("You have " + playerSpareArmy + " troops to place.");
            //each time the loop loops, the player gets to add x number of troops to a chosen territory.
            while(!matchTerritory)
            {    
                System.out.println("Type in the name of the territory you want to place your troops in. (ex: ON)");
                input = kb.nextLine();
                for(int i = 0; i < playerLand.size(); i++)
                {
                    if(input.equals(playerLand.get(i)))
                    {
                        territory  = playerLand.get(i);
                        for(int j = 0; j < playerPicked.length; j++)
                        {
                            if(territory.equals(playerPicked[j]))
                            {
                                index = j;
                            }    
                        }    
                        match = true;
                        i = playerLand.size();
                    }    
                }
                if(match)
                {
                    matchTerritory = true;
                }
                else
                {
                    System.out.println("Please try again, with the correct name of a territory that you control.");
                }    
            }
            match = false;
            matchTerritory = false;
            while(!placeTroop)
            {
                System.out.println("How many troops will you place in " + territory + "?");
                input = kb.nextLine();
                for(int i = 1; i <= playerSpareArmy; i++)
                {
                    String s = String.valueOf(i);
                    if(input.equals(s))
                    {
                        deployment = true;
                        numDeployed = i;
                        i = (playerSpareArmy + 1);
                    }    
                }
                if(deployment)
                {
                    placeTroop = true;
                }
                else
                {
                    System.out.println("Please type in the number in integer that is between 1 and the number of troops you have in reserve. (ex: 7)");
                }    
            }
            placeTroop = false;
            deployment = false;
            playerSpareArmy -= numDeployed;
            playerArmy[index] += numDeployed;
            getMap();
            if(playerSpareArmy == 0)
            {
                ranOutPlayerTroop = true;
            }
        }
        ranOutPlayerTroop = false;
        System.out.println();
    }    
    public static void getArmyComp()
    {
        armyComp += "Player's army composition:\n";
        for(int i = 0; i < land.length; i++)
        {
            for(int j = 0; j < playerLand.size(); j++)
            {
                if(land[i].equals(playerLand.get(j)))
                {
                        armyComp += land[i] + ": " + playerArmy[i] + "\n";
                }    
            }    
        }
        armyComp += "Athena's army composition:\n";
        for(int i = 0; i < land.length; i++)
        {
            for(int j = 0; j < botLand.size(); j++)
            {
                if(land[i].equals(botLand.get(j)))
                {
                        armyComp += land[i] + ": " + botArmy[i] + "\n";
                }    
            }    
        }
        System.out.println(armyComp);
        armyComp = "";
    }
    private static void botSpareArmySize()
    {
        botSpareArmy += 3;
        if(botLand.size() >= 12 && botLand.size() < 15)
        {
            botSpareArmy += 1;
        }
        else if(botLand.size() >= 15 && botLand.size() < 18)
        {
            botSpareArmy += 2;
        }
        else if(botLand.size() >= 18 && botLand.size() < 21)
        {
            botSpareArmy += 3;
        }
        else if(botLand.size() >= 21 && botLand.size() < 24)
        {
            botSpareArmy += 4;
        }
        else if(botLand.size() >= 24 && botLand.size() < 27)
        {
            botSpareArmy += 5;
        }
        else if(botLand.size() >= 27 && botLand.size() < 30)
        {
            botSpareArmy += 6;
        }
        else if(botLand.size() >= 30 && botLand.size() < 33)
        {
            botSpareArmy += 7;
        }
        else if(botLand.size() >= 33 && botLand.size() < 36)
        {
            botSpareArmy += 8;
        }
        else if(botLand.size() >= 36 && botLand.size() < 40)
        {
            botSpareArmy += 9;
        }
        else if(botLand.size() >= 40 && botLand.size() < 43)
        {
            botSpareArmy += 10;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : North_America)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == North_America.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : South_America)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == South_America.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : Europe)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Europe.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : Africa)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Africa.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : Asia)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Asia.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        for(String list : botLand)
        {
            for(String c : Australia)
            {
                if(list.equals(c))
                {
                    matchContinent++;
                }    
            }    
        }
        if(matchContinent == Australia.length)
        {
            botSpareArmy += 5;
        }
        matchContinent = 0;
        if(botCard > 1)
        {
            boolean turnIn = turnAbility();
            if(turnIn)
            {
                if(botCard == 2)
                {
                    botSpareArmy += 2;
                }
                else if(botCard == 3)
                {
                    botSpareArmy += 4;
                }
                else if(botCard == 4)
                {
                    botSpareArmy += 7;
                }
                else if(botCard == 5)
                {
                    botSpareArmy += 10;
                }
                else if(botCard == 6)
                {
                    botSpareArmy += 13;
                }
                else if(botCard == 7)
                {
                    botSpareArmy += 17;
                }
                else if(botCard == 8)
                {
                    botSpareArmy += 21;
                }
                else if(botCard == 9)
                {
                    botSpareArmy += 25;
                }
                else if(botCard == 10)
                {
                    botSpareArmy += 30;
                }
                botCard = 0;
            }
        }    
    }
    private static void botAddArmy()
    {
        getLandBoolean();
        botSpareArmySize();
        landAttackAvailability2 = false;
        while(botSpareArmy > 0)
        {
            calcPlacementHelperInfo();
            String continentalSelectionDef = continentThatNeedsDefenseString(); //finished
            if(defensivePlacing(continentalSelectionDef))
            {
                int numPlacementDef = numPlacementForDefense(continentalSelectionDef);
                botSpareArmy -= numPlacementDef;
                ArrayList<String> defendingLand = new ArrayList<String>();
                ArrayList<Integer> defendingLandImpDef = new ArrayList<Integer>();
                getDefendingLandAndImpDef(defendingLand, defendingLandImpDef, continentalSelectionDef);
                orderArrayListOfDefendingLand(defendingLand, defendingLandImpDef);
                int n = 0;
                while(numPlacementDef > 0)
                {
                    int numPlacementDefInTerr = getNumPlacementDefInTerr(n, defendingLandImpDef, numPlacementDef);
                    numPlacementDef -= numPlacementDefInTerr;
                    placeTroopAroundPerimeter(n, defendingLand, numPlacementDefInTerr);
                    n++;
                }
            }
            else
            {
                String continentalSelectionOff = continentThatIsMostDesirable();
                int numPlacementOff = numPlacementForOffense(continentalSelectionOff);
                botSpareArmy -= numPlacementOff;
                landAttackAvailability2 = true;
                //other methods to help in this section
                //placeTroopAtNeededTerr(numPlacementOff);    
            }    
        }
        getMap();
        getBotPlacementDivider();
    }
    public static String continentThatIsMostDesirable()
    {
        if(!botTerrInNA && !bPETT && !bISL && !bVEN)
        {
            desirability[0] = 1000;
        }
        if(!botTerrInSA && !bCNA && !bNAF)
        {
            desirability[1] = 1000;
        }
        if(!botTerrInEU && !bGL && !bNAF && !bEGY && !bME && !bAFG && !bURAL)
        {
            desirability[2] = 1000;
        }
        if(!botTerrInAF && !bBRA && !bWEU && !bSEU && !bME)
        {
            desirability[3] = 1000;
        }
        if(!botTerrInAS && !bRUS && !bSEU && !bEGY && !bEAF && !bIDN && !bAK)
        {
            desirability[4] = 1000;
        }
        if(!botTerrInAU && !bSEAS)
        {
            desirability[5] = 1000;
        }
        double[] desirabilityCopy = new double[6];
        for(int i = 0; i < desirability.length; i++)
        {
            desirabilityCopy[i] = desirability[i];
        }
        for(int curIndex = 0; curIndex < desirabilityCopy.length; curIndex++)
        {
            int minIndex = findMin(desirabilityCopy, curIndex);
            swap(desirabilityCopy, curIndex, minIndex);
        }
        if(desirability[0] == desirabilityCopy[0])
        {
            return "NA";
        }
        else if(desirability[1] == desirabilityCopy[0])
        {
            return "SA";
        }
        else if(desirability[2] == desirabilityCopy[0])
        {
            return "EU";
        }
        else if(desirability[3] == desirabilityCopy[0])
        {
            return "AF";
        }
        else if(desirability[4] == desirabilityCopy[0])
        {
            return "AS";
        }
        else
        {
            return "AU";
        }
    }    
    public static String continentThatNeedsDefenseString()
    {
        double[] continentalNeedForDef = new double[6];
        double[] continentalNeedForDefCopy = new double[6];
        //smaller the continentalNeedForDef value, the better.
        if(!botTerrInNA)
        {
            continentalNeedForDef[0] = 1000;
        }
        else
        {
            if(botControlledContinents[0])
            {
                if(vulnerabilityNA <= 0)
                {
                    continentalNeedForDef[0] = (double)vulnerabilityNA*1.12;
                }
                else
                {
                    continentalNeedForDef[0] = (double)vulnerabilityNA*0.88;
                }
            }    
            else
            {
                continentalNeedForDef[0] = (double)vulnerabilityNA; 
            } 
        }   
        if(!botTerrInSA)
        {
            continentalNeedForDef[1] = 1000;
        }
        else
        {
            if(botControlledContinents[1])
            {
                if(vulnerabilitySA <= 0)
                {
                    continentalNeedForDef[1] = (double)vulnerabilitySA*1.13;
                }
                else
                {
                    continentalNeedForDef[1] = (double)vulnerabilitySA*0.89;
                }
            }
            else
            {
                continentalNeedForDef[1] = (double)vulnerabilitySA; 
            } 
        } 
        if(!botTerrInEU)
        {
            continentalNeedForDef[2] = 1000;
        }
        else
        {
            if(botControlledContinents[2])
            {
                if(vulnerabilityEU <= 0)
                {
                    continentalNeedForDef[2] = (double)vulnerabilityEU*1.08;
                }
                else
                {
                    continentalNeedForDef[2] = (double)vulnerabilityEU*0.92;
                }
            }
            else
            {
                continentalNeedForDef[2] = (double)vulnerabilityEU; 
            } 
        } 
        if(!botTerrInAF)
        {
            continentalNeedForDef[3] = 1000;
        } 
        else
        {
            if(botControlledContinents[3])
            {
                if(vulnerabilityAF <= 0)
                {    
                    continentalNeedForDef[3] = (double)vulnerabilityAF*1.07;
                }
                else
                {
                    continentalNeedForDef[3] = (double)vulnerabilityAF*0.93;
                }    
            }
            else
            {
                continentalNeedForDef[3] = (double)vulnerabilityAF; 
            } 
        } 
        if(!botTerrInAS)
        {
            continentalNeedForDef[4] = 1000;
        }
        else
        {
            if(botControlledContinents[4])
            {
                if(vulnerabilityAS <= 0)
                {
                    continentalNeedForDef[4] = (double)vulnerabilityAS*1.07;
                }
                else
                {
                    continentalNeedForDef[4] = (double)vulnerabilityAS*0.93;
                }    
            }
            else
            {
                continentalNeedForDef[4] = (double)vulnerabilityAS; 
            } 
        } 
        if(!botTerrInAU)
        {
            continentalNeedForDef[5] = 1000;
        }
        else
        {
            if(botControlledContinents[5])
            {
                if(vulnerabilityAU <= 0)
                {
                    continentalNeedForDef[5] = (double)vulnerabilityAU*1.29;
                }
                else
                {
                    continentalNeedForDef[5] = (double)vulnerabilityAU*0.71;
                }    
            }
            else
            {
                continentalNeedForDef[5] = (double)vulnerabilityAU; 
            } 
        }
        for(int i = 0; i < continentalNeedForDef.length; i++)
        {    
            continentalNeedForDefCopy[i] = continentalNeedForDef[i];
        }    
        for(int curIndex = 0; curIndex < continentalNeedForDefCopy.length; curIndex++)
        {
            int minIndex = findMin(continentalNeedForDefCopy, curIndex);
            swap(continentalNeedForDefCopy, curIndex, minIndex);
        }
        if(continentalNeedForDef[0] == continentalNeedForDefCopy[0])
        {
            return "NA";
        }
        else if(continentalNeedForDef[1] == continentalNeedForDefCopy[0])
        {
            return "SA";
        }
        else if(continentalNeedForDef[2] == continentalNeedForDefCopy[0])
        {
            return "EU";
        }
        else if(continentalNeedForDef[3] == continentalNeedForDefCopy[0])
        {
            return "AF";
        }
        else if(continentalNeedForDef[4] == continentalNeedForDefCopy[0])
        {
            return "AS";
        }
        else
        {
            return "AU";
        }
    }
    public static int findMin(double[] arr, int startingIndex)
    {
        int minIndex = startingIndex;
        for(int i = minIndex + 1; i < arr.length; i++)
        {
            if(arr[i] < arr[minIndex])
            {
                minIndex = i;
            }    
        }
        return minIndex;
    }
    private static void swap(double[] arr, int x, int y)
    {
        double temp = arr[x];
        arr[x] = arr[y];
        arr[y] = temp;
    }    
    private static void getBotPlacementDivider()
    {
        System.out.println();
        System.out.println("==========================================================================================================");
        System.out.println();
        System.out.println("Athena has placed its troops.");
        System.out.println();
        System.out.println("==========================================================================================================");
        System.out.println();
    }    
    private static void calcPlacementHelperInfo()
    {
        bAK = false;
        bNT = false;
        bGL = false;
        bAB = false;
        bON = false;
        bECAN = false;
        bWUSA = false;
        bEUSA = false;
        bCNA = false;
        bVEN = false;
        bPER = false;
        bBRA = false;
        bARG = false;
        bISL = false;
        bGBR = false;
        bSCAND = false;
        bWEU = false;
        bNEU = false;
        bRUS = false;
        bSEU = false;
        bNAF = false;
        bEGY = false;
        bCAF = false;
        bEAF = false;
        bSAF = false;
        bMDG = false;
        bURAL = false;
        bSI = false;
        bYAKT = false;
        bPETT = false;
        bAFG = false;
        bIRKT = false;
        bMNG = false;
        bJPN = false;
        bME = false;
        bIND = false;
        bCHN = false;
        bSEAS = false;
        bIDN = false;
        bPNG = false;
        bWAUS = false;
        bEAUS = false;
        //
        eAK = false;
        eNT = false;
        eGL = false;
        eAB = false;
        eON = false;
        eECAN = false;
        eWUSA = false;
        eEUSA = false;
        eCNA = false;
        eVEN = false;
        ePER = false;
        eBRA = false;
        eARG = false;
        eISL = false;
        eGBR = false;
        eSCAND = false;
        eWEU = false;
        eNEU = false;
        eRUS = false;
        eSEU = false;
        eNAF = false;
        eEGY = false;
        eCAF = false;
        eEAF = false;
        eSAF = false;
        eMDG = false;
        eURAL = false;
        eSI = false;
        eYAKT = false;
        ePETT = false;
        eAFG = false;
        eIRKT = false;
        eMNG = false;
        eJPN = false;
        eME = false;
        eIND = false;
        eCHN = false;
        eSEAS = false;
        eIDN = false;
        ePNG = false;
        eWAUS = false;
        eEAUS = false;
        for(int i = 0; i < land.length; i++)
        {
            landImp[i] = 0;
            for(int j = 0; j < botLand.size(); j++)
            {
                if(land[i].equals(botLand.get(j)))
                {
                    landImp[i]++; 
                }    
            }    
        }
        for(int i = 0; i < botLand.size(); i++)
        {
            for(int j = 0; j < playerLand.size(); j++)
            {
                if(getAttackAvailability(botLand.get(i), playerLand.get(j)))
                {
                    if(botLand.get(i).equals("AK"))
                    {
                        bAK = true;
                    }
                    else if(botLand.get(i).equals("NT"))
                    {
                        bNT = true;
                    }
                    else if(botLand.get(i).equals("GL"))
                    {
                        bGL = true;
                    }
                    else if(botLand.get(i).equals("AB"))
                    {
                        bAB = true;
                    }
                    else if(botLand.get(i).equals("ON"))
                    {
                        bON = true;
                    }
                    else if(botLand.get(i).equals("E.CAN"))
                    {
                        bECAN = true;
                    }
                    else if(botLand.get(i).equals("W.USA"))
                    {
                        bWUSA = true;
                    }
                    else if(botLand.get(i).equals("E.USA"))
                    {
                        bEUSA = true;
                    }
                    else if(botLand.get(i).equals("C.NA"))
                    {
                        bCNA = true;
                    }
                    else if(botLand.get(i).equals("VEN"))
                    {
                        bVEN = true;
                    }
                    else if(botLand.get(i).equals("PER"))
                    {
                        bPER = true;
                    }
                    else if(botLand.get(i).equals("BRA"))
                    {
                        bBRA = true;
                    }
                    else if(botLand.get(i).equals("ARG"))
                    {
                        bARG = true;
                    }
                    else if(botLand.get(i).equals("N.AF"))
                    {
                        bNAF = true;
                    }
                    else if(botLand.get(i).equals("EGY"))
                    {
                        bEGY = true;
                    }
                    else if(botLand.get(i).equals("C.AF"))
                    {
                        bCAF = true;
                    }
                    else if(botLand.get(i).equals("E.AF"))
                    {
                        bEAF = true;
                    }
                    else if(botLand.get(i).equals("S.AF"))
                    {
                        bSAF = true;
                    }
                    else if(botLand.get(i).equals("MDG"))
                    {
                        bMDG = true;
                    }
                    else if(botLand.get(i).equals("ISL"))
                    {
                        bISL = true;
                    }
                    else if(botLand.get(i).equals("GBR"))
                    {
                        bGBR = true;
                    }
                    else if(botLand.get(i).equals("SCAND"))
                    {
                        bSCAND = true;
                    }
                    else if(botLand.get(i).equals("W.EU"))
                    {
                        bWEU = true;
                    }
                    else if(botLand.get(i).equals("N.EU"))
                    {
                        bNEU = true;
                    }
                    else if(botLand.get(i).equals("RUS"))
                    {
                        bRUS = true;
                    }
                    else if(botLand.get(i).equals("S.EU"))
                    {
                        bSEU = true;
                    }
                    else if(botLand.get(i).equals("URAL"))
                    {
                        bURAL = true;
                    }
                    else if(botLand.get(i).equals("SI"))
                    {
                        bSI = true;
                    }
                    else if(botLand.get(i).equals("YAKT"))
                    {
                        bYAKT = true;
                    }
                    else if(botLand.get(i).equals("PETT"))
                    {
                        bPETT = true;
                    }
                    else if(botLand.get(i).equals("AFG"))
                    {
                        bAFG = true;
                    }
                    else if(botLand.get(i).equals("IRKT"))
                    {
                        bIRKT = true;
                    }
                    else if(botLand.get(i).equals("MNG"))
                    {
                        bMNG = true;
                    }
                    else if(botLand.get(i).equals("JPN"))
                    {
                        bJPN = true;
                    }
                    else if(botLand.get(i).equals("ME"))
                    {
                        bME = true;
                    }
                    else if(botLand.get(i).equals("IND"))
                    {
                        bIND = true;
                    }
                    else if(botLand.get(i).equals("CHN"))
                    {
                        bCHN = true;
                    }
                    else if(botLand.get(i).equals("SE.AS"))
                    {
                        bSEAS = true;
                    }
                    else if(botLand.get(i).equals("IDN"))
                    {
                        bIDN = true;
                    }
                    else if(botLand.get(i).equals("PNG"))
                    {
                        bPNG = true;
                    }
                    else if(botLand.get(i).equals("W.AUS"))
                    {
                        bWAUS = true;
                    }
                    else if(botLand.get(i).equals("E.AUS"))
                    {
                        bEAUS = true;
                    }
                    j = playerLand.size();
                }    
            }    
        }
        for(int i = 0; i < botControlledContinents.length; i++)
        {
            botControlledContinents[i] = false;
        }    
        if(bAK && bNT && bGL && bAB && bON && bECAN && bWUSA && bEUSA && bCNA)
        {
            botControlledContinents[0] = true;
            //NA
        }
        if(bVEN && bPER && bBRA && bARG)
        {
            botControlledContinents[1] = true;
            //SA
        }
        if(bISL && bGBR && bSCAND && bWEU && bNEU && bRUS && bSEU)
        {
            botControlledContinents[2] = true;
            //EU
        }
        if(bNAF && bEGY && bCAF && bEAF && bSAF && bMDG)
        {
            botControlledContinents[3] = true;
            //AF
        }
        if(bURAL && bSI && bYAKT && bPETT && bAFG && bIRKT && bMNG && bJPN && bME && bIND && bCHN && bSEAS)
        {
            botControlledContinents[4] = true;
            //AS
        }
        if(bIDN && bPNG && bWAUS && bEAUS)
        {
            botControlledContinents[5] = true;
            //AU
        }
        if(bAK || bNT || bGL || bAB || bON || bECAN || bWUSA || bEUSA || bCNA)
        {
            botTerrInNA = true;
        }
        if(bVEN || bPER || bBRA || bARG)
        {
            botTerrInSA = true;
        }
        if(bISL || bGBR || bSCAND || bWEU || bNEU || bRUS || bSEU)
        {
            botTerrInEU = true;
        }
        if(bNAF || bEGY || bCAF || bEAF || bSAF || bMDG)
        {
            botTerrInAF = true;
        }
        if(bURAL || bSI || bYAKT || bPETT || bAFG || bIRKT || bMNG || bJPN || bME || bIND || bCHN || bSEAS)
        {
            botTerrInAS = true;
        }
        if(bIDN || bPNG || bWAUS || bEAUS)
        {
            botTerrInAU = true;
        }
        for(int i = 0; i < playerLand.size(); i++)
        {
            if(playerLand.get(i).equals("AK"))
            {
                eAK = true;
            }
            else if(playerLand.get(i).equals("NT"))
            {
                eNT = true;
            }
            else if(playerLand.get(i).equals("GL"))
            {
                eGL = true;
            }
            else if(playerLand.get(i).equals("AB"))
            {
                eAB = true;
            }
            else if(playerLand.get(i).equals("ON"))
            {
                eON = true;
            }
            else if(playerLand.get(i).equals("E.CAN"))
            {
                eECAN = true;
            }
            else if(playerLand.get(i).equals("W.USA"))
            {
                eWUSA = true;
            }
            else if(playerLand.get(i).equals("E.USA"))
            {
                eEUSA = true;
            }
            else if(playerLand.get(i).equals("C.NA"))
            {
                eCNA = true;
            }
            else if(playerLand.get(i).equals("VEN"))
            {
                eVEN = true;
            }
            else if(playerLand.get(i).equals("PER"))
            {
                ePER = true;
            }
            else if(playerLand.get(i).equals("BRA"))
            {
                eBRA = true;
            }
            else if(playerLand.get(i).equals("ARG"))
            {
                eARG = true;
            }
            else if(playerLand.get(i).equals("N.AF"))
            {
                eNAF = true;
            }
            else if(playerLand.get(i).equals("EGY"))
            {
                eEGY = true;
            }
            else if(playerLand.get(i).equals("C.AF"))
            {
                eCAF = true;
            }
            else if(playerLand.get(i).equals("E.AF"))
            {
                eEAF = true;
            }
            else if(playerLand.get(i).equals("S.AF"))
            {
                eSAF = true;
            }
            else if(playerLand.get(i).equals("MDG"))
            {
                eMDG = true;
            }
            else if(playerLand.get(i).equals("ISL"))
            {
                eISL = true;
            }
            else if(playerLand.get(i).equals("GBR"))
            {
                eGBR = true;
            }
            else if(playerLand.get(i).equals("SCAND"))
            {
                eSCAND = true;
            }
            else if(playerLand.get(i).equals("W.EU"))
            {
                eWEU = true;
            }
            else if(playerLand.get(i).equals("N.EU"))
            {
                eNEU = true;
            }
            else if(playerLand.get(i).equals("RUS"))
            {
                eRUS = true;
            }
            else if(playerLand.get(i).equals("S.EU"))
            {
                eSEU = true;
            }
            else if(playerLand.get(i).equals("URAL"))
            {
                eURAL = true;
            }
            else if(playerLand.get(i).equals("SI"))
            {
                eSI = true;
            }
            else if(playerLand.get(i).equals("YAKT"))
            {
                eYAKT = true;
            }
            else if(playerLand.get(i).equals("PETT"))
            {
                ePETT = true;
            }
            else if(playerLand.get(i).equals("AFG"))
            {
                eAFG = true;
            }
            else if(playerLand.get(i).equals("IRKT"))
            {
                eIRKT = true;
            }
            else if(playerLand.get(i).equals("MNG"))
            {
                eMNG = true;
            }
            else if(playerLand.get(i).equals("JPN"))
            {
                eJPN = true;
            }
            else if(playerLand.get(i).equals("ME"))
            {
                eME = true;
            }
            else if(playerLand.get(i).equals("IND"))
            {
                eIND = true;
            }
            else if(playerLand.get(i).equals("CHN"))
            {
                eCHN = true;
            }
            else if(playerLand.get(i).equals("SE.AS"))
            {
                eSEAS = true;
            }
            else if(playerLand.get(i).equals("IDN"))
            {
                eIDN = true;
            }
            else if(playerLand.get(i).equals("PNG"))
            {
                ePNG = true;
            }
            else if(playerLand.get(i).equals("W.AUS"))
            {
                eWAUS = true;
            }
            else if(playerLand.get(i).equals("E.AUS"))
            {
                eEAUS = true;
            }
        }
        for(int i = 0; i < landImp.length; i++)
        {
            landImp[i] = 0;
        }
        for(int i = 0; i < landImpOff.length; i++)
        {
            landImpOff[i] = 0;
        }
        for(int i = 0; i < landImpDef.length; i++)
        {
            landImpDef[i] = 0;
        }
        if(bAK)
        {
            if(ePETT)
            {
                landImp[getIndex("AK")] += playerArmy[getIndex("PETT")];
                landImpDef[getIndex("AK")]--;
            }
            if(eNT)
            {
                landImp[getIndex("AK")] += playerArmy[getIndex("NT")];
                landImpDef[getIndex("AK")]--;
            }
            if(eAB)
            {
                landImp[getIndex("AK")] += playerArmy[getIndex("AB")];
                landImpDef[getIndex("AK")]--;
            }
        }
        if(bNT)
        {
            if(eAK)
            {
                landImp[getIndex("NT")] += playerArmy[getIndex("AK")];
                landImpDef[getIndex("NT")]--;
            }
            if(eAB)
            {
                landImp[getIndex("NT")] += playerArmy[getIndex("AB")];
                landImpDef[getIndex("NT")]--;
            }
            if(eON)
            {
                landImp[getIndex("NT")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("NT")]--;
            }
            if(eGL)
            {
                landImp[getIndex("NT")] += playerArmy[getIndex("GL")];
                landImpDef[getIndex("NT")]--;
            }
        }
        if(bAB)
        {
            if(eAK)
            {
                landImp[getIndex("AB")] += playerArmy[getIndex("AK")];
                landImpDef[getIndex("AB")]--;
            }
            if(eNT)
            {
                landImp[getIndex("AB")] += playerArmy[getIndex("NT")];
                landImpDef[getIndex("AB")]--;
            }
            if(eON)
            {
                landImp[getIndex("AB")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("AB")]--;
            }
            if(eWUSA)
            {
                landImp[getIndex("AB")] += playerArmy[getIndex("W.USA")];
                landImpDef[getIndex("AB")]--;
            }
        }
        if(bON)
        {
            if(eNT)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("NT")];
                landImpDef[getIndex("ON")]--;
            }
            if(eAB)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("AB")];
                landImpDef[getIndex("ON")]--;
            }
            if(eWUSA)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("W.USA")];
                landImpDef[getIndex("ON")]--;
            }
            if(eEUSA)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("E.USA")];
                landImpDef[getIndex("ON")]--;
            }
            if(eECAN)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("E.CAN")];
                landImpDef[getIndex("ON")]--;
            }
            if(eGL)
            {
                landImp[getIndex("ON")] += playerArmy[getIndex("GL")];
                landImpDef[getIndex("ON")]--;
            }
        }
        if(bECAN)
        {
            if(eGL)
            {
                landImp[getIndex("E.CAN")] += playerArmy[getIndex("GL")];
                landImpDef[getIndex("E.CAN")]--;
            }
            if(eON)
            {
                landImp[getIndex("E.CAN")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("E.CAN")]--;
            }
            if(eEUSA)
            {
                landImp[getIndex("E.CAN")] += playerArmy[getIndex("E.USA")];
                landImpDef[getIndex("E.CAN")]--;
            }
        }
        if(bWUSA)
        {
            if(eAB)
            {
                landImp[getIndex("W.USA")] += playerArmy[getIndex("AB")];
                landImpDef[getIndex("W.USA")]--;
            }
            if(eON)
            {
                landImp[getIndex("W.USA")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("W.USA")]--;
            }
            if(eEUSA)
            {
                landImp[getIndex("W.USA")] += playerArmy[getIndex("E.USA")];
                landImpDef[getIndex("W.USA")]--;
            }
            if(eCNA)
            {
                landImp[getIndex("W.USA")] += playerArmy[getIndex("C.NA")];
                landImpDef[getIndex("W.USA")]--;
            }
        }
        if(bEUSA)
        {
            if(eECAN)
            {
                landImp[getIndex("E.USA")] += playerArmy[getIndex("E.CAN")];
                landImpDef[getIndex("E.USA")]--;
            }
            if(eON)
            {
                landImp[getIndex("E.USA")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("E.USA")]--;
            }
            if(eWUSA)
            {
                landImp[getIndex("E.USA")] += playerArmy[getIndex("W.USA")];
                landImpDef[getIndex("E.USA")]--;
            }
            if(eCNA)
            {
                landImp[getIndex("E.USA")] += playerArmy[getIndex("C.NA")];
                landImpDef[getIndex("E.USA")]--;
            }
        }
        if(bCNA)
        {
            if(eWUSA)
            {
                landImp[getIndex("C.NA")] += playerArmy[getIndex("W.USA")];
                landImpDef[getIndex("C.NA")]--;
            }
            if(eEUSA)
            {
                landImp[getIndex("C.NA")] += playerArmy[getIndex("E.USA")];
                landImpDef[getIndex("C.NA")]--;
            }
            if(eVEN)
            {
                landImp[getIndex("C.NA")] += playerArmy[getIndex("VEN")];
                landImpDef[getIndex("C.NA")]--;
            }
        }
        if(bGL)
        {
            if(eNT)
            {
                landImp[getIndex("GL")] += playerArmy[getIndex("NT")];
                landImpDef[getIndex("GL")]--;
            }
            if(eON)
            {
                landImp[getIndex("GL")] += playerArmy[getIndex("ON")];
                landImpDef[getIndex("GL")]--;
            }
            if(eECAN)
            {
                landImp[getIndex("GL")] += playerArmy[getIndex("ECAN")];
                landImpDef[getIndex("GL")]--;
            }
            if(eISL)
            {
                landImp[getIndex("GL")] += playerArmy[getIndex("ISL")];
                landImpDef[getIndex("GL")]--;
            }
        }
        if(bVEN)
        {
            if(eCNA)
            {
                landImp[getIndex("VEN")] += playerArmy[getIndex("C.NA")];
                landImpDef[getIndex("VEN")]--;
            }
            if(ePER)
            {
                landImp[getIndex("VEN")] += playerArmy[getIndex("PER")];
                landImpDef[getIndex("VEN")]--;
            }
            if(eBRA)
            {
                landImp[getIndex("VEN")] += playerArmy[getIndex("BRA")];
                landImpDef[getIndex("VEN")]--;
            }
        }
        if(bPER)
        {
            if(eVEN)
            {
                landImp[getIndex("PER")] += playerArmy[getIndex("VEN")];
                landImpDef[getIndex("PER")]--;
            }
            if(eBRA)
            {
                landImp[getIndex("PER")] += playerArmy[getIndex("BRA")];
                landImpDef[getIndex("PER")]--;
            }
            if(eARG)
            {
                landImp[getIndex("PER")] += playerArmy[getIndex("ARG")];
                landImpDef[getIndex("PER")]--;
            }
        }
        if(bBRA)
        {
            if(eVEN)
            {
                landImp[getIndex("BRA")] += playerArmy[getIndex("VEN")];
                landImpDef[getIndex("BRA")]--;
            }
            if(ePER)
            {
                landImp[getIndex("BRA")] += playerArmy[getIndex("PER")];
                landImpDef[getIndex("BRA")]--;
            }
            if(eARG)
            {
                landImp[getIndex("BRA")] += playerArmy[getIndex("ARG")];
                landImpDef[getIndex("BRA")]--;
            }
            if(eNAF)
            {
                landImp[getIndex("BRA")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("BRA")]--;
            }
        }
        if(bARG)
        {
            if(ePER)
            {
                landImp[getIndex("ARG")] += playerArmy[getIndex("PER")];
                landImpDef[getIndex("ARG")]--;
            }
            if(eBRA)
            {
                landImp[getIndex("ARG")] += playerArmy[getIndex("BRA")];
                landImpDef[getIndex("ARG")]--;
            }
        }
        if(bISL)
        {
            if(eGL)
            {
                landImp[getIndex("ISL")] += playerArmy[getIndex("GL")];
                landImpDef[getIndex("ISL")]--;
            }
            if(eGBR)
            {
                landImp[getIndex("ISL")] += playerArmy[getIndex("GBR")];
                landImpDef[getIndex("ISL")]--;
            }
            if(eSCAND)
            {
                landImp[getIndex("ISL")] += playerArmy[getIndex("SCAND")];
                landImpDef[getIndex("ISL")]--;
            }
        }
        if(bGBR)
        {
            if(eISL)
            {
                landImp[getIndex("GBR")] += playerArmy[getIndex("ISL")];
                landImpDef[getIndex("GBR")]--;
            }
            if(eSCAND)
            {
                landImp[getIndex("GBR")] += playerArmy[getIndex("SCAND")];
                landImpDef[getIndex("GBR")]--;
            }
            if(eNEU)
            {
                landImp[getIndex("GBR")] += playerArmy[getIndex("N.EU")];
                landImpDef[getIndex("GBR")]--;
            }
            if(eWEU)
            {
                landImp[getIndex("GBR")] += playerArmy[getIndex("W.EU")];
                landImpDef[getIndex("GBR")]--;
            }
        }
        if(bWEU)
        {
            if(eGBR)
            {
                landImp[getIndex("W.EU")] += playerArmy[getIndex("GBR")];
                landImpDef[getIndex("W.EU")]--;
            }
            if(eNEU)
            {
                landImp[getIndex("W.EU")] += playerArmy[getIndex("N.EU")];
                landImpDef[getIndex("W.EU")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("W.EU")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("W.EU")]--;
            }
            if(eNAF)
            {
                landImp[getIndex("W.EU")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("W.EU")]--;
            }
        }
        if(bNEU)
        {
            if(eGBR)
            {
                landImp[getIndex("N.EU")] += playerArmy[getIndex("GBR")];
                landImpDef[getIndex("N.EU")]--;
            }
            if(eWEU)
            {
                landImp[getIndex("N.EU")] += playerArmy[getIndex("W.EU")];
                landImpDef[getIndex("N.EU")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("N.EU")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("N.EU")]--;
            }
            if(eRUS)
            {
                landImp[getIndex("N.EU")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("N.EU")]--;
            }
            if(eSCAND)
            {
                landImp[getIndex("N.EU")] += playerArmy[getIndex("SCAND")];
                landImpDef[getIndex("N.EU")]--;
            }
        }
        if(bSEU)
        {
            if(eWEU)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("W.EU")];
                landImpDef[getIndex("S.EU")]--;
            }
            if(eNEU)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("N.EU")];
                landImpDef[getIndex("S.EU")]--;
            }
            if(eRUS)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("S.EU")]--;
            }
            if(eME)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("S.EU")]--;
            }
            if(eEGY)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("EGY")];
                landImpDef[getIndex("S.EU")]--;
            }
            if(eNAF)
            {
                landImp[getIndex("S.EU")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("S.EU")]--;
            }
        }
        if(bSCAND)
        {
            if(eISL)
            {
                landImp[getIndex("SCAND")] += playerArmy[getIndex("ISL")];
                landImpDef[getIndex("SCAND")]--;
            }
            if(eGBR)
            {
                landImp[getIndex("SCAND")] += playerArmy[getIndex("GBR")];
                landImpDef[getIndex("SCAND")]--;
            }
            if(eNEU)
            {
                landImp[getIndex("SCAND")] += playerArmy[getIndex("N.EU")];
                landImpDef[getIndex("SCAND")]--;
            }
            if(eRUS)
            {
                landImp[getIndex("SCAND")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("SCAND")]--;
            }
        }
        if(bRUS)
        {
            if(eSCAND)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("SCAND")];
                landImpDef[getIndex("RUS")]--;
            }
            if(eNEU)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("N.EU")];
                landImpDef[getIndex("RUS")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("RUS")]--;
            }
            if(eME)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("RUS")]--;
            }
            if(eAFG)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("AFG")];
                landImpDef[getIndex("RUS")]--;
            }
            if(eURAL)
            {
                landImp[getIndex("RUS")] += playerArmy[getIndex("URAL")];
                landImpDef[getIndex("RUS")]--;
            }
        }
        if(bNAF)
        {
            if(eBRA)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("BRA")];
                landImpDef[getIndex("N.AF")]--;
            }
            if(eCAF)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("C.AF")];
                landImpDef[getIndex("N.AF")]--;
            }
            if(eEAF)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("N.AF")]--;
            }
            if(eEGY)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("EGY")];
                landImpDef[getIndex("N.AF")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("N.AF")]--;
            }
            if(eWEU)
            {
                landImp[getIndex("N.AF")] += playerArmy[getIndex("W.EU")];
                landImpDef[getIndex("N.AF")]--;
            }
        }
        if(bEGY)
        {
            if(eNAF)
            {
                landImp[getIndex("EGY")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("EGY")]--;
            }
            if(eEAF)
            {
                landImp[getIndex("EGY")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("EGY")]--;
            }
            if(eME)
            {
                landImp[getIndex("EGY")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("EGY")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("EGY")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("EGY")]--;
            }
        }
        if(bEAF)
        {
            if(eME)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("E.AF")]--;
            }
            if(eEGY)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("EGY")];
                landImpDef[getIndex("E.AF")]--;
            }
            if(eNAF)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("E.AF")]--;
            }
            if(eCAF)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("C.AF")];
                landImpDef[getIndex("E.AF")]--;
            }
            if(eSAF)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("S.AF")];
                landImpDef[getIndex("E.AF")]--;
            }
            if(eMDG)
            {
                landImp[getIndex("E.AF")] += playerArmy[getIndex("MDG")];
                landImpDef[getIndex("E.AF")]--;
            }
        }
        if(bCAF)
        {
            if(eNAF)
            {
                landImp[getIndex("C.AF")] += playerArmy[getIndex("N.AF")];
                landImpDef[getIndex("C.AF")]--;
            }
            if(eEAF)
            {
                landImp[getIndex("C.AF")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("C.AF")]--;
            }
            if(eSAF)
            {
                landImp[getIndex("C.AF")] += playerArmy[getIndex("S.AF")];
                landImpDef[getIndex("C.AF")]--;
            }
        }
        if(bSAF)
        {
            if(eCAF)
            {
                landImp[getIndex("S.AF")] += playerArmy[getIndex("C.AF")];
                landImpDef[getIndex("S.AF")]--;
            }
            if(eEAF)
            {
                landImp[getIndex("S.AF")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("S.AF")]--;
            }
            if(eMDG)
            {
                landImp[getIndex("S.AF")] += playerArmy[getIndex("MDG")];
                landImpDef[getIndex("S.AF")]--;
            }
        }
        if(bMDG)
        {
            if(eEAF)
            {
                landImp[getIndex("MDG")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("MDG")]--;
            }
            if(eSAF)
            {
                landImp[getIndex("MDG")] += playerArmy[getIndex("S.AF")];
                landImpDef[getIndex("MDG")]--;
            }
        }
        if(bURAL)
        {
            if(eRUS)
            {
                landImp[getIndex("URAL")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("URAL")]--;
            }
            if(eAFG)
            {
                landImp[getIndex("URAL")] += playerArmy[getIndex("AFG")];
                landImpDef[getIndex("URAL")]--;
            }
            if(eCHN)
            {
                landImp[getIndex("URAL")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("URAL")]--;
            }
            if(eSI)
            {
                landImp[getIndex("URAL")] += playerArmy[getIndex("SI")];
                landImpDef[getIndex("URAL")]--;
            }
        }
        if(bSI)
        {
            if(eURAL)
            {
                landImp[getIndex("SI")] += playerArmy[getIndex("URAL")];
                landImpDef[getIndex("SI")]--;
            }
            if(eCHN)
            {
                landImp[getIndex("SI")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("SI")]--;
            }
            if(eMNG)
            {
                landImp[getIndex("SI")] += playerArmy[getIndex("MNG")];
                landImpDef[getIndex("SI")]--;
            }
            if(eIRKT)
            {
                landImp[getIndex("SI")] += playerArmy[getIndex("IRKT")];
                landImpDef[getIndex("SI")]--;
            }
            if(eYAKT)
            {
                landImp[getIndex("SI")] += playerArmy[getIndex("YAKT")];
                landImpDef[getIndex("SI")]--;
            }
        }
        if(bYAKT)
        {
            if(eSI)
            {
                landImp[getIndex("YAKT")] += playerArmy[getIndex("SI")];
                landImpDef[getIndex("YAKT")]--;
            }
            if(eIRKT)
            {
                landImp[getIndex("YAKT")] += playerArmy[getIndex("IRKT")];
                landImpDef[getIndex("YAKT")]--;
            }
            if(ePETT)
            {
                landImp[getIndex("YAKT")] += playerArmy[getIndex("PETT")];
                landImpDef[getIndex("YAKT")]--;
            }
        }
        if(bPETT)
        {
            if(eYAKT)
            {
                landImp[getIndex("PETT")] += playerArmy[getIndex("YAKT")];
                landImpDef[getIndex("PETT")]--;
            }
            if(eIRKT)
            {
                landImp[getIndex("PETT")] += playerArmy[getIndex("IRKT")];
                landImpDef[getIndex("PETT")]--;
            }
            if(eMNG)
            {
                landImp[getIndex("PETT")] += playerArmy[getIndex("MNG")];
                landImpDef[getIndex("PETT")]--;
            }
            if(eJPN)
            {
                landImp[getIndex("PETT")] += playerArmy[getIndex("JPN")];
                landImpDef[getIndex("PETT")]--;
            }
            if(eAK)
            {
                landImp[getIndex("PETT")] += playerArmy[getIndex("AK")];
                landImpDef[getIndex("PETT")]--;
            }
        }
        if(bIRKT)
        {
            if(eSI)
            {
                landImp[getIndex("IRKT")] += playerArmy[getIndex("SI")];
                landImpDef[getIndex("IRKT")]--;
            }
            if(eMNG)
            {
                landImp[getIndex("IRKT")] += playerArmy[getIndex("MNG")];
                landImpDef[getIndex("IRKT")]--;
            }
            if(ePETT)
            {
                landImp[getIndex("IRKT")] += playerArmy[getIndex("PETT")];
                landImpDef[getIndex("IRKT")]--;
            }
            if(eYAKT)
            {
                landImp[getIndex("IRKT")] += playerArmy[getIndex("YAKT")];
                landImpDef[getIndex("IRKT")]--;
            }
        }
        if(bAFG)
        {
            if(eRUS)
            {
                landImp[getIndex("AFG")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("AFG")]--;
            }
            if(eME)
            {
                landImp[getIndex("AFG")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("AFG")]--;
            }
            if(eIND)
            {
                landImp[getIndex("AFG")] += playerArmy[getIndex("IND")];
                landImpDef[getIndex("AFG")]--;
            }
            if(eCHN)
            {
                landImp[getIndex("AFG")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("AFG")]--;
            }
            if(eURAL)
            {
                landImp[getIndex("AFG")] += playerArmy[getIndex("URAL")];
                landImpDef[getIndex("AFG")]--;
            }
        }
        if(bMNG)
        {
            if(eCHN)
            {
                landImp[getIndex("MNG")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("MNG")]--;
            }
            if(eSI)
            {
                landImp[getIndex("MNG")] += playerArmy[getIndex("SI")];
                landImpDef[getIndex("MNG")]--;
            }
            if(eIRKT)
            {
                landImp[getIndex("MNG")] += playerArmy[getIndex("IRKT")];
                landImpDef[getIndex("MNG")]--;
            }
            if(ePETT)
            {
                landImp[getIndex("MNG")] += playerArmy[getIndex("PETT")];
                landImpDef[getIndex("MNG")]--;
            }
            if(eJPN)
            {
                landImp[getIndex("MNG")] += playerArmy[getIndex("JPN")];
                landImpDef[getIndex("MNG")]--;
            }
        }
        if(bJPN)
        {
            if(eMNG)
            {
                landImp[getIndex("JPN")] += playerArmy[getIndex("MNG")];
                landImpDef[getIndex("JPN")]--;
            }
            if(ePETT)
            {
                landImp[getIndex("JPN")] += playerArmy[getIndex("PETT")];
                landImpDef[getIndex("JPN")]--;
            }
        }
        if(bCHN)
        {
            if(eMNG)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("MNG")];
                landImpDef[getIndex("CHN")]--;
            }
            if(eSI)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("SI")];
                landImpDef[getIndex("CHN")]--;
            }
            if(eURAL)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("URAL")];
                landImpDef[getIndex("CHN")]--;
            }
            if(eAFG)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("AFG")];
                landImpDef[getIndex("CHN")]--;
            }
            if(eIND)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("IND")];
                landImpDef[getIndex("CHN")]--;
            }
            if(eSEAS)
            {
                landImp[getIndex("CHN")] += playerArmy[getIndex("SE.AS")];
                landImpDef[getIndex("CHN")]--;
            }
        }
        if(bME)
        {
            if(eRUS)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("RUS")];
                landImpDef[getIndex("ME")]--;
            }
            if(eSEU)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("S.EU")];
                landImpDef[getIndex("ME")]--;
            }
            if(eEGY)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("EGY")];
                landImpDef[getIndex("ME")]--;
            }
            if(eEAF)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("E.AF")];
                landImpDef[getIndex("ME")]--;
            }
            if(eIND)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("IND")];
                landImpDef[getIndex("ME")]--;
            }
            if(eAFG)
            {
                landImp[getIndex("ME")] += playerArmy[getIndex("AFG")];
                landImpDef[getIndex("ME")]--;
            }
        }
        if(bIND)
        {
            if(eME)
            {
                landImp[getIndex("IND")] += playerArmy[getIndex("ME")];
                landImpDef[getIndex("IND")]--;
            }
            if(eAFG)
            {
                landImp[getIndex("IND")] += playerArmy[getIndex("AFG")];
                landImpDef[getIndex("IND")]--;
            }
            if(eCHN)
            {
                landImp[getIndex("IND")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("IND")]--;
            }
            if(eSEAS)
            {
                landImp[getIndex("IND")] += playerArmy[getIndex("SE.AS")];
                landImpDef[getIndex("IND")]--;
            }
        }
        if(bSEAS)
        {
            if(eIND)
            {
                landImp[getIndex("SE.AS")] += playerArmy[getIndex("IND")];
                landImpDef[getIndex("SE.AS")]--;
            }
            if(eCHN)
            {
                landImp[getIndex("SE.AS")] += playerArmy[getIndex("CHN")];
                landImpDef[getIndex("SE.AS")]--;
            }
            if(eIDN)
            {
                landImp[getIndex("SE.AS")] += playerArmy[getIndex("IDN")];
                landImpDef[getIndex("SE.AS")]--;
            }
        }
        if(bIDN)
        {
            if(eSEAS)
            {
                landImp[getIndex("IDN")] += playerArmy[getIndex("SE.AS")];
                landImpDef[getIndex("IDN")]--;
            }
            if(ePNG)
            {
                landImp[getIndex("IDN")] += playerArmy[getIndex("PNG")];
                landImpDef[getIndex("IDN")]--;
            }
            if(eWAUS)
            {
                landImp[getIndex("IDN")] += playerArmy[getIndex("W.AUS")];
                landImpDef[getIndex("IDN")]--;
            }
        }
        if(bPNG)
        {
            if(eIDN)
            {
                landImp[getIndex("PNG")] += playerArmy[getIndex("IDN")];
                landImpDef[getIndex("PNG")]--;
            }
            if(eEAUS)
            {
                landImp[getIndex("PNG")] += playerArmy[getIndex("E.AUS")];
                landImpDef[getIndex("PNG")]--;
            }
        }
        if(bWAUS)
        {
            if(eIDN)
            {
                landImp[getIndex("W.AUS")] += playerArmy[getIndex("IDN")];
                landImpDef[getIndex("W.AUS")]--;
            }
            if(eEAUS)
            {
                landImp[getIndex("W.AUS")] += playerArmy[getIndex("EAUS")];
                landImpDef[getIndex("W.AUS")]--;
            }
        }
        if(bEAUS)
        {
            if(eWAUS)
            {
                landImp[getIndex("E.AUS")] += playerArmy[getIndex("W.AUS")];
                landImpDef[getIndex("E.AUS")]--;
            }
            if(ePNG)
            {
                landImp[getIndex("E.AUS")] += playerArmy[getIndex("PNG")];
                landImpDef[getIndex("E.AUS")]--;
            }
        }
        for(int i = 0; i < landImp.length; i++)
        {
            landImpOff[i] += landImp[i];
            landImpDef[i] += landImp[i];
        }    
        surroundingTerrDefNA.clear();
        surroundingTerrOffNA.clear();
        surroundingTerrDefSA.clear();
        surroundingTerrOffSA.clear();
        surroundingTerrDefEU.clear();
        surroundingTerrOffEU.clear();
        surroundingTerrDefAF.clear();
        surroundingTerrOffAF.clear();
        surroundingTerrDefAS.clear();
        surroundingTerrOffAS.clear();
        surroundingTerrDefAU.clear();
        surroundingTerrOffAU.clear();
        vulnerabilityNA = 0;
        vulnerabilitySA = 0;
        vulnerabilityEU = 0;
        vulnerabilityAF = 0;
        vulnerabilityAS = 0;
        vulnerabilityAU = 0;
        boolean[] contactTerrNA = new boolean[land.length];
        boolean[] contactTerrSA = new boolean[land.length];
        boolean[] contactTerrEU = new boolean[land.length];
        boolean[] contactTerrAF = new boolean[land.length];
        boolean[] contactTerrAS = new boolean[land.length];
        boolean[] contactTerrAU = new boolean[land.length];
        for(int i = 0; i < land.length; i++)
        {
            contactTerrNA[i] = false;
            contactTerrSA[i] = false;
            contactTerrEU[i] = false;
            contactTerrAF[i] = false;
            contactTerrAS[i] = false;
            contactTerrAU[i] = false;
        }
        //BREAK THIS UP INTO PIECES, do not add botArmy[inATerr] to vulnerabilityCont if the continent is controlled and the land is not touching a enemy terr.
        if(landImp[getIndex("AK")] > 0)
        {
            surroundingTerrDefNA.add("AK");
            if(!bNT || !bAB)
            {
                surroundingTerrOffNA.add("AK");
            }    
            landImpOff[getIndex("AK")] += (botArmy[getIndex("AK")] - 1);
            landImpDef[getIndex("AK")] -= botArmy[getIndex("AK")];
            vulnerabilityNA += botArmy[getIndex("AK")];
            if(ePETT && !contactTerrNA[getIndex("PETT")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("PETT")] - 1);
                contactTerrNA[getIndex("PETT")] = true;
            }
            if(eNT && !contactTerrNA[getIndex("NT")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("NT")] - 1);
                contactTerrNA[getIndex("NT")] = true;
            }
            if(eAB && !contactTerrNA[getIndex("AB")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("AB")] - 1);
                contactTerrNA[getIndex("AB")] = true;
            }
            if(botControlledContinents[4])
            {
                surroundingTerrDefAS.add("AK"); 
                vulnerabilityAS += botArmy[getIndex("AK")]*(2/3);
                if(eNT && !contactTerrAS[getIndex("NT")])
                {
                    vulnerabilityAS -= (playerArmy[getIndex("NT")] - 1)*(2/3);
                    contactTerrAS[getIndex("NT")] = true;
                }
                if(eAB && !contactTerrAS[getIndex("AB")])
                {   
                    vulnerabilityAS -= (playerArmy[getIndex("AB")] - 1)*(2/3);
                    contactTerrAS[getIndex("AB")] = true;
                }
            }
            else if(bPETT)
            {
                surroundingTerrDefAS.add("AK"); //should get 1/2 value of its landImpDef for listing
                vulnerabilityAS += botArmy[getIndex("AK")]*(1/3);
                if(eNT && !contactTerrAS[getIndex("NT")])
                {
                    vulnerabilityAS -= (playerArmy[getIndex("NT")] - 1)*(1/3);
                    contactTerrAS[getIndex("NT")] = true;
                }
                if(eAB && !contactTerrAS[getIndex("AB")])
                {   
                    vulnerabilityAS -= (playerArmy[getIndex("AB")] - 1)*(1/3);
                    contactTerrAS[getIndex("AB")] = true;
                }
            }
            else
            {
                surroundingTerrOffAS.add("AK");
            }    
        }
        else if(bAK)
        {
            vulnerabilityNA += botArmy[getIndex("AK")]*(1/2);
        }
        //
        if(landImp[getIndex("C.NA")] > 0)
        {
            surroundingTerrDefNA.add("C.NA");
            if(!bWUSA || !bEUSA)
            {
                surroundingTerrOffNA.add("C.NA");
            }    
            landImpOff[getIndex("C.NA")] += (botArmy[getIndex("C.NA")] - 1);
            landImpDef[getIndex("C.NA")] -= botArmy[getIndex("C.NA")];
            vulnerabilityNA += botArmy[getIndex("C.NA")];
            if(eVEN && !contactTerrNA[getIndex("VEN")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("VEN")] - 1);
                contactTerrNA[getIndex("VEN")] = true;
            }
            if(eWUSA && !contactTerrNA[getIndex("W.USA")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("W.USA")] - 1);
                contactTerrNA[getIndex("W.USA")] = true;
            }
            if(eAB && !contactTerrNA[getIndex("E.USA")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("E.USA")] - 1);
                contactTerrNA[getIndex("E.USA")] = true;
            }
            if(botControlledContinents[1])
            {
                surroundingTerrDefSA.add("C.NA"); 
                vulnerabilitySA += botArmy[getIndex("C.NA")]*(2/3);
                if(eWUSA && !contactTerrSA[getIndex("W.USA")])
                {
                    vulnerabilitySA -= (playerArmy[getIndex("W.USA")] - 1)*(2/3);
                    contactTerrSA[getIndex("W.USA")] = true;
                }
                if(eEUSA && !contactTerrSA[getIndex("E.USA")])
                {   
                    vulnerabilitySA -= (playerArmy[getIndex("E.USA")] - 1)*(2/3);
                    contactTerrSA[getIndex("E.USA")] = true;
                }
            }
            else if(bVEN)
            {
                surroundingTerrDefSA.add("C.NA"); //should get 1/2 value of its landImpDef for listing
                vulnerabilitySA += botArmy[getIndex("C.NA")]*(1/3);
                if(eWUSA && !contactTerrSA[getIndex("W.USA")])
                {
                    vulnerabilitySA -= (playerArmy[getIndex("W.USA")] - 1)*(1/3);
                    contactTerrSA[getIndex("W.USA")] = true;
                }
                if(eEUSA && !contactTerrSA[getIndex("E.USA")])
                {   
                    vulnerabilitySA -= (playerArmy[getIndex("E.USA")] - 1)*(1/3);
                    contactTerrSA[getIndex("E.USA")] = true;
                }
            }
            else
            {
                surroundingTerrOffSA.add("C.NA");
            }    
        }
        else if(bCNA)
        {
            vulnerabilityNA += botArmy[getIndex("C.NA")]*(1/2);
        }
        if(landImp[getIndex("GL")] > 0)
        {
            surroundingTerrDefNA.add("GL");
            if(!bNT || !bON || !bECAN)
            {
                surroundingTerrOffNA.add("GL");
            }    
            landImpOff[getIndex("GL")] += (botArmy[getIndex("GL")] - 1);
            landImpDef[getIndex("GL")] -= botArmy[getIndex("GL")];
            vulnerabilityNA += botArmy[getIndex("GL")];
            if(eNT && !contactTerrNA[getIndex("NT")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("NT")] - 1);
                contactTerrNA[getIndex("NT")] = true;
            }
            if(eON && !contactTerrNA[getIndex("ON")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("ON")] - 1);
                contactTerrNA[getIndex("ON")] = true;
            }
            if(eECAN && !contactTerrNA[getIndex("E.CAN")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("E.CAN")] - 1);
                contactTerrNA[getIndex("E.CAN")] = true;
            }
            if(eISL && !contactTerrNA[getIndex("ISL")])
            {
                vulnerabilityNA -= (playerArmy[getIndex("ISL")] - 1);
                contactTerrNA[getIndex("ISL")] = true;
            }
            if(botControlledContinents[2])
            {
                surroundingTerrDefEU.add("GL");
                vulnerabilityEU += botArmy[getIndex("GL")]*(2/3);
                if(eNT && !contactTerrEU[getIndex("NT")])
                {
                    vulnerabilityEU -= (playerArmy[getIndex("NT")] - 1)*(2/3);
                    contactTerrEU[getIndex("NT")] = true;
                }
                if(eON && !contactTerrEU[getIndex("ON")])
                {   
                    vulnerabilityEU -= (playerArmy[getIndex("ON")] - 1)*(2/3);
                    contactTerrEU[getIndex("ON")] = true;
                }
                if(eECAN && !contactTerrEU[getIndex("E.CAN")])
                {   
                    vulnerabilityEU -= (playerArmy[getIndex("E.CAN")] - 1)*(2/3);
                    contactTerrEU[getIndex("E.CAN")] = true;
                }
            }
            else if(bISL)
            {
                surroundingTerrDefEU.add("GL"); //should get 1/2 value of its landImpDef for listing
                vulnerabilityEU += botArmy[getIndex("GL")]*(1/3);
                if(eNT && !contactTerrEU[getIndex("NT")])
                {
                    vulnerabilityEU -= (playerArmy[getIndex("NT")] - 1)*(1/3);
                    contactTerrEU[getIndex("NT")] = true;
                }
                if(eON && !contactTerrEU[getIndex("ON")])
                {   
                    vulnerabilityEU -= (playerArmy[getIndex("ON")] - 1)*(1/3);
                    contactTerrEU[getIndex("ON")] = true;
                }
                if(eECAN && !contactTerrEU[getIndex("E.CAN")])
                {   
                    vulnerabilityEU -= (playerArmy[getIndex("E.CAN")] - 1)*(1/3);
                    contactTerrEU[getIndex("E.CAN")] = true;
                }
            }
            else
            {
                surroundingTerrOffEU.add("GL");
            }    
        }
        else if(bGL)
        {
            vulnerabilityNA += botArmy[getIndex("GL")]*(1/2);
        }
        //
        if(landImp[getIndex("VEN")] > 0)
        {
            surroundingTerrDefSA.add("VEN");
            if(!bPER || !bBRA)
            {
                surroundingTerrOffSA.add("VEN");
            }    
            landImpOff[getIndex("VEN")] += (botArmy[getIndex("VEN")] - 1);
            landImpDef[getIndex("VEN")] -= botArmy[getIndex("VEN")];
            vulnerabilitySA += botArmy[getIndex("VEN")];
            if(ePER && !contactTerrSA[getIndex("PER")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("PER")] - 1);
                contactTerrSA[getIndex("PER")] = true;
            }
            if(eBRA && !contactTerrSA[getIndex("BRA")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("BRA")] - 1);
                contactTerrSA[getIndex("BRA")] = true;
            }
            if(eCNA && !contactTerrSA[getIndex("C.NA")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("C.NA")] - 1);
                contactTerrSA[getIndex("C.NA")] = true;
            }
            if(botControlledContinents[0])
            {
                surroundingTerrDefNA.add("VEN");
                vulnerabilityNA += botArmy[getIndex("VEN")]*(2/3);
                if(ePER && !contactTerrNA[getIndex("PER")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("PER")] - 1)*(2/3);
                    contactTerrNA[getIndex("PER")] = true;
                }
                if(eBRA && !contactTerrNA[getIndex("BRA")])
                {   
                    vulnerabilityNA -= (playerArmy[getIndex("BRA")] - 1)*(2/3);
                    contactTerrNA[getIndex("BRA")] = true;
                }
            }
            else if(bCNA)
            {
                surroundingTerrDefNA.add("VEN");
                vulnerabilityNA += botArmy[getIndex("VEN")]*(1/3);
                if(ePER && !contactTerrNA[getIndex("PER")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("PER")] - 1)*(1/3);
                    contactTerrNA[getIndex("PER")] = true;
                }
                if(eBRA && !contactTerrNA[getIndex("BRA")])
                {   
                    vulnerabilityNA -= (playerArmy[getIndex("BRA")] - 1)*(1/3);
                    contactTerrNA[getIndex("BRA")] = true;
                }
            }
            else
            {
                surroundingTerrOffNA.add("VEN");
            }    
        }
        else if(bVEN)
        {
            vulnerabilitySA += botArmy[getIndex("VEN")]*(1/2);
        }
        if(landImp[getIndex("BRA")] > 0)
        {
            surroundingTerrDefSA.add("BRA");
            if(!bVEN || !bPER || !bARG)
            {
                surroundingTerrOffSA.add("BRA");
            }    
            landImpOff[getIndex("BRA")] += (botArmy[getIndex("BRA")] - 1);
            landImpDef[getIndex("BRA")] -= botArmy[getIndex("BRA")];
            vulnerabilitySA += botArmy[getIndex("BRA")];
            if(eVEN && !contactTerrSA[getIndex("VEN")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("VEN")] - 1);
                contactTerrSA[getIndex("VEN")] = true;
            }
            if(ePER && !contactTerrSA[getIndex("PER")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("PER")] - 1);
                contactTerrSA[getIndex("PER")] = true;
            }
            if(eARG && !contactTerrSA[getIndex("ARG")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("ARG")] - 1);
                contactTerrSA[getIndex("ARG")] = true;
            }
            if(eNAF && !contactTerrSA[getIndex("N.AF")])
            {
                vulnerabilitySA -= (playerArmy[getIndex("N.AF")] - 1);
                contactTerrSA[getIndex("N.AF")] = true;
            }
            if(botControlledContinents[3])
            {
                surroundingTerrDefAF.add("BRA");
                vulnerabilityAF += botArmy[getIndex("BRA")]*(2/3);
                if(eVEN && !contactTerrAF[getIndex("VEN")])
                {
                    vulnerabilityAF -= (playerArmy[getIndex("VEN")] - 1)*(2/3);
                    contactTerrAF[getIndex("VEN")] = true;
                }
                if(ePER && !contactTerrAF[getIndex("PER")])
                {   
                    vulnerabilityAF -= (playerArmy[getIndex("PER")] - 1)*(2/3);
                    contactTerrAF[getIndex("PER")] = true;
                }
                if(eARG && !contactTerrAF[getIndex("ARG")])
                {   
                    vulnerabilityAF -= (playerArmy[getIndex("ARG")] - 1)*(2/3);
                    contactTerrAF[getIndex("ARG")] = true;
                }
            }
            else if(bNAF)
            {
                surroundingTerrDefAF.add("BRA");
                vulnerabilityAF += botArmy[getIndex("BRA")]*(1/3);
                if(eVEN && !contactTerrAF[getIndex("VEN")])
                {
                    vulnerabilityAF -= (playerArmy[getIndex("VEN")] - 1)*(1/3);
                    contactTerrAF[getIndex("VEN")] = true;
                }
                if(ePER && !contactTerrAF[getIndex("PER")])
                {   
                    vulnerabilityAF -= (playerArmy[getIndex("PER")] - 1)*(1/3);
                    contactTerrAF[getIndex("PER")] = true;
                }
                if(eARG && !contactTerrAF[getIndex("ARG")])
                {   
                    vulnerabilityAF -= (playerArmy[getIndex("ARG")] - 1)*(1/3);
                    contactTerrAF[getIndex("ARG")] = true;
                }
            }
            else
            {
                surroundingTerrOffAF.add("BRA");
            }    
        }
        else if(bBRA)
        {
            vulnerabilitySA += botArmy[getIndex("BRA")]*(1/2);
        }
        //
        if(landImp[getIndex("ISL")] > 0)
        {
            surroundingTerrDefEU.add("ISL");
            if(!bGBR || !bSCAND)
            {
                surroundingTerrOffEU.add("ISL");
            }    
            landImpOff[getIndex("ISL")] += (botArmy[getIndex("ISL")] - 1);
            landImpDef[getIndex("ISL")] -= botArmy[getIndex("ISL")];
            vulnerabilityEU += botArmy[getIndex("ISL")];
            if(eGBR && !contactTerrEU[getIndex("GBR")])
            {
                vulnerabilityEU -= (playerArmy[getIndex("GBR")] - 1);
                contactTerrEU[getIndex("GBR")] = true;
            }
            if(eSCAND && !contactTerrEU[getIndex("SCAND")])
            {
                vulnerabilityEU -= (playerArmy[getIndex("SCAND")] - 1);
                contactTerrEU[getIndex("SCAND")] = true;
            }
            if(eGL && !contactTerrEU[getIndex("GL")])
            {
                vulnerabilityEU -= (playerArmy[getIndex("GL")] - 1);
                contactTerrEU[getIndex("GL")] = true;
            }
            if(botControlledContinents[0])
            {
                surroundingTerrDefNA.add("ISL");
                vulnerabilityNA += botArmy[getIndex("ISL")]*(2/3);
                if(eGBR && !contactTerrNA[getIndex("GBR")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("GBR")] - 1)*(2/3);
                    contactTerrNA[getIndex("GBR")] = true;
                }
                if(eSCAND && !contactTerrNA[getIndex("SCAND")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("SCAND")] - 1)*(2/3);
                    contactTerrNA[getIndex("SCAND")] = true;
                }
            }
            else if(bGL)
            {
                surroundingTerrDefNA.add("ISL");
                vulnerabilityNA += botArmy[getIndex("ISL")]*(1/3);
                if(eGBR && !contactTerrNA[getIndex("GBR")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("GBR")] - 1)*(1/3);
                    contactTerrNA[getIndex("GBR")] = true;
                }
                if(eSCAND && !contactTerrNA[getIndex("SCAND")])
                {
                    vulnerabilityNA -= (playerArmy[getIndex("SCAND")] - 1)*(1/3);
                    contactTerrNA[getIndex("SCAND")] = true;
                }
            }
            else
            {
                surroundingTerrOffNA.add("ISL");
            }    
        }
        int takabilityNA = 0;
        int takabilitySA = 0;
        int takabilityEU = 0;
        int takabilityAF = 0;
        int takabilityAS = 0;
        int takabilityAU = 0;
        if(eAK)
        {
            takabilityNA += playerArmy[getIndex("AK")];
        }
        if(eNT)
        {
            takabilityNA += playerArmy[getIndex("NT")];
        }
        if(eGL)
        {
            takabilityNA += playerArmy[getIndex("GL")];
        }
        if(eAB)
        {
            takabilityNA += playerArmy[getIndex("AB")];
        }
        if(eON)
        {
            takabilityNA += playerArmy[getIndex("ON")];
        }
        if(eECAN)
        {
            takabilityNA += playerArmy[getIndex("E.CAN")];
        }
        if(eWUSA)
        {
            takabilityNA += playerArmy[getIndex("W.USA")];
        }
        if(eEUSA)
        {
            takabilityNA += playerArmy[getIndex("E.USA")];
        }
        if(eCNA)
        {
            takabilityNA += playerArmy[getIndex("C.NA")];
        }
        if(eVEN)
        {
            takabilitySA += playerArmy[getIndex("VEN")];
        }
        if(ePER)
        {
            takabilitySA += playerArmy[getIndex("PER")];
        }
        if(eBRA)
        {
            takabilitySA += playerArmy[getIndex("BRA")];
        }
        if(eARG)
        {
            takabilitySA += playerArmy[getIndex("ARG")];
        }
        if(eISL)
        {
            takabilityEU += playerArmy[getIndex("ISL")];
        }
        if(eGBR)
        {
            takabilityEU += playerArmy[getIndex("GBR")];
        }
        if(eSCAND)
        {
            takabilityEU += playerArmy[getIndex("SCAND")];
        }
        if(eWEU)
        {
            takabilityEU += playerArmy[getIndex("W.EU")];
        }
        if(eNEU)
        {
            takabilityEU += playerArmy[getIndex("N.EU")];
        }
        if(eRUS)
        {
            takabilityEU += playerArmy[getIndex("RUS")];
        }
        if(eSEU)
        {
            takabilityEU += playerArmy[getIndex("S.EU")];
        }
        if(eNAF)
        {
            takabilityAF += playerArmy[getIndex("N.AF")];
        }
        if(eEGY)
        {
            takabilityAF += playerArmy[getIndex("EGY")];
        }
        if(eCAF)
        {
            takabilityAF += playerArmy[getIndex("C.AF")];
        }
        if(eEAF)
        {
            takabilityAF += playerArmy[getIndex("E.AF")];
        }
        if(eSAF)
        {
            takabilityAF += playerArmy[getIndex("S.AF")];
        }
        if(eMDG)
        {
            takabilityAF += playerArmy[getIndex("MDG")];
        }
        if(eURAL)
        {
            takabilityAS += playerArmy[getIndex("URAL")];
        }
        if(eSI)
        {
            takabilityAS += playerArmy[getIndex("SI")];
        }
        if(eYAKT)
        {
            takabilityAS += playerArmy[getIndex("YAKT")];
        }
        if(ePETT)
        {
            takabilityAS += playerArmy[getIndex("PETT")];
        }
        if(eAFG)
        {
            takabilityAS += playerArmy[getIndex("AFG")];
        }
        if(eIRKT)
        {
            takabilityAS += playerArmy[getIndex("IRKT")];
        }
        if(eMNG)
        {
            takabilityAS += playerArmy[getIndex("MNG")];
        }
        if(eJPN)
        {
            takabilityAS += playerArmy[getIndex("JPN")];
        }
        if(eME)
        {
            takabilityAS += playerArmy[getIndex("ME")];
        }
        if(eIND)
        {
            takabilityAS += playerArmy[getIndex("IND")];
        }
        if(eCHN)
        {
            takabilityAS += playerArmy[getIndex("CHN")];
        }
        if(eSEAS)
        {
            takabilityAS += playerArmy[getIndex("SE.AS")];
        }
        if(eIDN)
        {
            takabilityAU += playerArmy[getIndex("IDN")];
        }
        if(ePNG)
        {
            takabilityAU += playerArmy[getIndex("PNG")];
        }
        if(eWAUS)
        {
            takabilityAU += playerArmy[getIndex("W.AUS")];
        }
        if(eEAUS)
        {
            takabilityAU += playerArmy[getIndex("E.AUS")];
        }
        for(int i = 0; i < desirability.length; i++)
        {
            desirability[i] = 0;
        }
        desirability[0] = (takabilityNA/5*2.26);
        desirability[1] = (takabilitySA/2*1.48);
        desirability[2] = (takabilityEU/5*2.8);
        desirability[3] = (takabilityAF/3*2.26);
        desirability[4] = (takabilityAS/7*3.25);
        desirability[5] = (takabilityAU/2*1.21);
    }    
    public static boolean turnAbility()
    {
        int playerArmySize = 0;
        int botArmySize = 0;
        for(int i = 0; i < playerLand.size(); i++)
        {
            playerArmySize += playerArmy[getIndex(playerLand.get(i))];
        }
        for(int i = 0; i < botLand.size(); i++)
        {
            botArmySize += botArmy[getIndex(botLand.get(i))];
        }
        playerArmySize -= playerLand.size();
        botArmySize -= botLand.size();
        if(botArmySize >= playerArmySize)
        {
            if(botCard >= 10)
            {
                return true;
            }
            else
            {
                return false;
            }    
        }
        else
        {
            if(botCard >= 10)
            {
                return true;
            }
            else
            {
                if(botArmySize < (getNumAttack()*3))
                {
                    return true;
                }
                else
                {
                    return false;
                }     
            }
        }
    }
    private static void getLandBoolean()
    {
        for(int i = 0; i < land.length; i++)
        {
            landBoolean[i] = false;
        }    
        for(int i = 0; i < playerLand.size(); i++)
        {
            for(int j = 0; j < land.length; j++)
            {
                if(playerLand.get(i).equals(land[j]))
                {
                    landBoolean[j] = true;
                    j = land.length;
                }    
            }    
        }     
    }
    public static boolean defensivePlacing(String continentalSelectionDef)
    {
        int totalNum = getTotalBotNum() - getTotalPlayerNum();
        if(continentalSelectionDef.equals("NA"))
        {
            if(vulnerabilityNA < 0 && vulnerabilityNA < totalNum*(1-(1/2.26)))
            {
                return true;
            }
            else
            {
                return false;
            }    
        }
        else if(continentalSelectionDef.equals("SA"))
        {
            if(vulnerabilitySA < 0 && vulnerabilitySA < totalNum*(1-(1/1.48)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else if(continentalSelectionDef.equals("EU"))
        {
            if(vulnerabilityEU < 0 && vulnerabilityEU < totalNum*(1-(1/2.8)))
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
        else if(continentalSelectionDef.equals("AF"))
        {
            if(vulnerabilityAF < 0 && vulnerabilityAF < totalNum*(1-(1/2.26)))
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
        else if(continentalSelectionDef.equals("AS"))
        {
            if(vulnerabilityAS < 0 && vulnerabilityAS < totalNum*(1-(1/3.25)))
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
        else
        {
            if(vulnerabilityAU < 0 && vulnerabilityAU < totalNum*(1-(1/1.21)))
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
    }
    public static int getTotalPlayerNum()
    {
        int num = 0;
        for(int i = 0; i < land.length; i++)
        {
            if(landBoolean[i])
            {
                num += playerArmy[i];
            }   
        }
        return num;
    }
    public static int getTotalBotNum()
    {
        int num = 0;
        for(int i = 0; i < land.length; i++)
        {
            if(!landBoolean[i])
            {
                num += botArmy[i];
            }   
        }
        return num;
    }
    public static int numPlacementForDefense(String continentalSelectionDef)
    {
        int numBotTroop = 0;
        if(continentalSelectionDef.equals("NA"))
        {
            numBotTroop = Math.abs(vulnerabilityNA);
        }
        else if(continentalSelectionDef.equals("SA"))
        {
            numBotTroop = Math.abs(vulnerabilitySA);
        }
        else if(continentalSelectionDef.equals("EU"))
        {
            numBotTroop = Math.abs(vulnerabilityEU);
        }
        else if(continentalSelectionDef.equals("AF"))
        {
            numBotTroop = Math.abs(vulnerabilityAF);
        }
        else if(continentalSelectionDef.equals("AS"))
        {
            numBotTroop = Math.abs(vulnerabilityAS);
        }
        else
        {
            numBotTroop = Math.abs(vulnerabilityAU);
        }
        if(numBotTroop > botSpareArmy)
        {
            numBotTroop = botSpareArmy;
        }
        return numBotTroop;
    }
    public static int numPlacementForOffense(String continentalSelectionOff)
    {
        ArrayList<String> landForBotAttack = new ArrayList<String>();
        int botNumAttackingTroop = 0;
        int playerNumDefendingTroop = 0;
        int botNumAttackingTroopAdditional = 0;
        if(continentalSelectionOff.equals("NA"))
        {
            for(int i = 0; i < surroundingTerrOffNA.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffNA.get(i));
            }
            for(int i = 0; i < 9; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }    
        }
        else if(continentalSelectionOff.equals("SA"))
        {
            for(int i = 0; i < surroundingTerrOffSA.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffSA.get(i));
            }
            for(int i = 9; i < 13; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }
        }
        else if(continentalSelectionOff.equals("EU"))
        {
            for(int i = 0; i < surroundingTerrOffEU.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffEU.get(i));
            }
            for(int i = 13; i < 20; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }
        }
        else if(continentalSelectionOff.equals("AF"))
        {
            for(int i = 0; i < surroundingTerrOffAF.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffAF.get(i));
            }
            for(int i = 20; i < 26; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }
        }
        else if(continentalSelectionOff.equals("AS"))
        {
            for(int i = 0; i < surroundingTerrOffAS.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffAS.get(i));
            }
            for(int i = 26; i < 38; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }
        }
        else
        {
            for(int i = 0; i < surroundingTerrOffAU.size(); i++)
            {
                landForBotAttack.add(surroundingTerrOffAU.get(i));
            }
            for(int i = 38; i < 42; i++)
            {
                if(landBoolean[i])
                {
                    playerNumDefendingTroop += playerArmy[i];
                }    
            }
        }
        for(int i = 0; i < landForBotAttack.size(); i++)
        {
            botNumAttackingTroop += (botArmy[getIndex(landForBotAttack.get(i))] - 1);
        }
        botNumAttackingTroopAdditional = playerNumDefendingTroop*2 - botNumAttackingTroop;
        if(botNumAttackingTroopAdditional > 3)
        {
            if(botNumAttackingTroopAdditional < botSpareArmy)
            {
                return botNumAttackingTroopAdditional;
            }
            else
            {
                return botSpareArmy;
            }    
        }
        else
        {
            return 3;
        }    
    }
    private static void orderArrayListOfDefendingLand(ArrayList<String> defendingLand, ArrayList<Integer> defendingLandImpDef)
    {
        String[] arrDL = new String[defendingLand.size()];
        int[] arrDLID = new int[defendingLand.size()];
        for(int i = 0; i < defendingLand.size(); i++)
        {
            arrDL[i] = defendingLand.get(i);
            arrDLID[i] = defendingLandImpDef.get(i);
        }
        for(int curIndex = 0; curIndex < arrDLID.length; curIndex++)
        {
            int maxIndex = findMax(arrDLID, curIndex);
            swap(arrDL, arrDLID, curIndex, maxIndex);
        }
        defendingLand.clear();
        defendingLandImpDef.clear();
        for(int i = 0; i < arrDL.length; i++)
        {
            defendingLand.add(arrDL[i]);
            defendingLandImpDef.add(arrDLID[i]);
        }
        for(int i = 0; i < defendingLand.size(); i++)
        {
            System.out.println(defendingLand.get(i));
            System.out.println(defendingLandImpDef.get(i));
        }    
    }
    private static int findMax(int[] arr, int startingIndex)
    {
        int maxIndex = startingIndex;
        for(int i = maxIndex; i < arr.length; i++)
        {
            if(arr[i] > arr[maxIndex])
            {
                maxIndex = i;
            }    
        }
        return maxIndex;
    }    
    private static void swap(String[] arrDL, int[] arrDLID, int x, int y)
    {
        String tempDL = arrDL[x];
        arrDL[x] = arrDL[y];
        arrDL[y] = tempDL;
        int tempDLID = arrDLID[x];
        arrDLID[x] = arrDLID[y];
        arrDLID[y] = tempDLID;
    }
    public static int getNumPlacementDefInTerr(int n, ArrayList<Integer> defendingLandImpDef, int numPlacementDef)
    {
        int num = 0;
        if(defendingLandImpDef.size() > n)
        {
            num = defendingLandImpDef.get(n);
        }
        else
        {
            num = 3;
        }
        if(num > numPlacementDef)
        {
            num = numPlacementDef;
        }
        return num;
    }
    private static void getDefendingLandAndImpDef(ArrayList<String> defendingLand, ArrayList<Integer> defendingLandImpDef, String continentalSelectionDef)
    {
        if(continentalSelectionDef.equals("NA"))
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefNA.clone();
        }
        else if(continentalSelectionDef.equals("SA"))
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefSA.clone();
        }
        else if(continentalSelectionDef.equals("EU"))
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefEU.clone();
        }
        else if(continentalSelectionDef.equals("AF"))
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefAF.clone();
        }
        else if(continentalSelectionDef.equals("AS"))
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefAS.clone();
        }
        else
        {
            defendingLand = (ArrayList<String>)surroundingTerrDefAU.clone();
        }
        for(int i = 0; i < defendingLand.size(); i++)
        {
            defendingLandImpDef.add(landImpDef[getIndex(defendingLand.get(i))]);
        }    
    }
    private static void placeTroopAroundPerimeter(int n, ArrayList<String> defendingLand, int numPlacementDefInTerr)
    {
        if(defendingLand.size() > n)
        {
            botArmy[getIndex(defendingLand.get(n))] += numPlacementDefInTerr;
        }
        else
        {
            botArmy[getIndex(botLand.get(rand.nextInt(botLand.size())))] += numPlacementDefInTerr;
        }    
    }
}
   


