public class CheckerA {
    private int x;
    private static int xPosition = 1;
    private int y;
    private static int yPosition = 8;
    private boolean isKing;
    //Presets the position of the checkers in the correct position.
    public CheckerA() {
        this.x = xPosition;
        this.y = yPosition;
        this.isKing = false;
        if(xPosition < 7) {
            xPosition += 2;
        } else {
            xPosition = (xPosition %= 2)+1;
            yPosition--;
        }
    }

    public CheckerA(int x, int y) {
        this.x = x;
        this.y = y;
        this.isKing = false;
    }

    public CheckerA(int x, int y, boolean isKing) {
        this.x = x;
        this.y = y;
        this.isKing = isKing;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean isKing() {
        return isKing;
    }

    public boolean isAtEnd() {
        if(this.y == 1) {
            return true;
        } else {
            return false;
        }
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setToKing() {
        isKing = true;
    }

    public void moveLeft() {
        this.x--;
    }

    public void moveRight() {
        this.x++;
    }

    public void moveUp() {
        this.y++;
    }

    public void moveDown() {
        this.y--;
    }

    //tester
    public String toString() {
        return "A: " + this.x + " / " + this.y + " / " + this.isKing;
    }

}
