import java.util.ArrayList;

public class Board {
    private ArrayList<CheckerA> aList;
    private ArrayList<CheckerB> bList;

    //This sets up the checkers, by initializing them into two different ArrayList (aList and bList), in order to handle them easier.
    public Board() {
        this.aList = new ArrayList<>();
        this.bList = new ArrayList<>();
        for(int i = 0; i < 12; i++) {
            this.aList.add(new CheckerA());
            this.bList.add(new CheckerB());
        }
    }

    public boolean isAListEmpty() {
        if(aList.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isBListEmpty() {
        if(bList.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public void showBoard() {
        //Adds the coordinate in numbers
        //ex:If a checker is at x:3/y:5, adds 35
        ArrayList<Integer> listXY = new ArrayList<>();
        ArrayList<Character> listAB = new ArrayList<>();
        for(int i = 0; i < aList.size(); i++) {
            listXY.add((aList.get(i).getX()*10)+aList.get(i).getY());
            if(aList.get(i).isKing()) {
                listAB.add('A');
            } else {
                listAB.add('a');
            }
        }
        for(int i = 0; i < bList.size(); i++) {
            listXY.add((bList.get(i).getX()*10)+bList.get(i).getY());
            if(bList.get(i).isKing()) {
                listAB.add('B');
            } else {
                listAB.add('b');
            }
        }
        int coordinate = 18;
        int yScale = 7;
        System.out.println("______________________________");
        System.out.println("      (Checker Board)");
        System.out.println(" Y ");
        System.out.print(" 8 ");
        while(coordinate != 10) {
            boolean checkerOnCoordinate = false;
            int listXYIndex = 0;
            for(int i = 0; i < listXY.size(); i++) {
                //checks if there is a checker on the coordinate
                if(coordinate == listXY.get(i)) {
                    checkerOnCoordinate = true;
                    listXYIndex = i;
                }
            }
            if(checkerOnCoordinate) {
                //Prints [A], [B], [a], or [b]
                System.out.print("["+listAB.get(listXYIndex)+"]");
            } else {
                //Prints [ ] on every first coordinate that has its first and second index add up to an odd number
                int tensDigitCoordinate = Character.getNumericValue(Integer.toString(coordinate).charAt(0));
                int onesDigitCoordinate = Character.getNumericValue(Integer.toString(coordinate).charAt(1));
                if((tensDigitCoordinate + onesDigitCoordinate) % 2 == 0) {
                    System.out.print("   ");
                } else {
                    System.out.print("[ ]");
                }
            }
            if(Integer.toString(coordinate).charAt(0) != '8') {
                coordinate += 10;
            } else {
                coordinate -= 71;
                System.out.println();
                if(yScale != 0) {
                    System.out.print(" " + yScale + " ");
                }
                yScale--;
            }
        }
        System.out.println("    1  2  3  4  5  6  7  8  X");
        System.out.println("______________________________");
    }

    public ArrayList<String> showMovesA() {
        //Iterates over the aList and finds out if the objects in the list can move
        ArrayList<String> possibleMovesA = new ArrayList<>();
        ArrayList<String> possibleJumpsA = new ArrayList<>();
        for(int i = 0; i < this.aList.size(); i++) {
            if(this.aList.get(i).isKing()) {
                //Checks for kings
                int xLeft = aList.get(i).getX() - 1;
                int xRight = aList.get(i).getX() + 1;
                int yUp = aList.get(i).getY() + 1;
                int yDown = aList.get(i).getY() - 1;
                if(xLeft >= 1 && yUp <= 8) {
                    boolean xLeftYUpSpaceBlank = true;
                    boolean xLeftYUpJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == yUp) {
                            xLeftYUpSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == yUp) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYUpJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (yUp + 1) <= 8) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (yUp + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYUpSpaceBlank = false;
                                        xLeftYUpJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (yUp + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYUpSpaceBlank = false;
                                        xLeftYUpJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYUpSpaceBlank = false;
                                xLeftYUpJump = false;
                            }
                        }
                    }
                    if(xLeftYUpSpaceBlank && !xLeftYUpJump) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "lu");
                    } else if(xLeftYUpSpaceBlank && xLeftYUpJump) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "lu");
                    }
                }
                if(xLeft >= 1 && yDown >= 1) {
                    boolean xLeftYDownSpaceBlank = true;
                    boolean xLeftYDownJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == yDown) {
                            xLeftYDownSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == yDown) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYDownJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (yDown - 1) >= 1) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (yDown - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYDownSpaceBlank = false;
                                        xLeftYDownJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (yDown - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYDownSpaceBlank = false;
                                        xLeftYDownJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYDownSpaceBlank = false;
                                xLeftYDownJump = false;
                            }
                        }
                    }
                    if(xLeftYDownSpaceBlank && !xLeftYDownJump) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "ld");
                    } else if(xLeftYDownSpaceBlank && xLeftYDownJump) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "ld");
                    }
                }
                if(xRight <= 8 && yUp <= 8) {
                    boolean xRightYUpSpaceBlank = true;
                    boolean xRightYUpJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == yUp) {
                            xRightYUpSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == yUp) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYUpJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (yUp + 1) <= 8) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (yUp + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYUpSpaceBlank = false;
                                        xRightYUpJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (yUp + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYUpSpaceBlank = false;
                                        xRightYUpJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYUpSpaceBlank = false;
                                xRightYUpJump = false;
                            }
                        }
                    }
                    if(xRightYUpSpaceBlank && !xRightYUpJump) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "ru");
                    } else if(xRightYUpSpaceBlank && xRightYUpJump) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "ru");
                    }
                }
                if(xRight <= 8 && yDown >= 1) {
                    boolean xRightYDownSpaceBlank = true;
                    boolean xRightYDownJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == yDown) {
                            xRightYDownSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == yDown) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYDownJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (yDown - 1) >= 1) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (yDown - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYDownSpaceBlank = false;
                                        xRightYDownJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (yDown - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYDownSpaceBlank = false;
                                        xRightYDownJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYDownSpaceBlank = false;
                                xRightYDownJump = false;
                            }
                        }
                    }
                    if(xRightYDownSpaceBlank) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "rd");
                    } else if(xRightYDownSpaceBlank) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "rd");
                    }
                }
            } else {
                //Works well - debugged
                //Checks for non-kings
                int xLeft = aList.get(i).getX() - 1;
                int xRight = aList.get(i).getX() + 1;
                int y = aList.get(i).getY() - 1;
                if(xLeft >= 1) {
                    boolean xLeftYSpaceBlank = true;
                    boolean xLeftYJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == y) {
                            xLeftYSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == y) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (y - 1) >= 1) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (y - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYSpaceBlank = false;
                                        xLeftYJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (y - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYSpaceBlank = false;
                                        xLeftYJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYSpaceBlank = false;
                                xLeftYJump = false;
                            }
                        }
                    }
                    if(xLeftYSpaceBlank && !xLeftYJump) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "l");
                    } else if(xLeftYSpaceBlank && xLeftYJump) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "l");
                    }
                }
                if(xRight <= 8) {
                    boolean xRightYSpaceBlank = true;
                    boolean xRightYJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == y) {
                            xRightYSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == y) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (y - 1) >= 1) {
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (y - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYSpaceBlank = false;
                                        xRightYJump = false;
                                    }
                                }
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (y - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYSpaceBlank = false;
                                        xRightYJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYSpaceBlank = false;
                                xRightYJump = false;
                            }
                        }
                    }
                    if(xRightYSpaceBlank && !xRightYJump) {
                        possibleMovesA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "r");
                    } else if(xRightYSpaceBlank && xRightYJump) {
                        possibleJumpsA.add(String.valueOf(aList.get(i).getX()) + String.valueOf(aList.get(i).getY()) + "r");
                    }
                }
            }
        }
        if(possibleJumpsA.isEmpty()) {
            return possibleMovesA;
        } else{
            possibleJumpsA.add("j");
            return possibleJumpsA;
        }
    }

    public ArrayList<String> showMovesB() {
        //Iterates over the bList and finds out if the objects in the list can move
        ArrayList<String> possibleMovesB = new ArrayList<>();
        ArrayList<String> possibleJumpsB = new ArrayList<>();
        for(int i = 0; i < this.bList.size(); i++) {
            if(this.bList.get(i).isKing()) {
                //Checks for kings
                int xLeft = bList.get(i).getX() - 1;
                int xRight = bList.get(i).getX() + 1;
                int yUp = bList.get(i).getY() + 1;
                int yDown = bList.get(i).getY() - 1;
                if(xLeft >= 1 && yUp <= 8) {
                    boolean xLeftYUpSpaceBlank = true;
                    boolean xLeftYUpJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == yUp) {
                            xLeftYUpSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == yUp) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYUpJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (yUp + 1) <= 8) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (yUp + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYUpSpaceBlank = false;
                                        xLeftYUpJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (yUp + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYUpSpaceBlank = false;
                                        xLeftYUpJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYUpSpaceBlank = false;
                                xLeftYUpJump = false;
                            }
                        }
                    }
                    if(xLeftYUpSpaceBlank && !xLeftYUpJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "lu");
                    } else if(xLeftYUpSpaceBlank && xLeftYUpJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "lu");
                    }
                }
                if(xLeft >= 1 && yDown >= 1) {
                    boolean xLeftYDownSpaceBlank = true;
                    boolean xLeftYDownJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == yDown) {
                            xLeftYDownSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == yDown) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYDownJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (yDown - 1) >= 1) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (yDown - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYDownSpaceBlank = false;
                                        xLeftYDownJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (yDown - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYDownSpaceBlank = false;
                                        xLeftYDownJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYDownSpaceBlank = false;
                                xLeftYDownJump = false;
                            }
                        }
                    }
                    if(xLeftYDownSpaceBlank && !xLeftYDownJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "ld");
                    } else if(xLeftYDownSpaceBlank && xLeftYDownJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "ld");
                    }
                }
                if(xRight <= 8 && yUp <= 8) {
                    boolean xRightYUpSpaceBlank = true;
                    boolean xRightYUpJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == yUp) {
                            xRightYUpSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == yUp) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYUpJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (yUp + 1) <= 8) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (yUp + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYUpSpaceBlank = false;
                                        xRightYUpJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (yUp + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYUpSpaceBlank = false;
                                        xRightYUpJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYUpSpaceBlank = false;
                                xRightYUpJump = false;
                            }
                        }
                    }
                    if(xRightYUpSpaceBlank && !xRightYUpJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "ru");
                    } else if(xRightYUpSpaceBlank && xRightYUpJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "ru");
                    }
                }
                if(xRight <= 8 && yDown >= 1) {
                    boolean xRightYDownSpaceBlank = true;
                    boolean xRightYDownJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == yDown) {
                            xRightYDownSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == yDown) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYDownJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (yDown - 1) >= 1) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (yDown - 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYDownSpaceBlank = false;
                                        xRightYDownJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (yDown - 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYDownSpaceBlank = false;
                                        xRightYDownJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYDownSpaceBlank = false;
                                xRightYDownJump = false;
                            }
                        }
                    }
                    if(xRightYDownSpaceBlank && !xRightYDownJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "rd");
                    } else if(xRightYDownSpaceBlank && xRightYDownJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "rd");
                    }
                }
            } else {
                //Works well - debugged
                //Checks for non-kings
                int xLeft = bList.get(i).getX() - 1;
                int xRight = bList.get(i).getX() + 1;
                int y = bList.get(i).getY() + 1;
                if(xLeft >= 1) {
                    boolean xLeftYSpaceBlank = true;
                    boolean xLeftYJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xLeft && bList.get(j).getY() == y) {
                            xLeftYSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xLeft && aList.get(j).getY() == y) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xLeftYJump = true;
                            //This checks if there are enough space for a jump.
                            if((xLeft - 1) >= 1 && (y + 1) <= 8) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xLeft - 1) && aList.get(k).getY() == (y + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xLeftYSpaceBlank = false;
                                        xLeftYJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xLeft - 1) && bList.get(k).getY() == (y + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xLeftYSpaceBlank = false;
                                        xLeftYJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xLeftYSpaceBlank = false;
                                xLeftYJump = false;
                            }
                        }
                    }
                    if(xLeftYSpaceBlank && !xLeftYJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "l");
                    } else if(xLeftYSpaceBlank && xLeftYJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "l");
                    }
                }
                if(xRight <= 8) {
                    boolean xRightYSpaceBlank = true;
                    boolean xRightYJump = false;
                    //Sees if the space is free for movement (checks friendly checkers)
                    for(int j = 0; j < bList.size(); j++) {
                        if(bList.get(j).getX() == xRight && bList.get(j).getY() == y) {
                            xRightYSpaceBlank = false;
                        }
                    }
                    //Sees if the space is free for movement or jump (checks enemy checkers)
                    for(int j = 0; j < aList.size(); j++) {
                        if(aList.get(j).getX() == xRight && aList.get(j).getY() == y) {
                            //if there is a enemy checker in the space, check if it is jumpable.
                            xRightYJump = true;
                            //This checks if there are enough space for a jump.
                            if((xRight + 1) <= 8 && (y + 1) <= 8) {
                                for(int k = 0; k < aList.size(); k++) {
                                    if(aList.get(k).getX() == (xRight + 1) && aList.get(k).getY() == (y + 1)) {
                                        //If there is another enemy checker behind the blocking checker, the a checker cannot move.
                                        xRightYSpaceBlank = false;
                                        xRightYJump = false;
                                    }
                                }
                                for(int k = 0; k < bList.size(); k++) {
                                    if(bList.get(k).getX() == (xRight + 1) && bList.get(k).getY() == (y + 1)) {
                                        //If there is another friendly checker behind the blocking checker, the a checker cannot move.
                                        xRightYSpaceBlank = false;
                                        xRightYJump = false;
                                    }
                                }
                            } else {
                                //Not enough space for a jump.
                                xRightYSpaceBlank = false;
                                xRightYJump = false;
                            }
                        }
                    }
                    if(xRightYSpaceBlank && !xRightYJump) {
                        possibleMovesB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "r");
                    } else if(xRightYSpaceBlank && xRightYJump) {
                        possibleJumpsB.add(String.valueOf(bList.get(i).getX()) + String.valueOf(bList.get(i).getY()) + "r");
                    }
                }
            }
        }
        if(possibleJumpsB.isEmpty()) {
            return possibleMovesB;
        } else{
            possibleJumpsB.add("j");
            return possibleJumpsB;
        }
    }

    public int moveA(String moveChecker) {
        ArrayList<String> possibleMoves = showMovesA();
        boolean plausibleMove = false;
        for(int i = 0; i < possibleMoves.size(); i++) {
            if(moveChecker.equals(possibleMoves.get(i))) {
                plausibleMove = true;
            }
        }
        if(!plausibleMove) {
            //The move is not available
            return -1;
        } else {
            //The move is available
            if(!possibleMoves.get(possibleMoves.size()-1).equals("j")) {
                //When there is no jumping involved
                int xOriginal = Character.getNumericValue(moveChecker.charAt(0));
                int yOriginal = Character.getNumericValue(moveChecker.charAt(1));
                int coordinate = (xOriginal*10)+yOriginal;
                String direction = moveChecker.substring(2);
                ArrayList<Integer> listXY = new ArrayList<>();
                //Get cooridates of all A pieces
                for(int i = 0; i < aList.size(); i++) {
                    listXY.add((aList.get(i).getX()*10)+aList.get(i).getY());
                }
                int listXYIndex = 0;
                for(int i = 0; i < listXY.size(); i++) {
                    //checks if there is a checker on the coordinate
                    if(coordinate == listXY.get(i)) {
                        listXYIndex = i;
                    }
                }
                //These move the actual checker
                if(direction.equals("l")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                }
                if(direction.equals("r")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                }
                if(direction.equals("ld")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                }
                if(direction.equals("rd")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                }
                if(direction.equals("lu")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveUp();
                }
                if(direction.equals("ru")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveUp();
                }
                for(int i = 0; i < aList.size(); i++) {
                    if(aList.get(i).isAtEnd()) {
                        aList.get(i).setToKing();
                    }
                }
            } else {
                //These are for the jumping checkers
                int xOriginal = Character.getNumericValue(moveChecker.charAt(0));
                int yOriginal = Character.getNumericValue(moveChecker.charAt(1));
                int coordinate = (xOriginal*10)+yOriginal;
                String direction = moveChecker.substring(2);
                ArrayList<Integer> listXY = new ArrayList<>();
                ArrayList<Integer> listXYB = new ArrayList<>();
                //Get cooridates of A pieces
                for(int i = 0; i < aList.size(); i++) {
                    listXY.add((aList.get(i).getX()*10)+aList.get(i).getY());
                }
                //Get cooridates of B pieces
                for(int i = 0; i < bList.size(); i++) {
                    listXYB.add((bList.get(i).getX()*10)+bList.get(i).getY());
                }
                int listXYIndex = 0;
                for(int i = 0; i < listXY.size(); i++) {
                    //checks if there is a checker on the coordinate
                    if(coordinate == listXY.get(i)) {
                        listXYIndex = i;
                    }
                }
                if(direction.equals("l")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                    coordinate -= 11;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate -= 11;
                }
                if(direction.equals("r")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                    coordinate += 9;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate += 9;
                }
                if(direction.equals("ld")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveDown();
                    coordinate -= 11;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate -= 11;
                }
                if(direction.equals("rd")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveDown();
                    coordinate += 9;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate += 9;
                }
                if(direction.equals("lu")) {
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveUp();
                    aList.get(listXYIndex).moveLeft();
                    aList.get(listXYIndex).moveUp();
                    coordinate -= 9;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate -= 9;
                }
                if(direction.equals("ru")) {
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveUp();
                    aList.get(listXYIndex).moveRight();
                    aList.get(listXYIndex).moveUp();
                    coordinate += 11;
                    for(int i = 0; i < listXYB.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYB.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    bList.remove(listXYIndex);
                    coordinate += 11;
                }
                //Turns the checker into a king if it reaches the end.
                for(int i = 0; i < aList.size(); i++) {
                    if(aList.get(i).isAtEnd()) {
                        aList.get(i).setToKing();
                    }
                }
                possibleMoves = showMovesA();
                ArrayList<String> possibleMovesCopy = new ArrayList<>();
                if(possibleMoves.get(possibleMoves.size()-1).equals("j")) {
                    possibleMoves.remove(possibleMoves.size()-1);
                    for(int i = 0; i < possibleMoves.size(); i++) {
                        if(Integer.toString(coordinate).equals(possibleMoves.get(i).substring(0,2))) {
                            possibleMovesCopy.add(possibleMoves.get(i));
                        }
                    }
                    possibleMoves = possibleMovesCopy;
                    if(possibleMoves.size() > 0) {
                        showBoard();
                        System.out.println();
                        System.out.println("Another jump must be taken. Possible moves are:");
                        for (int i = 0; i < possibleMoves.size(); i++) {
                            System.out.println(possibleMoves.get(i));
                        }
                        System.out.println();
                        //Meaning that another jump is open
                        return coordinate;
                    }
                }
            }
            //Shows the first jump
            showBoard();
            return 0;
        }
    }

    public int moveB(String moveChecker) {
        ArrayList<String> possibleMoves = showMovesB();
        boolean plausibleMove = false;
        for(int i = 0; i < possibleMoves.size(); i++) {
            if(moveChecker.equals(possibleMoves.get(i))) {
                plausibleMove = true;
            }
        }
        if(!plausibleMove) {
            //The move is not available
            return -1;
        } else {
            //The move is available
            if(!possibleMoves.get(possibleMoves.size()-1).equals("j")) {
                //When there is no jumping involved
                int xOriginal = Character.getNumericValue(moveChecker.charAt(0));
                int yOriginal = Character.getNumericValue(moveChecker.charAt(1));
                int coordinate = (xOriginal*10)+yOriginal;
                String direction = moveChecker.substring(2);
                ArrayList<Integer> listXY = new ArrayList<>();
                //Get cooridates of all B pieces
                for(int i = 0; i < bList.size(); i++) {
                    listXY.add((bList.get(i).getX()*10)+bList.get(i).getY());
                }
                int listXYIndex = 0;
                for(int i = 0; i < listXY.size(); i++) {
                    //checks if there is a checker on the coordinate
                    if(coordinate == listXY.get(i)) {
                        listXYIndex = i;
                    }
                }
                //These move the actual checker
                if(direction.equals("l")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                }
                if(direction.equals("r")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                }
                if(direction.equals("ld")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveDown();
                }
                if(direction.equals("rd")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveDown();
                }
                if(direction.equals("lu")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                }
                if(direction.equals("ru")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                }
                for(int i = 0; i < bList.size(); i++) {
                    if(bList.get(i).isAtEnd()) {
                        bList.get(i).setToKing();
                    }
                }
            } else {
                //These are for the jumping checkers
                int xOriginal = Character.getNumericValue(moveChecker.charAt(0));
                int yOriginal = Character.getNumericValue(moveChecker.charAt(1));
                int coordinate = (xOriginal*10)+yOriginal;
                String direction = moveChecker.substring(2);
                ArrayList<Integer> listXY = new ArrayList<>();
                ArrayList<Integer> listXYA = new ArrayList<>();
                //Get cooridates of B pieces
                for(int i = 0; i < bList.size(); i++) {
                    listXY.add((bList.get(i).getX()*10)+bList.get(i).getY());
                }
                //Get cooridates of A pieces
                for(int i = 0; i < aList.size(); i++) {
                    listXYA.add((aList.get(i).getX()*10)+aList.get(i).getY());
                }
                int listXYIndex = 0;
                for(int i = 0; i < listXY.size(); i++) {
                    //checks if there is a checker on the coordinate
                    if(coordinate == listXY.get(i)) {
                        listXYIndex = i;
                    }
                }
                if(direction.equals("l")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                    coordinate -= 9;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate -= 9;
                }
                if(direction.equals("r")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                    coordinate += 11;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate += 11;
                }
                if(direction.equals("ld")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveDown();
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveDown();
                    coordinate -= 11;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate -= 11;
                }
                if(direction.equals("rd")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveDown();
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveDown();
                    coordinate += 9;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate += 9;
                }
                if(direction.equals("lu")) {
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                    bList.get(listXYIndex).moveLeft();
                    bList.get(listXYIndex).moveUp();
                    coordinate -= 9;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate -= 9;
                }
                if(direction.equals("ru")) {
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                    bList.get(listXYIndex).moveRight();
                    bList.get(listXYIndex).moveUp();
                    coordinate += 11;
                    for(int i = 0; i < listXYA.size(); i++) {
                        //checks if there is a checker on the coordinate
                        if(coordinate == listXYA.get(i)) {
                            listXYIndex = i;
                        }
                    }
                    aList.remove(listXYIndex);
                    coordinate += 11;
                }
                for(int i = 0; i < bList.size(); i++) {
                    if(bList.get(i).isAtEnd()) {
                        bList.get(i).setToKing();
                    }
                }
                possibleMoves = showMovesB();
                ArrayList<String> possibleMovesCopy = new ArrayList<>();
                if(possibleMoves.get(possibleMoves.size()-1).equals("j")) {
                    possibleMoves.remove(possibleMoves.size()-1);
                    for(int i = 0; i < possibleMoves.size(); i++) {
                        if(Integer.toString(coordinate).equals(possibleMoves.get(i).substring(0,2))) {
                            possibleMovesCopy.add(possibleMoves.get(i));
                        }
                    }
                    possibleMoves = possibleMovesCopy;
                    if(possibleMoves.size() > 0) {
                        showBoard();
                        System.out.println();
                        System.out.println("Another jump must be taken. Possible moves are:");
                        for (int i = 0; i < possibleMoves.size(); i++) {
                            System.out.println(possibleMoves.get(i));
                        }
                        System.out.println();
                        //Meaning that another jump is open
                        return coordinate;
                    }
                }
            }
            //Shows the first jump
            showBoard();
            return 0;
        }
    }

    //tester
    public void print() {
        for(int i = 0; i < this.aList.size(); i++) {
            System.out.println(this.aList.get(i));
        }
        for(int i = 0; i < this.bList.size(); i++) {
            System.out.println(this.bList.get(i));
        }
    }

}
