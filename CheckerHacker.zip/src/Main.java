import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    private static Scanner kb = new Scanner(System.in);
    private static Random rand = new Random();
    public static void main(String[] args) {
        //This is a Java program designed to simulate the lengendary game of checkers
        //The game will include to mods, two-player and one-player (where the player would face a checkers bot named Companion)
        System.out.println("Welcome to CheckerHackers, where you can play the amazing game of checkers.");
        System.out.println("Press any key to start.");
        kb.nextLine();
        room();
    }

    public static void room() {
        //Creating a new object for the board.
        Board b = new Board();
        System.out.println("non-king checkers are in lowercase, king checkers will be in uppercase.");
        System.out.println("You can only move left or right in non-king checkers, and you can move left/right and up/down with king checkers.");
        System.out.println("If there is an available jump to capture the enemy checker(s), you must make the jump.");
        System.out.println("List of all possible moves will be shown on the screen.");
        System.out.println("PLease decide who will be player A, and who will be player B.");
        System.out.println("Press any keys to flip the coin in order to decide who is going first.");
        kb.nextLine();
        if(rand.nextBoolean()) {
            System.out.println("Player A will go first.");
            while(true) {
                ArrayList<String> possibleMovesA = b.showMovesA();
                if (b.isAListEmpty() || possibleMovesA.isEmpty()) {
                    System.out.println("There are no more possible moves for player A.\nPlayer B wins!\nPress any key to end the game. I hope you had lots of fun!");
                    kb.nextLine();
                    System.exit(0);
                }
                playerATurn(b);
                ArrayList<String> possibleMovesB = b.showMovesB();
                if (b.isBListEmpty() || possibleMovesB.isEmpty()) {
                    System.out.println("There are no more possible moves for player B.\nPlayer A wins!\nPress any key to end the game. I hope you had lots of fun!");
                    kb.nextLine();
                    System.exit(0);
                }
                playerBTurn(b);
            }
        } else {
            System.out.println("Player B will go first.");
            while(true) {
                ArrayList<String> possibleMovesB = b.showMovesB();
                if (b.isBListEmpty() || possibleMovesB.isEmpty()) {
                    System.out.println("There are no more possible moves for player B.\nPlayer A wins!\nPress any key to end the game. I hope you had lots of fun!");
                    kb.nextLine();
                    System.exit(0);
                }
                playerBTurn(b);
                ArrayList<String> possibleMovesA = b.showMovesA();
                if (b.isAListEmpty() || possibleMovesA.isEmpty()) {
                    System.out.println("There are no more possible moves for player A.\nPlayer B wins!\nPress any key to end the game. I hope you had lots of fun!");
                    kb.nextLine();
                    System.exit(0);
                }
                playerATurn(b);
            }
        }
    }

    public static void playerATurn(Board b) {
        System.out.println("Player A's Turn.");
        ArrayList<String> possibleMovesA = b.showMovesA();
        b.showBoard();
        System.out.println("These are the possible moves.");
        for(int i = 0; i < possibleMovesA.size(); i++) {
            if(!possibleMovesA.get(i).equals("j")) {
                System.out.println(possibleMovesA.get(i));
            }
        }
        boolean moved = false;
        int returnValue = 0;
        while(!moved) {
            System.out.println("Please type in the move you would like to make.\nPlease type in xCoord + yCoord + (l/r if the piece is not a king (lowercase) or (lu/ld/ru/rd id if the piece is a king (uppercase))).");
            System.out.println("One example is: 16r");
            String coordinate = kb.nextLine();
            returnValue = b.moveA(coordinate);
            if(returnValue == -1) {
                System.out.println("Typo. Please try again.");
            } else {
                moved = true;
            }
        }
        if(returnValue > 0) {
            while (returnValue != 0) {
                System.out.println("Please type in the jump move you would like to make, the procedure is the same");
                String coordinate = kb.nextLine();
                if (coordinate.length() > 2 && Character.isDigit(coordinate.charAt(0)) && Character.isDigit(coordinate.charAt(1))) {
                    if (Integer.parseInt(coordinate.substring(0, 2)) == returnValue) {
                        int returnValueOriginal = returnValue;
                        returnValue = b.moveA(coordinate);
                        if(returnValue == -1) {
                            returnValue = returnValueOriginal;
                        }
                    } else {
                        System.out.println("The move doesn't work. Please try again.");
                    }
                } else {
                    System.out.println("Typo. Please try again.");
                }
            }
        }
    }

    public static void playerBTurn(Board b) {
        System.out.println("Player B's Turn.");
        ArrayList<String> possibleMovesB = b.showMovesB();
        b.showBoard();
        System.out.println("These are the possible moves.");
        for(int i = 0; i < possibleMovesB.size(); i++) {
            if(!possibleMovesB.get(i).equals("j")) {
                System.out.println(possibleMovesB.get(i));
            }
        }
        boolean moved = false;
        int returnValue = 0;
        while(!moved) {
            System.out.println("Please type in the move you would like to make.\nPlease type in xCoord + yCoord + (l/r if the piece is not a king (lowercase) or (lu/ld/ru/rd id if the piece is a king (uppercase))).");
            System.out.println("One example is: 23l");
            String coordinate = kb.nextLine();
            returnValue = b.moveB(coordinate);
            if(returnValue == -1) {
                System.out.println("Typo. Please try again.");
            } else {
                moved = true;
            }
        }
        if(returnValue > 0) {
            while (returnValue != 0) {
                System.out.println("Please type in the jump move you would like to make, the procedure is the same");
                String coordinate = kb.nextLine();
                if (coordinate.length() > 2 && Character.isDigit(coordinate.charAt(0)) && Character.isDigit(coordinate.charAt(1))) {
                    if (Integer.parseInt(coordinate.substring(0, 2)) == returnValue) {
                        int returnValueOriginal = returnValue;
                        returnValue = b.moveB(coordinate);
                        if(returnValue == -1) {
                            returnValue = returnValueOriginal;
                        }
                    } else {
                        System.out.println("The move doesn't work. Please try again.");
                    }
                } else {
                    System.out.println("Typo. Please try again.");
                }
            }
        }
    }
}
